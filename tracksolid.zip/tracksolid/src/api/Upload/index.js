/*!
 * 图片 请求相关
 */

import axios from 'axios'
import { URL } from '@/config'

// 上传图片
export function upload (file) {
  let url = URL + '/driver/upload'
  let param = new FormData() // 创建form对象
  // 通过append向form对象添加数据
  param.append('file', file)
  let config = {
    headers: {'Content-Type': 'multipart/form-data'}
  }
  let result = axios.post(url, param, config).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 删除图片
export function delFile (fileName) {
  let url = URL + '/driver/delFile?key=' + fileName
  let result = axios.get(url).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}
