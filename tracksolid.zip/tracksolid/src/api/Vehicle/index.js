/*!
 * vehicle 异步请求相关
 */

import axios from 'axios'
// eslint-disable-next-line no-unused-vars
import { URL, GO_BACK_URL } from '@/config'
// eslint-disable-next-line no-unused-vars
import qs from 'qs'

// 获取/查询获取车辆列表
export function getVehicleData (imei = null, plateNo = null, status = 0, pageSize = 10, pageNum = 0) {
  let url = URL + '/vehicle/list'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      imei,
      plateNo,
      status,
      pageSize,
      pageNum
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 导出车辆列表信息
export function exportVehicleData (imei = null, plateNo = null, status = null) {
  let url = URL + '/vehicle/export'
  let result = axios({
    method: 'post',
    url: url,
    responseType: 'arraybuffer',
    data: {
      imei,
      plateNo,
      status
    }
  }).then((response) => {
    console.log(response.data)
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 删除车辆信息
export function vehicleDelete (id = null) {
  let url = URL + '/vehicle/deleteById'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      id
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 修改/新增车辆信息
export function vehicleUpdate (id = null, plateNo = null, plateType = null, imei = null, engineNo = null, status = null, maxSpeed = null, brand = null, model = null, vin = null, fuel = null, color = null, ext1 = null, ext2 = null, ext3 = null, ext4 = null, imagePath = null, productionYear = null, remark = null
) {
  let url = URL + '/vehicle/update'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      id,
      plateNo,
      plateType,
      imei,
      engineNo,
      status,
      maxSpeed,
      brand,
      model,
      vin,
      fuel,
      color,
      ext1,
      ext2,
      ext3,
      ext4,
      imagePath,
      productionYear,
      remark
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// imei后6位搜索匹配到的imei号和deviceName
export function deviceQuery (imei = null, pageNum = 0, pageSize = 100) {
  let url = URL + '/vehicle/deviceQuery'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      imei,
      pageNum,
      pageSize
    },
    responseType: 'json'
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 新增： imei跳转到monitor界面
/* export function imeiLink(keyword=null, userId=null) {
  let url = GO_BACK_URL.split('/fleetIndex').join('')+ '/console'
  let result = axios({
    method: 'post',
    url,
    data:{
      keyword,
      userId,
    }
  })
  .then((response) => {
    return response.data
  })
  .catch((e) => {
    return e
  });
  return result
} */

// 查询设备对应的里程阈值获取
export function getImeiMileThreshold (imei = null) {
  let url = window._ctx + '/device/querymileageThreshold'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      imei
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 设备对应的行驶里程获取
export function getImeiDriveMile (imei = null) {
  let url = window._ctx + '/device/getTotalMilage'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      imei
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 保存超速的里程
export function saveOverSpeed (imei = null, overSpeed = null, overSecond = null) {
  let url = window._ctx + '/device/saveOverSpeed'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      imei,
      overSpeed,
      overSecond
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 保存持续时间告警信息
export function saveAccOnDuration (imei = null, aCCOnDurtionThreshold = null, currentAccOnDuration = null) {
  let url = window._ctx + '/device/saveAccOnDuration'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      imei,
      aCCOnDurtionThreshold,
      currentAccOnDuration
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 保存里程
export function saveMileThreshold (imei = null, mileageThreshold = null, odometer = null) {
  let url = window._ctx + '/device/saveMileage'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      imei,
      mileageThreshold,
      odometer
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}
