/*!
 * notification 异步请求相关
 */

import axios from 'axios'
import { URL } from '@/config'

// 查询通知列表
export function getNotificationList (startDate = null, endDate = null, source = null, pageSize = 10, pageNum = 1) {
  let url = URL + '/notification/list'
  let result = axios.post(url, {
    startDate,
    endDate,
    source,
    pageSize,
    pageNum
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 获取未读的通知数量
export function getNotificationCount () {
  let url = URL + '/notification/count'
  let result = axios.post(url, {
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 批量删除通知
export function notificationdDelete (idArray = null) {
  let url = URL + '/notification/delete'
  let result = axios.post(url, {
    idArray
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 标记所有通知为已读
export function notificationAllRead () {
  let url = URL + '/notification/allRead'
  let result = axios.post(url, {
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 导出通知信息
export function exportNotificationData (startDate = null, endDate = null, source = null, pageSize = null, pageNum = null) {
  let url = URL + '/notification/export'
  let result = axios({
    method: 'post',
    url: url,
    responseType: 'arraybuffer',
    data: {
      startDate,
      endDate,
      source,
      pageSize,
      pageNum
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}
