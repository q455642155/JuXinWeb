import axios from 'axios'
import { URL } from '@/config'

// 获取规划路径信息列表
export function getRouteInfo (pageSize = 10, pageNum = 0) {
  let url = URL + '/routeplan/list'
  let result = axios.post(url, {
    pageSize,
    pageNum
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 删除路径信息
export function deleteRoute (id = null) {
  let url = URL + '/routeplan/deleteById'
  let result = axios.post(url, {
    id
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 添加修改信息
export function addOrEditInfo (id = null, imeis = null, path_name = null, description = null, path_json = null) {
  let url = URL + '/routeplan/update'
  let result = axios.post(url, {
    id,
    imeis,
    path_name,
    description,
    path_json
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 查询告警信息
export function queryAlarmInfo (geonId = null) {
  let url = URL + '/geozone/queryalarminfo'
  let result = axios.post(url, {
    geonId
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 获取用户树初始化节点数据
export function relationDeviceData (userId = null) {
  let url = URL + '/customer/getOrgUserTree'
  let result = axios.post(url, {
    userId
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 获取初始化设备树的节点数据
export function getInitDeviceNode (userId = null, imeisOrdevName = null) {
  let url = URL + '/device/getReportDevice'
  let result = axios.post(url, {
    userId,
    imeisOrdevName
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 单击节点获取子节点
export function getLowerUserNode (parentId = null, fullParentId = null) {
  let url = URL + '/customer/getLowerUser'
  let result = axios.post(url, {
    parentId,
    fullParentId
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}
