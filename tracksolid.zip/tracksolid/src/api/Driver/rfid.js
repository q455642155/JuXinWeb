/*!
 * driver 异步请求相关
 */

import axios from 'axios'
import { URL } from '@/config'
// 查询rfid列表
export function getRfidData (cardId = null, startDate = null, endDate = null, pageSize = 10, pageNum = 0) {
  let url = URL + '/rfid/list'
  let result = axios.post(url, {
    cardId,
    startDate,
    endDate,
    pageSize,
    pageNum
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}
export function exportRfidData (imei = null, plateNo = null, status = null) {
  let url = 'URL' + '/rfid/export'
  let result = axios({
    method: 'post',
    url: url,
    responseType: 'arraybuffer',
    data: {
      imei,
      plateNo,
      status
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}
