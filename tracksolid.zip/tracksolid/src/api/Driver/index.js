/*!
 * driver 异步请求相关
 */

import axios from 'axios'
import { URL } from '@/config'
// 查询司机列表
export function getDriverData (keyword = null, phone = null, registerPlace = null, licenseExpired = false, pageSize = 10, pageNum = 0) {
  let url = URL + '/driver/list'
  let result = axios.post(url, {
    keyword,
    phone,
    registerPlace,
    licenseExpired,
    pageSize,
    pageNum
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 导出司机列表
export function exportDriverData (keyword = null, phone = null, registerPlace = null, licenseExpired = false) {
  let url = URL + '/driver/export'
  let result = axios({
    method: 'post',
    url: url,
    responseType: 'arraybuffer',
    data: {
      keyword,
      registerPlace,
      phone,
      licenseExpired,
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 新增/修改司机信息
export function driverUpdate (id = null, driverNo = null, driverName = null, licenseNo = null, city = null, registerPlace = null, registerDate = null, expiredDate = null, email = null, phone = null, ext1 = null, ext2 = null, ext3 = null, ext4 = null, address = null, remark = null, imagePath = null) {
  let url = URL + '/driver/update'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      id,
      driverNo,
      driverName,
      licenseNo,
      city,
      registerPlace,
      registerDate,
      expiredDate,
      email,
      phone,
      ext1,
      ext2,
      ext3,
      ext4,
      address,
      remark,
      imagePath
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 删除司机信息
export function driverDelete (id = null) {
  let url = URL + '/driver/deleteById'
  let result = axios.post(url, {
    id
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}
