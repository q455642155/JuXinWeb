
import axios from 'axios'
import { URL } from '@/config'

// 获取车辆相关统计数据
export function getOverViewData (userId = null) {
  let url = URL + '/dashboard/getVehicleStatistics'
  let result = axios.post(url, {
    userId
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 获得油感消耗排序统计
export function getFuelConsumption (orderBy = null, viewQuantity = null, startTime = null, endTime = null) {
  let url = URL + '/dashboard/getTopFuelConsumption'
  let result = axios.post(url, {
    orderBy,
    viewQuantity,
    startTime,
    endTime
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 获取提醒任务
export function getRemind (type = null) {
  let url = URL + '/dashboard/reminderOverview'
  let result = axios.post(url, {
    type
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 获得行驶里程排序统计
export function getDriveMile (orderBy = null, viewQuantity = null, startTime = null, endTime = null) {
  let url = URL + '/dashboard/drivingMileageStatistics'
  let result = axios.post(url, {
    orderBy,
    viewQuantity,
    startTime,
    endTime
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 获得驾驶行为信息
export function getDriveBehavior (type = null, orderBy = null, viewQuantity = null, startTime = null, endTime = null) {
  let url = URL + '/dashboard/getDrivingBehavior'
  let result = axios.post(url, {
    type,
    orderBy,
    viewQuantity,
    startTime,
    endTime
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}
