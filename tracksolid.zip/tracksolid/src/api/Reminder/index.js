/*!
 * reminder 异步请求相关
 */

import axios from 'axios'
import { URL } from '@/config'

// 获取数据 - 查询提醒列表
export function getReminderData (relationId = null, reminderType = null) {
  let url = URL + '/reminder/list'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      relationId,
      reminderType
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 修改/新增提醒
export function updateReminder (id = null, relationId = null, reminderName = null, reminderType = null, interval = null, intervalType = null, remindAdvance = null, advanceType = null, reminderFactor = null, startDateStr = null, lastMaintenance = null, notificationEmail = null) {
  let url = URL + '/reminder/update'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      id,
      relationId,
      reminderName,
      reminderType,
      interval,
      intervalType,
      remindAdvance,
      advanceType,
      reminderFactor,
      startDateStr,
      lastMaintenance,
      notificationEmail
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// 删除提醒
export function deleteReminder (id = null) {
  let url = URL + '/reminder/deleteById'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      id
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}

// imei 获取车辆当前里程
export function getCurrentMileage (imei = null) {
  let url = URL + '/reminder/getCurrentMileage'
  let result = axios({
    method: 'post',
    url: url,
    data: {
      imei
    }
  }).then((response) => {
    return response.data
  }).catch((e) => {
    return e
  })
  return result
}
