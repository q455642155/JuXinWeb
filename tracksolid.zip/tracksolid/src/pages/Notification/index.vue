<template>
  <div class="page page-Notification">
    <Header @isNotification="getTableData()"/>
    <div class="body-wrapper">
      <Nav/>
      <div class="main-wrapper">
        <h1>{{ this.Local ? this.Local.prop('msg.updateNotice') : 'Notifications' }}</h1>
        <div class="main">
          <!-- Form Start -->
          <form ref="form">
            <div class="input-wrapper notification-time">
              <span
                class="notification-time-span"
              >{{ this.Local ? this.Local.prop('Fleet.Notification.NotificationTime') : 'Notification Time' }}</span>
              <el-date-picker
                v-model.trim="form.time"
                type="daterange"
                range-separator="-"
                value-format="yyyy-MM-dd"
                :start-placeholder="Local ? Local.prop('header.PositionStartTime') : 'Start Time'"
                :end-placeholder="Local ? Local.prop('header.PositionEndTime') : 'End Time'"
              ></el-date-picker>
            </div>
            <div class="input-wrapper reminder-entity">
              <span
                class="reminder-entity-span"
              >{{ this.Local ? this.Local.prop('Fleet.Notification.ReminderEntity') : 'Reminder Entity' }}</span>
              <el-select
                v-model="form.source"
                placeholder="Reminder Entity"
                class="reminder-entity-select"
              >
                <el-option
                  v-for="item in sourceStatus"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                  :no-data-text="Local ? Local.prop('comm.noData') : 'No data found'"
                ></el-option>
              </el-select>
            </div>
            <div class="input-wrapper search">
              <el-button
                type="primary"
                icon="el-icon-search"
                @click="onSubmit"
                round
              >{{ this.Local ? this.Local.prop('comm.Search') : 'Search' }}</el-button>
            </div>
          </form>
          <!-- Form End -->

          <!-- Table Start -->
          <div class="table-wrapper">
            <div class="btn-wrapper">
              <label>
                <el-button
                  @click="tableAllRead()"
                  type="primary"
                  size="mini"
                  icon="icon-message"
                  circle
                ></el-button>
                {{ this.Local ? this.Local.prop('Fleet.Notification.AllRead') : 'All Read' }}
              </label>
              <label>
                <el-button
                  @click="tableAllRowsDelete()"
                  type="primary"
                  size="mini"
                  icon="el-icon-delete"
                  circle
                ></el-button>
                {{ this.Local ? this.Local.prop('Asset.Delete') : 'Delete' }}
              </label>
              <label>
                <el-button
                  @click="tableExport()"
                  type="primary"
                  size="mini"
                  icon="icon-export"
                  class="fs12"
                  circle
                ></el-button>
                {{ this.Local ? this.Local.prop('header.ACCReport.export') : 'Export' }}
              </label>
            </div>
            <div class="table">
              <el-table
                ref="multipleTable"
                :data="tableData.list"
                stripe
                fit
                @selection-change="handleSelectionChange"
                @select-all="handleSelectAll"
                v-loading="loading"
                :element-loading-text="Local ? Local.prop('comm.loadingData') : 'Loading...'"
                :empty-text="Local ? Local.prop('comm.noData') : 'No data found'"
                tooltip-effect="dark"
              >
                <el-table-column width="40" type="selection" align="center"></el-table-column>
                <el-table-column
                  width="50"
                  align="center"
                  type="index"
                  :label="Local ? Local.prop('Alert.number') : 'No.'"
                  :index="indexMethod"
                ></el-table-column>

                <el-table-column
                  :label="Local ? Local.prop('Fleet.Notification.NotificationTime') : 'Notification Time'"
                >
                  <template
                    slot-scope="scope"
                  >{{ timestampToTime(scope.row.notificationTime, true) }}</template>
                </el-table-column>

                <el-table-column
                  prop="source"
                  :label="(Local ? Local.prop('Fleet.Vehicle.Vehicle') : 'Vehicle') + ' / ' + (Local ? Local.prop('Fleet.Driver') : 'Driver')"
                ></el-table-column>

                <el-table-column
                  prop="reminderName"
                  :label="Local ? Local.prop('Fleet.Reminder.ReminderName') : 'Reminder Name'"
                ></el-table-column>

                <el-table-column
                  prop="currentValue"
                  :label="Local ? Local.prop('Fleet.Notification.CurrentValue') : 'Current Value'"
                ></el-table-column>

                <el-table-column
                  min-width="300"
                  prop="content"
                  align="center"
                  :label="Local ? Local.prop('msg.content') : 'Content'"
                ></el-table-column>

                <el-table-column
                  align="center"
                  :label="Local ? Local.prop('comm.Operate') : 'Actions'"
                >
                  <template slot-scope="scope">
                    <el-button
                      @click="handleDelete(scope.$index, scope.row)"
                      class="btn-contorl"
                      size="mini"
                      type="danger"
                      icon="el-icon-delete"
                      circle
                    ></el-button>
                  </template>
                </el-table-column>
              </el-table>
              <div class="pagination-wrapper">
                <span class="total">
                  {{ this.Local ? this.Local.prop('Fleet.Driver.Displaying') : 'Displaying' }}
                  {{ (currentPage-1) * limitSize}} - {{currentPage * limitSize }}
                  {{ this.Local ? this.Local.prop('Fleet.Driver.Of') : 'of' }}
                  {{ tableData.total }}
                  {{ this.Local ? this.Local.prop('Fleet.Driver.Records') : 'Records' }}
                </span>
                <el-pagination
                  class="pagination"
                  @current-change="handleCurrentChange"
                  layout="sizes, prev, pager, next"
                  @size-change="handleSizeChange"
                  :page-sizes="limitSizes"
                  :page-size="limitSize"
                  :total="tableData.total"
                ></el-pagination>
              </div>
            </div>
          </div>
          <!-- Table End -->
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import Header from '@/components/Header'
import Nav from '@/components/Nav'
import {
  getNotificationList,
  notificationdDelete,
  notificationAllRead,
  exportNotificationData
} from '@/api/Notification'
import { mapGetters, mapMutations } from 'vuex'
import { promptMessage } from '@/common/js/common'
import { tableMixin } from '@/common/js/mixins'

export default {
  name: 'Notification',
  mixins: [tableMixin],
  computed: {
    ...mapGetters(['count'])
  },
  data() {
    return {
      // 搜索表单内容
      form: {
        time: '',
        source: ''
      },
      // 记录搜索时表格的搜索条件
      formToSearch: {
        time: '',
        source: ''
      },
      // 搜索表单下 sourceStatus 多选框选项
      sourceStatus: [
        {
          value: '',
          label: this.Local ? this.Local.prop('index.all') : 'All'
        },
        {
          value: 'Driver',
          label: this.Local ? this.Local.prop('Fleet.Driver') : 'Driver'
        },
        {
          value: 'Vehicle',
          label: this.Local
            ? this.Local.prop('Fleet.Vehicle.Vehicle')
            : 'Vehicle'
        }
      ]
    }
  },
  methods: {
    // Table - 获取表格数据异步请求
    getTableData() {
      // 清空数据
      // this.tableData = {}
      // 重新加载数据
      let startDate = this.formToSearch.time
        ? this.form.time[0] + ' 00:00:00'
        : null
      let endDate = this.formToSearch.time
        ? this.form.time[1] + ' 23:59:59'
        : null
      let source = this.formToSearch.source
      let pageSize = this.limitSize
      let pageNum = this.currentPage
      this.loading = true
      getNotificationList(startDate, endDate, source, pageSize, pageNum)
        .then(res => {
          if (res.code === 0) {
            this.tableData = res.data
            this.loading = false
            return
          }
          // 根据 code 的值给出提示信息
          promptMessage.call(this, res.code)
        })
        .catch(e => {
          this.$message({
            message: this.Local
              ? this.Local.prop('Commands.Unknown_error')
              : 'Unknown error',
            center: true,
            type: 'error'
          })
        })
    },
    // Form - 表单提交
    onSubmit() {
      this.formToSearch.time = this.form.time
      this.formToSearch.source = this.form.source
      this.getTableData()
    },
    // Table - 全部标为已读
    tableAllRead() {
      if (this.tableData.list && this.tableData.list.length > 0) {
        this.$confirm(
          this.Local
            ? this.Local.prop('Fleet.Notification.AllRead') + '?'
            : 'All Read ?',
          this.Local ? this.Local.prop('comm.infomation') : 'Message',
          {
            confirmButtonText: this.Local
              ? this.Local.prop('timePicker.confirm')
              : 'confirm',
            cancelButtonText: this.Local
              ? this.Local.prop('index.Cancel')
              : 'Cancel'
          }
        )
          .then(() => {
            notificationAllRead()
              .then(res => {
                if (res.code === 0) {
                  this.ids = []
                  this.SET_COUNT(0)
                }
                // 根据 code 的值给出提示信息
                promptMessage.call(this, res.code)
              })
              .catch(e => {
                this.$message({
                  message: this.Local
                    ? this.Local.prop('Commands.Unknown_error')
                    : 'Unknown error',
                  center: true,
                  type: 'error'
                })
              })
          })
          .catch(() => {
            // 取消
          })
      }
    },
    // Table - 删除数据异步请求
    tableRowsDelete (ids) {
      if (ids.length) {
        this.$confirm(
          this.Local
            ? this.Local.prop('comm.ConfirmDelete')
            : 'Confirm to delete it?',
          this.Local ? this.Local.prop('comm.Delete') : 'Delete',
          {
            confirmButtonText: this.Local
              ? this.Local.prop('comm.Delete')
              : 'Delete',
            cancelButtonText: this.Local
              ? this.Local.prop('index.Cancel')
              : 'Cancel'
          }
        )
          .then(() => {
            // 确认删除
            notificationdDelete(ids)
              .then(res => {
                if (res.code === 0) {
                  this.ids = []
                  this.getTableData()
                }
                // 根据 code 的值给出提示信息
                promptMessage.call(this, res.code)
              })
              .catch(e => {
                this.$message({
                  message: this.Local
                    ? this.Local.prop('Commands.Unknown_error')
                    : 'Unknown error',
                  center: true,
                  type: 'error'
                })
              })
          })
          .catch(() => {
            // 取消
          })
      }
    },

    // Table - 导出数据
    tableExport () {
      let startDate = this.formToSearch.time
        ? this.form.time[0] + ' 00:00:00'
        : null
      let endDate = this.formToSearch.time
        ? this.form.time[1] + ' 23:59:59'
        : null
      let source = this.formToSearch.source
      let pageNum = this.formToSearch.pageNum
      let pageSize = this.formToSearch.pageSize

      exportNotificationData(startDate, endDate, source, pageSize, pageNum)
        .then(res => {
          if (res.code) {
            // 根据code的值给出提示信息
            promptMessage.call(this, res.code)
          }
        })
        .catch(e => {
          this.$message({
            message: this.Local
              ? this.Local.prop('Commands.Unknown_error')
              : 'Unknown error',
            center: true,
            type: 'error'
          })
        })
    },
    ...mapMutations(['SET_COUNT'])
  },
  watch: {
    // 通知数量变化/增多 则刷新数据
    count: function (newVal, oldVal) {
      if (newVal > 0) {
        this.getTableData()
      }
    }
  },
  components: {
    Header,
    Nav
  }
}
</script>

<style lang='less'>
.page-Notification {
  .main {
    form {
      display: inline-block;
      border-bottom: 1px solid #f3f3f3;
      width: 100%;
      .input-wrapper {
        display: inline-block;
        margin-bottom: 20px;
        float: left;
        height: 40px;
        padding: 0 10px;
        .el-input {
          width: 230px;
        }
      }
      .driverNo {
        padding-left: 0;
      }
      .search {
        width: 120px;
      }
      .notification-time {
        padding-left: 0;
        .notification-time-span {
          display: inline-block;
          line-height: 40px;
          padding-right: 10px;
          color: #868aa8;
          font-size: 14px;
        }
        .status-select {
          display: inline-block;
          width: 230px;
        }
        .el-range-separator {
          color: #c3c3c3;
        }
      }
      .reminder-entity {
        .reminder-entity-span {
          display: inline-block;
          line-height: 40px;
          padding-right: 10px;
          color: #868aa8;
          font-size: 14px;
        }
        .status-select {
          display: inline-block;
          width: 230px;
        }
      }
    }
    .table-wrapper {
      margin: 20px 0 0 0;
      .btn-wrapper {
        display: block;
        width: 100%;
        height: 40px;
        label {
          float: left;
          margin-right: 20px;
          cursor: pointer;
          font-size: 14px;
          color: #868aa8;
          user-select: none;
          button {
            margin-right: 10px;
            padding: 6px;
            .icon-message,
            .el-icon-delete {
              font-size: 12px;
            }
            .icon-message {
              font-weight: bold;
            }
          }
        }
        label:hover {
          color: #ccc;
        }
        .fs12 i {
          font-size: 12px !important;
        }
      }
      .table {
        margin-top: 10px;
        .btn-contorl {
          padding: 6px;
        }
        .pagination-wrapper {
          width: 100%;
          height: 40px;
          margin-top: 20px;
          .pagination {
            display: inline-block;
            float: right;
            font-size: 12px;
          }
          .total {
            padding: 0 4px;
            background: #fff;
            font-size: 13px;
            min-width: 35.5px;
            height: 28px;
            line-height: 28px;
            box-sizing: border-box;
          }
        }
      }
    }
  }
}
</style>
