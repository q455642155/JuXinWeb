<template>
  <div class="page page-Driver">
    <Header/>
    <div class="body-wrapper">
      <Nav :active="active"/>
      <div class="main-wrapper">
        <h1>{{ this.Local ? this.Local.prop('Fleet.Driver') : 'Driver' }}</h1>
        <div class="main">
          <form ref="form">
            <div class="input-wrapper driverNo">
              <el-input
                :clearable="true"
                :maxlength="24"
                v-model.trim="form.keyword"
                :placeholder="Local ? Local.prop('Fleet.Driver.DriverNo') + '/' + Local.prop('Asset.Drivername') : 'Driver No./Driver Name'"
              ></el-input>
            </div>
            <div class="input-wrapper city">
              <el-input
                :clearable="true"
                :maxlength="24"
                v-model.trim="form.registerPlace"
                :placeholder="Local ? Local.prop('Fleet.Driver.RegisterPlace') : 'Register Place'"
              ></el-input>
            </div>
            <div class="input-wrapper license-expired">
              <el-checkbox
                v-model="form.licenseExpired"
              >{{ this.Local ? this.Local.prop('Fleet.Driver.LicenseExpired') : 'License Expired' }}</el-checkbox>
            </div>
            <div class="input-wrapper search">
              <el-button
                type="primary"
                icon="el-icon-search"
                @click="onSubmit"
                round
              >{{ this.Local ? this.Local.prop('comm.Search') : 'Search' }}</el-button>
            </div>
          </form>
          <div class="table-wrapper">
            <div class="btn-wrapper">
              <label>
                <el-button @click="driverAdd()" type="primary" size="mini" icon="icon-add" circle></el-button>
                {{ this.Local ? this.Local.prop('comm.Add') : 'Add' }}
              </label>
              <label>
                <el-button
                  @click="driverExport()"
                  type="primary"
                  size="mini"
                  icon="icon-export"
                  circle
                ></el-button>
                {{ this.Local ? this.Local.prop('header.ACCReport.export') : 'Export' }}
              </label>
            </div>
            <!-- table header -->
            <div class="table">
              <el-table
                ref="multipleTable"
                :data="tableData.list"
                stripe
                fit
                tooltip-effect="dark"
                @selection-change="handleSelectionChange"
                @select-all="handleSelectAll"
                :empty-text="Local ? Local.prop('comm.noData') : 'No data found'"
                v-loading="loading"
                :element-loading-text="Local ? Local.prop('comm.loadingData') : 'Loading...'"
              >
                <el-table-column type="selection" min-width="55" align="center"></el-table-column>
                <el-table-column
                  type="index"
                  :label="Local ? Local.prop('Alert.number') : 'No.'"
                  :index="indexMethod"
                  min-width="55"
                  align="center"
                ></el-table-column>

                <el-table-column
                  prop="driverNo"
                  :label="Local ? Local.prop('Fleet.Driver.DriverNo') : 'Driver No.'"
                  style="background-color:red!important;"
                ></el-table-column>

                <el-table-column
                  prop="driverName"
                  :label="Local ? Local.prop('Asset.Drivername') : 'Driver Name'"
                ></el-table-column>

                <el-table-column
                  prop="licenseNo"
                  :label="Local ? Local.prop('Fleet.Driver.LicenseNo') : 'License No.'"
                ></el-table-column>

                <el-table-column
                  prop="registerPlace"
                  :label="Local ? Local.prop('Fleet.Driver.RegisterPlace') : 'Register Place'"
                ></el-table-column>

                <el-table-column
                  :label="Local ? Local.prop('Fleet.Driver.RegisterDate') : 'Register Date'"
                >
                  <template slot-scope="scope">{{ timestampToTime(scope.row.registerDate, false) }}</template>
                </el-table-column>
                <el-table-column
                  :label="Local ? Local.prop('Fleet.Driver.ExpiredDate') : 'Expired Date'"
                >
                  <template slot-scope="scope">{{ timestampToTime(scope.row.expiredDate, false) }}</template>
                </el-table-column>

                <el-table-column
                  :label="Local ? Local.prop('Fleet.Driver.LicenseStatus') : 'License Status'"
                  align="center"
                >
                  <template slot-scope="scope">
                    <span
                      :class="expiredClass(scope.row.expiredDate)"
                    >{{ expired(scope.row.expiredDate) }}</span>
                  </template>
                </el-table-column>

                <el-table-column
                  :label="Local ? Local.prop('Fleet.Driver.Reminder') : 'Reminder'"
                  align="center"
                >
                  <template slot-scope="scope">
                    <el-button
                      size="mini"
                      class="reminder-edit"
                      @click="handleReminderEdit(scope.$index, scope.row)"
                    >{{ Local ? Local.prop('Alert.edit') : 'Edit' }}</el-button>
                  </template>
                </el-table-column>
                <el-table-column
                  :label="Local ? Local.prop('comm.Operate') : 'Actions'"
                  align="center"
                >
                  <template slot-scope="scope">
                    <el-button
                      @click="handleEdit(scope.$index, scope.row)"
                      class="btn-contorl"
                      size="mini"
                      type="success"
                      icon="el-icon-edit"
                      circle
                    ></el-button>
                    <el-button
                      @click="handleDelete(scope.$index, scope.row)"
                      class="btn-contorl"
                      size="mini"
                      type="danger"
                      icon="el-icon-delete"
                      circle
                    ></el-button>
                  </template>
                </el-table-column>
              </el-table>
              <div class="pagination-wrapper">
                <span class="total">
                  {{ this.Local ? this.Local.prop('Fleet.Driver.Displaying') : 'Displaying' }}
                  {{ (currentPage-1) * limitSize}} - {{currentPage * limitSize }}
                  {{ this.Local ? this.Local.prop('Fleet.Driver.Of') : 'of' }}
                  {{ tableData.total }}
                  {{ this.Local ? this.Local.prop('Fleet.Driver.Records') : 'Records' }}
                </span>
                <el-pagination
                  class="pagination"
                  @current-change="handleCurrentChange"
                  layout="sizes, prev, pager, next"
                  @size-change="handleSizeChange"
                  :page-sizes="limitSizes"
                  :page-size="limitSize"
                  :total="tableData.total"
                  :current-page="tableData.pageNum"
                ></el-pagination>
              </div>
            </div>
          </div>
          <DriverDialog
            ref="DriverDialog"
            :form="currentSelectRow"
            @refresh="getTableData()"
            :type="type"
          />
          <AddReminderDialog
            ref="AddReminderDialog"
            :reminderType="reminderType"
            :relationId="currentSelectRowToReminder.id"
            @refresh="getTableData()"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import Header from '@/components/Header'
import Nav from '@/components/Nav'
import DriverDialog from '@/components/DriverDialog'
import AddReminderDialog from '@/components/AddReminderDialog'
import { getDriverData, exportDriverData, driverDelete } from '@/api/Driver'
import { promptMessage } from '@/common/js/common'
import { tableMixin } from '@/common/js/mixins'

export default {
  name: 'Driver',
  mixins: [tableMixin],
  data() {
    return {
      // 导航栏状态
      active: 1,
      // 搜索表单内容
      form: {
        keyword: null,
        phone: null,
        registerPlace: null,
        licenseExpired: false
      },
      formToSearch: {
        keyword: null,
        phone: null,
        registerPlace: null,
        licenseExpired: false
      },
      // 点击Reminder时表格当前正在操作的行
      currentSelectRowToReminder: {},
      // 设置 DriverDialog 的类型 添加add 修改edit
      type: 'add',
      // 设置 AddReminderDialog 的类型: 1关联司机, 2关联车辆
      reminderType: 1
    };
  },
  /* 	mounted() {
			window.onresize = function windowResize () {
				this.tableWidth = window.innerWidth + 'px';
			}
		}, */
  methods: {
    // Table - 计算过期时间
    expired (expiredTime) {
      let NowTime = Date.parse(new Date())
      return expiredTime - NowTime > 0 ? this.Local ? this.Local.prop('Asset.yes') : 'OK' : this.Local ? this.Local.prop('cust.Expired') : 'Expired'
    },
    expiredClass (expiredTime) {
      let NowTime = Date.parse(new Date())
      return expiredTime - NowTime > 0 ? 'OK' : 'Expired'
    },
    // Table - 获取表格数据异步请求
    getTableData () {
      // 清空数据
      // this.tableData = {}
      // 重新加载数据
      let keyword = this.formToSearch.keyword
      let phone = this.formToSearch.phone
      let registerPlace = this.formToSearch.registerPlace
      let licenseExpired = this.formToSearch.licenseExpired
      let pageSize = this.limitSize
      let pageNum = this.currentPage
      getDriverData(
        keyword,
        phone,
        registerPlace,
        licenseExpired,
        pageSize,
        pageNum
      )
        .then(res => {
          if (res.code === 0) {
            this.tableData = res.data
            this.loading = false
            return
          }
          // 根据 code 的值给出提示信息
          promptMessage.call(this, res.code)
        })
        .catch(e => {
          this.$message({
            message: this.Local
              ? this.Local.prop('Commands.Unknown_error')
              : 'Unknown error',
            center: true,
            type: 'error'
          })
        })
    },
    // Form - 表单提交
    onSubmit () {
      this.formToSearch.keyword = this.form.keyword
      this.formToSearch.phone = this.form.phone
      this.formToSearch.registerPlace = this.form.registerPlace
      this.formToSearch.licenseExpired = this.form.licenseExpired
      this.getTableData()
    },
    // Table - 单行编辑
    handleEdit (index, row) {
      this.type = 'edit'
      // 复制对象 避免造成影响
      this.currentSelectRow = JSON.parse(JSON.stringify(row))
      this.$refs.DriverDialog.show()
    },
    // Table - 单行删除
    tableRowsDelete (ids) {
      this.$confirm(
        this.Local
          ? this.Local.prop('comm.ConfirmDelete')
          : 'Confirm to delete it?',
        this.Local ? this.Local.prop('comm.Delete') : 'Delete',
        {
          confirmButtonText: this.Local
            ? this.Local.prop('comm.Delete')
            : 'Delete',
          cancelButtonText: this.Local
            ? this.Local.prop('index.Cancel')
            : 'Cancel'
        }
      )
        .then(() => {
          let id = ids[0]
          driverDelete(id)
            .then(res => {
              if (res.code === 0) {
                // 刷新表格
                this.getTableData()
              }
              // 根据 code 的值给出提示信息
              promptMessage.call(this, res.code)
            })
            .catch(e => {
              this.$message({
                message: this.Local
                  ? this.Local.prop('Commands.Unknown_error')
                  : 'Unknown error',
                center: true,
                type: 'error'
              })
            })
        })
        .catch(() => {
          // 取消
        })
    },
    // Table - 单行编辑 Reminder 信息
    handleReminderEdit (index, row) {
      // 复制对象 避免造成影响
      this.currentSelectRowToReminder = JSON.parse(JSON.stringify(row))
      this.$refs.AddReminderDialog.show()
    },
    // Table - 新增司机信息
    driverAdd () {
      this.type = 'add'
      this.currentSelectRow = {}
      this.$refs.DriverDialog.show()
    },
    // Table - 导出数据
    driverExport () {
      let keyword = this.form.keyword
      let phone = this.form.phone
      let registerPlace = this.form.registerPlace
      let licenseExpired = this.form.licenseExpired
      exportDriverData(keyword, phone, registerPlace, licenseExpired)
        .then(res => {
          if (res.code) {
            // 根据 code 的值给出提示信息
            promptMessage.call(this, res.code)
          }
        })
        .catch(e => {
          this.$message({
            message: this.Local
              ? this.Local.prop('Commands.Unknown_error')
              : 'Unknown error',
            center: true,
            type: 'error'
          })
        })
    }
  },
  components: {
    Header,
    Nav,
    DriverDialog,
    AddReminderDialog
  }
}
</script>

<style lang='less'>
.page-Driver {
  .main {
    form {
      display: inline-block;
      border-bottom: 1px solid #f3f3f3;
      width: 100%;
      .license-expired {
        .el-checkbox__label {
          display: inline-block;
          line-height: 40px;
          color: #868aa8;
          font-size: 14px;
        }
        .status-select {
          display: inline-block;
          width: 230px;
        }
      }
      .input-wrapper {
        display: inline-block;
        margin-bottom: 20px;
        float: left;
        height: 40px;
        padding: 0 10px;
        .el-input {
          width: 230px;
        }
      }
      .driverNo {
        padding-left: 0;
      }
      .search {
        width: 120px;
      }
    }
    .table-wrapper {
      margin: 20px 0 0 0;
      .btn-wrapper {
        display: block;
        width: 100%;
        height: 40px;
        label {
          float: left;
          margin-right: 20px;
          cursor: pointer;
          font-size: 14px;
          color: #868aa8;
          user-select: none;
          button {
            margin-right: 10px;
            padding: 6px;
            .icon-add,
            .icon-export {
              font-size: 12px;
            }
          }
        }
        label:hover {
          color: #ccc;
        }
      }
      .el-table__header-wrapper {
        display: flex;
        position: relative;
      }
      .el-table__body,
      .el-table__footer,
      .el-table__header {
        table-layout: auto !important;
      }
      .table {
        margin-top: 10px;
        width: 100%;
        table {
          width: 100% !important;
          // position: absolute;
        }
        .reminder-edit {
          border: 0px;
          background: none;
        }
        .edit {
          color: #00abff;
          cursor: pointer;
        }
        .btn-contorl {
          padding: 6px;
        }
        .OK,
        .Expired {
          font-size: 12px;
          padding: 0 15px;
          color: #fff;
          background: #ccc;
          height: 100%;
          display: inline-block;
        }
        .OK {
          background: #67c23a;
        }
        .Expired {
          background: #f56c6c;
        }
      }
      .pagination-wrapper {
        width: 100%;
        height: 40px;
        margin-top: 20px;
        .pagination {
          display: inline-block;
          float: right;
          font-size: 12px;
        }
        .total {
          padding: 0 4px;
          background: #fff;
          font-size: 13px;
          min-width: 35.5px;
          height: 28px;
          line-height: 28px;
          -webkit-box-sizing: border-box;
          box-sizing: border-box;
        }
      }
    }
  }
}
</style>
