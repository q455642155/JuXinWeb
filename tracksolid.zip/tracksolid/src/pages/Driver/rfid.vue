<template>
  <div class="page page-Driver">
    <Header/>
    <div class="body-wrapper">
      <Nav :active="active"/>
      <div class="main-wrapper">
        <h1>{{ this.Local ? this.Local.prop('Fleet.rfid') : 'RFID History' }}</h1>
        <div class="main">
          <form ref="form">
            <div class="input-wrapper cardId">
              <el-input
                :clearable="true"
                :maxlength="24"
                v-model.trim="form.cardId"
                :placeholder="Local ? Local.prop('Fleet.rfid.cardId') : 'Driver No./Driver Name'"
              ></el-input>
            </div>
            <div class="input-wrapper time">
              <el-date-picker
                v-model.trim="form.time"
                type="daterange"
                range-separator="-"
                value-format="yyyy-MM-dd"
                :start-placeholder="Local ? Local.prop('header.PositionStartTime') : 'Start Time'"
                :end-placeholder="Local ? Local.prop('header.PositionEndTime') : 'End Time'"
              ></el-date-picker>
            </div>
            <div class="input-wrapper search">
              <el-button
                type="primary"
                icon="el-icon-search"
                @click="onSubmit"
                round
              >{{ this.Local ? this.Local.prop('comm.Search') : 'Search' }}</el-button>
            </div>
          </form>
          <div class="table-wrapper">
            <div class="table">
              <el-table
                ref="multipleTable"
                :data="tableData.list"
                stripe
                fit
                tooltip-effect="dark"
                @selection-change="handleSelectionChange"
                @select-all="handleSelectAll"
                :empty-text="Local ? Local.prop('comm.noData') : 'No data found'"
                v-loading="loading"
                :element-loading-text="Local ? Local.prop('comm.loadingData') : 'Loading...'"
              >
                <el-table-column type="selection" width="40" align="center"></el-table-column>

                <el-table-column
                  type="index"
                  :label="Local ? Local.prop('Alert.number') : 'No.'"
                  :index="indexMethod"
                  width="50"
                  align="center"
                ></el-table-column>

                <el-table-column
                  prop="cardId"
                  :label="Local ? Local.prop('Fleet.rfid.cardId') : 'Card Id.'"
                ></el-table-column>

                <el-table-column
                  prop="imei"
                  :label="Local ? Local.prop('Asset.DeviceIMEI') : 'IMEI'"
                ></el-table-column>

                <el-table-column
                  prop="driverName"
                  :label="Local ? Local.prop('index.showDriveName') : 'Drive Name'"
                >
                  <template scope="scope">
                      <div style="color:#3399FF;cursor:pointer;" @click="getDriveInfo(scope.row)">{{ scope.row.driverName}}</div>
                  </template>
                </el-table-column>

                <el-table-column
                  prop="vehicleName"
                  :label="Local ? Local.prop('index.showVehicleName') : 'Vehicle Name'"
                >
                  <template scope="scope">
                      <div style="color:#3399FF;cursor:pointer;" @click="getDeviceInfo(scope.row)">{{ scope.row.vehicleName}}</div>
                  </template>
                </el-table-column>

                <el-table-column
                  prop="vehicleNumber"
                  :label="Local ? Local.prop('Asset.LicenceplateNum') : 'License Plate No.'"
                ></el-table-column>

                <el-table-column
                  :label="Local ? Local.prop('index.operationTime') : 'Operation Time'"
                >
                  <template slot-scope="scope">{{ timestampToTime(scope.row.creationDate, true) }}</template>
                </el-table-column>
              </el-table>
              <div class="pagination-wrapper">
                <span class="total">
                  {{ this.Local ? this.Local.prop('Fleet.Driver.Displaying') : 'Displaying' }}
                  {{ (currentPage-1) * limitSize}} - {{currentPage * limitSize }}
                  {{ this.Local ? this.Local.prop('Fleet.Driver.Of') : 'of' }}
                  {{ tableData.total }}
                  {{ this.Local ? this.Local.prop('Fleet.Driver.Records') : 'Records' }}
                </span>
                <el-pagination
                  class="pagination"
                  @current-change="handleCurrentChange"
                  layout="sizes, prev, pager, next"
                  @size-change="handleSizeChange"
                  :page-sizes="limitSizes"
                  :page-size="limitSize"
                  :total="tableData.total"
                  :current-page="tableData.pageNum"
                ></el-pagination>
              </div>
            </div>
          </div>
          <!--驾驶员信息-->
          <driver-dialog :visible-p.sync="dialogDriveVisible" ref="DriverDialog" :form="driveInfo" @refresh="getTableData()" :type="type"></driver-dialog>
          <!--车辆信息-->
          <vehicle-dialog :visible-v.sync="dialogVehicleVisible" ref="DriverDialog" :form="vehicleInfo" @refresh="getTableData()"></vehicle-dialog>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import Header from '@/components/Header'
import Nav from '@/components/Nav'
import DriverDialog from '@/components/RfidDialog/DriveIndex'
import VehicleDialog from '@/components/RfidDialog/VehicleIndex'
import { getRfidData } from '@/api/Driver/rfid'
import { promptMessage } from '@/common/js/common'
import { tableMixin } from '@/common/js/mixins'

export default {
  name: 'Driver',
  mixins: [tableMixin],
  data() {
    return {
      // 导航栏状态
      active: 3,
      // 搜索表单内容
      form: {
        cardId: null,
        time: null
      },
      formToSearch: {
        cardId: null,
        time: null
      },
      // 点击Reminder时表格当前正在操作的行
      currentSelectRowToReminder: {},
      type: 'add',
      driveInfo: {},
      vehicleInfo: {},
      dialogDriveVisible: false,
      dialogVehicleVisible: false
    }
  },
  methods: {
    // Table - 获取表格数据异步请求
    getTableData() {
      // // 清空数据
      // this.tableData = {}
      // 重新加载数据
      let cardId = this.formToSearch.cardId
      let startDate = this.formToSearch.time
        ? this.form.time[0] + ' 00:00:00'
        : null
      let endDate = this.formToSearch.time
        ? this.form.time[1] + ' 23:59:59'
        : null
      let pageSize = this.limitSize
      let pageNum = this.currentPage
      getRfidData(cardId, startDate, endDate, pageSize, pageNum)
        .then(res => {
          if (res.code === 0) {
            this.tableData = res.data
            this.loading = false
            return
          }
          // 根据 code 的值给出提示信息
          promptMessage.call(this, res.code)
        })
        .catch(e => {
          this.$message({
            message: this.Local
              ? this.Local.prop('Commands.Unknown_error')
              : 'Unknown error',
            center: true,
            type: 'error'
          })
        })
    },
    // 点击驾驶员名字弹出信息
    getDriveInfo(row) {
      this.dialogDriveVisible = true
      this.driveInfo = Object.assign({}, row)
    },
    // 点击设备名字弹出信息
    getDeviceInfo(row) {
      this.dialogVehicleVisible = true
      this.vehicleInfo = Object.assign({}, row)
    },
    // Form - 表单提交
    onSubmit() {
      this.formToSearch.cardId = this.form.cardId
      this.formToSearch.time = this.form.time
      this.getTableData()
    }
  },
  components: {
    Header,
    Nav,
    DriverDialog,
    VehicleDialog
  }
}
</script>

<style lang='less'>
.page-Driver {
  .main {
    form {
      display: inline-block;
      border-bottom: 1px solid #f3f3f3;
      width: 100%;
      .license-expired {
        .el-checkbox__label {
          display: inline-block;
          line-height: 40px;
          color: #868aa8;
          font-size: 14px;
        }
        .status-select {
          display: inline-block;
          width: 230px;
        }
      }
      .input-wrapper {
        display: inline-block;
        margin-bottom: 20px;
        float: left;
        height: 40px;
        padding: 0 10px;
        .el-input {
          width: 230px;
        }
      }
      .driverNo {
        padding-left: 0;
      }
      .search {
        width: 120px;
      }
    }
    .table-wrapper {
      margin: 20px 0 0 0;
      .btn-wrapper {
        display: block;
        width: 100%;
        height: 40px;
        label {
          float: left;
          margin-right: 20px;
          cursor: pointer;
          font-size: 14px;
          color: #868aa8;
          user-select: none;
          button {
            margin-right: 10px;
            padding: 6px;
            .icon-add,
            .icon-export {
              font-size: 12px;
            }
          }
        }
        label:hover {
          color: #ccc;
        }
      }
      // 表格缩小自适应
      .el-table__header-wrapper {
        display: flex;
        position: relative;
      }
      .el-table__body,
      .el-table__footer,
      .el-table__header {
        table-layout: auto !important;
      }
      .table {
        margin-top: 10px;
        width: 100%;
        table {
          width: 100% !important;
        }
        .reminder-edit {
          border: 0px;
          background: none;
        }
        .edit {
          color: #00abff;
          cursor: pointer;
        }
        .btn-contorl {
          padding: 6px;
        }
        .OK,
        .Expired {
          font-size: 12px;
          padding: 0 15px;
          color: #fff;
          background: #ccc;
          height: 100%;
          display: inline-block;
        }
        .OK {
          background: #67c23a;
        }
        .Expired {
          background: #f56c6c;
        }
      }
      .pagination-wrapper {
        width: 100%;
        height: 40px;
        margin-top: 20px;
        .pagination {
          display: inline-block;
          float: right;
          font-size: 12px;
        }
        .total {
          padding: 0 4px;
          background: #fff;
          font-size: 13px;
          min-width: 35.5px;
          height: 28px;
          line-height: 28px;
          -webkit-box-sizing: border-box;
          box-sizing: border-box;
        }
      }
    }
  }
}
</style>
