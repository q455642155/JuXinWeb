<template>
	<div class="page page-Vehicle">
		<Header />
		<div class="body-wrapper">
			<Nav :active="active" />
			<div class="main-wrapper">
				<h1>
					{{ this.Local ? this.Local.prop('Fleet.Vehicle.Vehicle') : 'Vehicle' }}
				</h1>
				<div class="main">
					<form ref="form">
						<div class="input-wrapper imei">
							<el-input :clearable=true :maxlength=24 v-model.trim="form.imei" :placeholder="Local ? Local.prop('Asset.DeviceIMEI') : 'IMEI'"></el-input>
						</div>
						<div class="input-wrapper plateNo">
							<el-input :clearable=true :maxlength=24 v-model.trim="form.plateNo" :placeholder="Local ? Local.prop('Fleet.Vehicle.VehicleNo') : 'Vehicle No.'"></el-input>
						</div>
						<div class="input-wrapper status">
							<span class="status-span">
									{{ this.Local ? this.Local.prop('Alert.status') : 'Status' }}
								</span>
							<el-select class="status-select" v-model="form.status" :placeholder="Local ? Local.prop('Alert.status') : 'Status'">
								<el-option v-for="item in statusOptions" :key="item.value" :label="item.label" :value="item.value" no-data-text="No data">
								</el-option>
							</el-select>
						</div>
						<div class="input-wrapper search">
							<el-button type="primary" icon="el-icon-search" @click="onSubmit" round>
								{{ this.Local ? this.Local.prop('comm.Search') : 'Search' }}
							</el-button>
						</div>
					</form>
					<div class="table-wrapper">
						<div class="btn-wrapper">
							<label>
									<el-button @click="vehicleAdd()" type="primary" size="mini" icon="icon-add" circle></el-button>
									{{ this.Local ? this.Local.prop('comm.Add') : 'Add' }}
								</label>
							<label>
									<el-button @click="vehicleExport()" type="primary" size="mini" icon="icon-export" circle></el-button>
									{{ this.Local ? this.Local.prop('header.ACCReport.export') : 'Export' }}
								</label>
							<form id="form" target="_blank" ref="linkForm" method="post">
								<input type="hidden" name="keyword" id="keyword" ref="imei">
								<input type="hidden" name="userId" id="userId" ref="userId">
							</form>
						</div>
						<div class="table">
							<el-table ref="multipleTable" :data="tableData.list" stripe fit tooltip-effect="dark" @selection-change="handleSelectionChange" @select-all="handleSelectAll" :empty-text="Local ? Local.prop('comm.noData') : 'No data found'" v-loading="loading" :element-loading-text="Local ? Local.prop('comm.loadingData') : 'Loading...'">
								<el-table-column width="40" align="center" type="selection">
								</el-table-column>
								<el-table-column width="50" align="center" type="index" :label="Local ? Local.prop('Alert.number') : 'No.'" :index="indexMethod">
	
								</el-table-column>
	
								<el-table-column prop="plateNo" :label="Local ? Local.prop('Fleet.Vehicle.VehicleNo') : 'Vehicle No.'">
	
								</el-table-column>
	
								<el-table-column prop="plateType" :label="Local ? Local.prop('Fleet.Vehicle.VehicleType') : 'Vehicle Type'">
								</el-table-column>
	
								<el-table-column prop="maxSpeed" :label="Local ? Local.prop('Fleet.Vehicle.MaxSpeed') : 'Max Speed'">
								</el-table-column>
	
								<el-table-column prop="deviceName" :label="Local ? Local.prop('Asset.DeviceName') : 'Device Name'">
								</el-table-column>
	
								<el-table-column prop="imei" :label="Local ? Local.prop('Fleet.Vehicle.DeviceIMEI') : 'Device IMEI'">
								<template slot-scope="scope">
									<a @click="jumpMonitor(scope.$index, scope.row)" class="link">{{scope.row.imei}}</a>
								</template>
								</el-table-column>
								<el-table-column
									:label="Local ? Local.prop('Alert.status') : 'Status'"
									align="center"
								>
<template slot-scope="scope">
	<span :class="scope.row.status === 1 ? 'status-Using' : 'status-Sold'">
												{{ scope.row.status === 1 ? (Local ? Local.prop('Fleet.Vehicle.Using') : 'Using') : (Local ? Local.prop('Fleet.Vehicle.Sold') : 'Sold') }}
											</span>
</template>
								</el-table-column>
								<el-table-column
								:label="Local ? Local.prop('Fleet.Driver.reminderStatus') : 'Remind Status'"
								align="center"
								>
								<template slot-scope="scope">
									<span :class="licenseStatusList[0].type" v-if="scope.row.reminderStatus === '0'">{{ licenseStatusList[0].text }}</span>
									<span :class="licenseStatusList[1].type" v-if="scope.row.reminderStatus === '1'">{{ licenseStatusList[1].text }}</span>
									<span :class="licenseStatusList[2].type" v-if="scope.row.reminderStatus === '2'">{{ licenseStatusList[2].text }}</span>
									<span :class="licenseStatusList[3].type" v-if="scope.row.reminderStatus === null">{{ licenseStatusList[3].text }}</span>
								</template>
								</el-table-column>
								<el-table-column
									:label="Local ? Local.prop('Fleet.Driver.Reminder') : 'Reminder'"
									align="center"
								>
<template slot-scope="scope">
	<el-button size="mini" class="reminder-edit" @click="handleReminderEdit(scope.$index, scope.row)">
		{{ Local ? Local.prop('Alert.edit') : 'Edit' }}
	</el-button>
</template>
								</el-table-column>
								<el-table-column
									:label="Local ? Local.prop('comm.Operate') : 'Actions'"
									align="center"
								>
<template slot-scope="scope">
	<el-button @click="handleEdit(scope.$index, scope.row)" class="btn-contorl" size="mini" type="success" icon="el-icon-edit" circle>
	</el-button>
	<el-button @click="handleDelete(scope.$index, scope.row)" class="btn-contorl" size="mini" type="danger" icon="el-icon-delete" circle></el-button>
</template>
								</el-table-column>
							</el-table>
							<div class="pagination-wrapper">
								<span class="total">
									{{ this.Local ? this.Local.prop('Fleet.Driver.Displaying') : 'Displaying' }} 
									{{ (currentPage-1) * limitSize}} - {{currentPage * limitSize }} 
									{{ this.Local ? this.Local.prop('Fleet.Driver.Of') : 'of' }} 
									{{ tableData.total }} 
									{{ this.Local ? this.Local.prop('Fleet.Driver.Records') : 'Records' }}
								</span>
								<el-pagination
									class="pagination"
									@current-change="handleCurrentChange"
									layout="sizes, prev, pager, next"
									@size-change="handleSizeChange"
									:page-sizes="limitSizes"
									:page-size="limitSize"
									:total="tableData.total"
									:current-page="tableData.pageNum"
								>
								</el-pagination>
							</div>
						</div>
					</div>
					<VehicleDialog ref="VehicleDialog" @refresh="getTableData()" :form="currentSelectRow" :btnType="btnType" />
					<AddReminderDialog 
						ref="AddReminderDialog" 
						:reminderType="reminderType" 
						:relationId="currentSelectRowToReminder.id"
						:imei="currentSelectRowToReminder.imei"
						@refresh="getTableData()"
					/>
				</div>
			</div>
		</div>
	</div>
</template>

<script type="text/ecmascript-6">
	import Header from '@/components/Header'
	import Nav from '@/components/Nav'
	import VehicleDialog from '@/components/VehicleDialog'
	import AddReminderDialog from '@/components/AddReminderDialog'
	import {
		getVehicleData,
		exportVehicleData,
		vehicleDelete,
		imeiLink
	} from '@/api/Vehicle'
	import {
		promptMessage
	} from '@/common/js/common'
	import {
		tableMixin
	} from '@/common/js/mixins'
	import {
		GO_BACK_URL, URL
	} from '@/config/index'
	
	export default {
		name: 'Vehicle',
		mixins: [
			tableMixin
		],
		data() {
			return {
				// 导航栏状态
				active: 2,
				// 搜索表单内容
				form: {
					imei: '',
					plateNo: '',
					status: 0,
				},
				// 记录搜索时表格的搜索条件
				formToSearch: {
					imei: '',
					plateNo: '',
					status: 0
				},
				// 搜索表单下 status 多选框选项
				statusOptions: [{
						value: 0,
						label: this.Local ? this.Local.prop('index.all') : 'All'
					},
					{
						value: 1,
						label: this.Local ? this.Local.prop('Fleet.Vehicle.Using') : 'Using'
					},
					{
						value: 2,
						label: this.Local ? this.Local.prop('Fleet.Vehicle.Sold') : 'Sold'
					}
				],
				// 点击Reminder时表格当前正在操作的行
				currentSelectRowToReminder: {},
				// 设置 AddReminderDialog 的类型: 1关联司机, 2关联车辆
				reminderType: 2,
				btnType: '',
				licenseStatusList: [
					{
					'type':'OK',
					'text':'OK'
					},
					{
					'type':'Waiting',
					'text':'Waiting'
					},
					{
					'type':'Delayed',
					'text':'Delayed'
					},
					{
					'type':'NA',
					'text':'N/A'
					}
				]
				// imei跳转提交的参数
			/* 	sendFormLink: {
					keyword: null,
					userId: null,
				}, */
			}
		},
		methods: {
			// Table - 获取表格数据异步请求
			getTableData() {
				// 清空数据
				// this.tableData = {}
				// 重新加载数据
				let imei = this.formToSearch.imei
				let plateNo = this.formToSearch.plateNo
				let status = this.formToSearch.status
				let pageSize = this.limitSize
				let pageNum = this.currentPage
				this.loading = true
				getVehicleData(imei, plateNo, status, pageSize, pageNum).then((res) => {
					if (res.code === 0) {
						this.tableData = res.data
						this.loading = false
						return
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this, res.code)
				}).catch((e) => {
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
				})
			},
			// Form - 表单提交
			onSubmit() {
				// 记录搜索时表格的搜索条件
				this.formToSearch.imei = this.form.imei
				this.formToSearch.plateNo = this.form.plateNo
				this.formToSearch.status = this.form.status
				this.getTableData()
			},
			// Table - 新增司机信息
			vehicleAdd() {
				this.currentSelectRow = {}
				this.btnType = 'add' // 添加信息的时候不去调用相关的接口
				this.$refs.VehicleDialog.show()
			},
			// Table - 导出数据
			vehicleExport() {
				let imei = this.form.imei
				let plateNo = this.form.plateNo
				let status = this.form.status
	
				exportVehicleData(imei, plateNo, status).then((res) => {
					if (res.code) {
						// 根据 code 的值给出提示信息
						promptMessage.call(this, res.code)
					}
				}).catch((e) => {
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
				})
			},
			// Table - 单行编辑 Reminder 信息
			handleReminderEdit(index, row) {
				// 复制对象 避免造成影响
				this.currentSelectRowToReminder = JSON.parse(JSON.stringify(row))
				this.$refs.AddReminderDialog.show()
			},
			// Table - 单行删除
			tableRowsDelete(ids) {
				if (ids.length) {
					this.$confirm(this.Local ? this.Local.prop('comm.ConfirmDelete') : 'Confirm to delete it?', this.Local ? this.Local.prop('comm.Delete') : 'Delete', {
						confirmButtonText: this.Local ? this.Local.prop('comm.Delete') : 'Delete',
						cancelButtonText: this.Local ? this.Local.prop('index.Cancel') : 'Cancel',
					}).then(() => {
						// 确认删除
						let id = ids[0]
						vehicleDelete(id).then((res) => {
							if (res.code === 0) {
								this.ids = []
								this.getTableData()
							}
							// 根据 code 的值给出提示信息
							promptMessage.call(this, res.code)
						}).catch((e) => {
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							});
						})
					}).catch(() => {
						// 取消         
					});
				}
			},
			// Table - 单行编辑
			handleEdit(index, row) {
				// 复制对象 避免造成影响
				this.currentSelectRow = JSON.parse(JSON.stringify(row))
				this.btnType = 'edit' // 编辑信息的时候才去调用相关的接口
				this.$refs.VehicleDialog.show()
			},
	
			// 跳转到monitor界面
			jumpMonitor(index, row) {
				this.currentSelectRow = JSON.parse(JSON.stringify(row))
				let form = this.$refs.linkForm
				document.getElementById("keyword").value  = this.currentSelectRow.imei
				document.getElementById("userId").value  =  this.currentSelectRow.imeiUserId
				// 新增判断
				var n = (URL.split(':')).length - 1
				if (n > 1) {
					form.action = URL.slice(0, URL.lastIndexOf(':')) + '/console'
				} else {
					if (URL.lastIndexOf(':') > 5) {
						form.action = URL.slice(0, URL.lastIndexOf(':')) + '/console'
					} else {
						form.action = URL.split('/fleet').join('')+ '/console'
					}
				}
				// form.action = URL.split('/fleet').join('')+ '/console'
				form.submit()
			}
		},
		components: {
			Header,
			Nav,
			VehicleDialog,
			AddReminderDialog
		}
	}
</script>

<style lang='less'>
	.page-Vehicle {
		.main {
			form {
				display: inline-block;
				border-bottom: 1px solid #f3f3f3;
				width: 100%;
				.status {
					.status-span {
						display: inline-block;
						padding-right: 10px;
						line-height: 40px;
						color: #868aa8;
						font-size: 14px;
					}
					.status-select {
						display: inline-block;
						width: 230px;
					}
				}
				.input-wrapper {
					display: inline-block;
					margin-bottom: 20px;
					float: left;
					height: 40px;
					padding: 0 10px;
					.el-input {
						width: 230px;
					}
				}
				.imei {
					padding-left: 0;
				}
				.search {
					width: 120px;
				}
			}
			.table-wrapper {
				margin: 20px 0 0 0;
				.btn-wrapper {
					display: block;
					width: 100%;
					height: 40px;
					label {
						float: left;
						margin-right: 20px;
						cursor: pointer;
						font-size: 14px;
						color: #868aa8;
						user-select: none;
						button {
							margin-right: 10px;
							padding: 6px;
							.icon-add,
							.icon-export {
								font-size: 12px;
							}
						}
					}
					label:hover {
						color: #ccc;
					}
				}
				// 表格缩小自适应
				.el-table__header-wrapper {
					display: flex;
					position: relative;
				}
				.el-table__body,
				.el-table__footer,
				.el-table__header {
					table-layout: auto!important;
				}
				table {
					width: 100% !important;
				}
				.table {
					margin-top: 10px;
					.edit {
						color: #00abff;
						cursor: pointer;
					}
					.reminder-edit {
						border: 0px;
						background: none;
					}
					.btn-contorl {
						padding: 6px;
					}
					.status-Using {
						font-size: 12px;
						padding: 0 15px;
						background: #67C238;
						display: inline-block;
						color: #fff;
					}
					.status-Sold {
						font-size: 12px;
						padding: 0 15px;
						background: #f56c6c;
						display: inline-block;
						color: #fff;
					}
					.OK,
					.Waiting,
					.Delayed {
						font-size: 12px;
						padding: 0 15px;
						color: #fff;
						background: #ccc;
						height: 100%;
						display: inline-block;
					}
					.NA{
						color:#000;
					}
					.OK {
					background: #67c23a;
					width: 50px;
					}
					.Waiting {
					background: #FF8F1B;
					width: 50px;
					}
					.Delayed {
					background: #FF0000;
					width: 50px;
					}
					.link {
						cursor: pointer;
						color: blue;
					}
				}
				.pagination-wrapper {
					width: 100%;
					height: 40px;
					margin-top: 20px;
					.pagination {
						display: inline-block;
						float: right;
						font-size: 12px;
					}
					.total {
						padding: 0 4px;
						background: #fff;
						font-size: 13px;
						min-width: 35.5px;
						height: 28px;
						line-height: 28px;
						-webkit-box-sizing: border-box;
						box-sizing: border-box;
					}
				}
			}
		}
	}
</style>