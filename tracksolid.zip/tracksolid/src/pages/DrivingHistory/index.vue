<template>
	<div class="page page-DrivingHistory">
		<Header />
		<div class="body-wrapper">
			<Nav :active="active" />
			<div class="main-wrapper">
				<h1>{{ this.Local ? this.Local.prop('Fleet.drivingHistory') : 'Driving History' }}</h1>
				<div class="main">
					<el-row :gutter="10">
						<el-col :xl="8" :lg="10" :md="10" :sm="10">
							<div class="table-wrapper">
								<div class="btn-wrapper">
									<label>
										<el-button v-popover:noticeInfo type="primary" @click="addDevice" size="mini" icon="icon-add" circle>
										</el-button>
										{{ this.Local ? this.Local.prop('comm.Add') : 'Add' }}
										<el-popover
											ref="noticeInfo"
											placement="right-start"
											width="200"
											trigger="click">
											{{this.Local ? this.Local.prop('Fleet.choose') : 'Right of the map choose two dots to add it'}}
										</el-popover>
									</label>
									<label>
										<el-button type="primary" @click="removeInfo()" size="mini" icon="el-icon-delete" circle>
										</el-button>
										{{ this.Local ? this.Local.prop('Asset.Delete') : 'Delete' }}
									</label>
								</div>
								<div class="table">
									<el-table
										ref="multipleTable"
										:data="tableData.list"
										stripe
										fit
										tooltip-effect="dark"
										:empty-text="Local ? Local.prop('comm.noData') : 'No data found'"
										v-loading="loading"
										:element-loading-text="Local ? Local.prop('comm.loadingData') : 'Loading...'"
										element-loading-background="rgba(0, 0, 0, 0.8)"
									>
									<el-table-column
										width="30"
										align="center"
									>
									<template slot-scope="scope">
										<el-radio class="radio" v-model="radio" :label="scope.$index" @change.native="selectRow(scope.$index, scope.row)"></el-radio>
									</template>
									</el-table-column>
									<el-table-column
										prop="pathName"
										width="200"
										align="center"
										:label="Local ? Local.prop('Alert.number') : 'Name'"
									>
									</el-table-column>
									<el-table-column
										:label="Local ? Local.prop('comm.Operate') : 'Actions'"
										align="center"
									>
										<template slot-scope="scope">
											<el-dropdown placement="bottom-start" trigger="click">
												<i class="fa fa-cog set"></i>
												<el-dropdown-menu slot="dropdown">
													<el-dropdown-item><p class="text" @click="editInfo(scope.$index, scope.row)">{{Local ? Local.prop("Asset.Edit") : 'Edit'}}</p></el-dropdown-item>
													<el-dropdown-item><p class="text" @click="deleteInfo(scope.$index, scope.row)">{{Local ? Local.prop("Asset.Delete") : 'Delete'}}</p></el-dropdown-item>
													<el-dropdown-item><p class="text" @click="Assign(scope.$index, scope.row)">{{Local ? Local.prop("Geozones.linkdevice") : 'Assign Device'}}</p></el-dropdown-item>
												</el-dropdown-menu>
											</el-dropdown>
											<!-- <el-popover :ref="scope.row.id" placement="right" width="70" trigger="click">
												<p class="text" @click="editInfo(scope.$index, scope.row)">{{Local ? Local.prop("Asset.Edit") : 'Edit'}}</p>
												<p class="text" @click="deleteInfo(scope.$index, scope.row)">{{Local ? Local.prop("Asset.Delete") : 'Delete'}}</p>
												<p class="text" @click="deleteInfo(scope.$index, scope.row)">{{Local ? Local.prop("Geozones.linkdevice") : 'Assign Device'}}</p>	
											</el-popover> -->
										</template>
									</el-table-column>

									</el-table>

									<div class="pagination-wrapper">
										<!-- <span class="total">
											{{ this.Local ? this.Local.prop('Fleet.Driver.Displaying') : 'Displaying' }} 
											{{ (currentPage-1) * limitSize}} - {{currentPage * limitSize }} 
											{{ this.Local ? this.Local.prop('Fleet.Driver.Of') : 'of' }} 
											{{ tableData.total }} 
											{{ this.Local ? this.Local.prop('Fleet.Driver.Records') : 'Records' }}
										</span> -->
										<el-pagination
										class="pagination"
										@current-change="handleCurrentChange"
										layout="prev, pager, next"
										@size-change="handleSizeChange"
										:page-sizes="limitSizes"
										:page-size="limitSize"
										:total="tableData.total"
										:current-page="tableData.pageNum"
										></el-pagination>
									</div>

								</div>
							</div>
						</el-col>
						<el-col :xl="16" :lg="14" :md="14" :sm="14">
							<div id="map" style="width:100%;height:700px;"></div>
						</el-col>
					</el-row>
				</div>
			</div>
		</div>
		<!--添加-->
		<add-dialog ref="editDialog" :visible-p.sync="dialogAddVisible" :latDetail="latDetails" @clearMap="clearMap" @refresh="getTableData()"></add-dialog>
		<!--编辑-->
		<edit-dialog ref="editDialog" :visible-p.sync="dialogEditVisible" :form="details" :latDetail="latDetails" @clearMap="clearMap" @refresh="getTableData()"></edit-dialog>
		<!--关联设备-->
		<assign-device ref="relationDevice" :visible-p.sync="dialogAssignVisible" @refresh="getTableData()"></assign-device>
	</div>
</template>

<script type="text/ecmascript-6">
	import Header from '@/components/Header'
	import Nav from '@/components/Nav'
	import AddDialog from '@/components/DriveHistory/AddDialog.vue'
	import EditDialog from '@/components/DriveHistory/EditDialog.vue'
	import AssignDevice from '@/components/DriveHistory/AssignDevice.vue'
	import { promptMessage } from '@/common/js/common'
	import { tableMixin } from '@/common/js/mixins'
	import {getRouteInfo, deleteRoute} from '@/api/Drivehistory/index.js'
	export default {
		name: 'DrivingHistory',
		mixins: [
			tableMixin
		],
		data() {
			return {
				// 导航栏状态
				active: 4,
				radio: '',
				dialogAddVisible: false, // 添加弹框
				dialogEditVisible: false, // 编辑弹框
				dialogAssignVisible: false, // 关联设备
				details: {}, // 编辑详情
				latDetails: [],
				// 初始化地图的中心坐标
				initLat: {
					lat: 32.565449, 
					lng: 102.711364
				},
				routeList: [],
				mapList: [],
				deviceList: [], // 判断删除设备是是否有选中
				addNote: false
			}
		},
		mounted() {
			this.initMap() // 初始化地图
		},
		methods: {
			// 获取数据
			getTableData() {
				let pageSize = this.limitSize
				let pageNum = this.currentPage
				getRouteInfo(
					pageSize,
					pageNum
				).then(res => {
					if (res.code === 0) {
						this.tableData = res.data
						this.loading = false
						return
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this, res.code)
				}).catch(e => {
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					})
				})
			},
			// 删除路径信息
			removeInfo(){
				if (this.routeList.length === 0) {
					this.$alert(this.Local ? this.Local.prop('Geozones.Places') : 'Please select the record you want to delete!', this.Local ? this.Local.prop('comm.Information') : 'information', {
						confirmButtonText: this.Local ? this.Local.prop('Asset.yes') : 'OK'
					});
				} else {
					var id = this.routeList[0].id
					deleteRoute(id).then(res => {
						if (res.code) {
							// 根据 code 的值给出提示信息
							promptMessage.call(this, res.code)
						}
					}).catch(err => {
						this.$message({
							message: this.Local
							? this.Local.prop('Commands.Unknown_error')
							: 'Unknown error',
							center: true,
							type: 'error'
						})
					})
				}
			},
			// 初始化地图
			initMap() {
				var myLatLng = this.initLat
				var map = new google.maps.Map(document.getElementById('map'), {
					zoom: 8,
					center: myLatLng,
					mapTypeId:google.maps.MapTypeId.ROADMAP
				})
			},
			// 点击添加按钮添加设备
			addDevice(){
				this.addNote = true
				this.radio = ''
				this.addShowMap()
			},
			// 添加设备显示标记路线
			addShowMap(){
				var that = this
				var map = null
				var poly = null
				var myLatLng = this.initLat
				var newArr = []
				map = new google.maps.Map(document.getElementById('map'), {
					zoom: 8,
					center: myLatLng,
					mapTypeId:google.maps.MapTypeId.ROADMAP
				})
				var poly = new google.maps.Polyline({
					strokeColor: '#f00',
					strokeOpacity: 1.0,
					strokeWeight: 3
				})
				poly.setMap(map)
				if(this.addNote == true) {
					map.addListener('click', function(event){
						var path = poly.getPath();
						path.push(event.latLng);
						var marker = new google.maps.Marker({
							position: event.latLng,
							title: '#' + path.getLength(),
							map: map
						})
						var obj={}
						var left = marker.getPosition().lat()
						var top = marker.getPosition().lng()
						obj["lat"] = left
						obj["lng"] = top
						newArr.push(obj)
						if(newArr.length > 1) {
							that.dialogAddVisible = true
							that.latDetails = newArr // 把坐标传到子组件
						}
					})
				}
			},
			// 单选设备显示路线图
			selectRow(index, row) {
				this.radio = this.tableData.list.indexOf(row)
				this.deviceList.push(row)
				this.selectShowMap(row.pathJson)
			},
			// 点击设备列表显示路线
			selectShowMap(mapData){
				var myLatLng = this.initLat
				var that = this
				var directionsService = new google.maps.DirectionsService
				var directionsDisplay = new google.maps.DirectionsRenderer()
				if (mapData && mapData.length > 0) {
					var source = mapData[0].lat +','+mapData[0].lng
					var destination = mapData[mapData.length-1].lat +','+mapData[mapData.length-1].lng
				}
				var map = new google.maps.Map(document.getElementById('map'), {
					zoom: 8,
					center: new google.maps.LatLng(39.915, 116.404),
					mapTypeId:google.maps.MapTypeId.ROADMAP
				})
				directionsDisplay.setMap(map)
				directionsService.route({
					origin: source,
					destination: destination,
					travelMode:google.maps.TravelMode.DRIVING
				}, function(response, status){
					if (status == google.maps.DirectionsStatus.OK) {
						directionsDisplay.setDirections(response)
					} else {
						that.$message({
							type: 'error',
							message: this.Local ? this.Local.prop('Alert.RouteMessage') : 'No route found'
						})
					}
				})
			},
			// 编辑
			editInfo(index, row) {
				this.radio = ''
				if(this.$refs.editDialog) {
					this.$refs.editDialog.clearInputValidate()
				}
				this.details = Object.assign({}, row)
				this.dialogEditVisible = true
				this.editShowMap(row.points)
			},
			// 编辑设备修改路线
			editShowMap(mapData) {
				var myLatLng = this.initLat
				var that = this
				var directionsService = new google.maps.DirectionsService
				var directionsDisplay = new google.maps.DirectionsRenderer({ 'draggable': true })
				if (mapData && mapData.length > 0) {
					var source = mapData[0].lat +','+mapData[0].lng
					var destination = mapData[mapData.length-1].lat +','+mapData[mapData.length-1].lng
				}
				var map = new google.maps.Map(document.getElementById('map'), {
					zoom: 8,
					center: new google.maps.LatLng(39.915, 116.404),
					mapTypeId:google.maps.MapTypeId.ROADMAP
				})
				console.log(directionsDisplay)
				// google.maps.event.addListener('dragend',function(){})
				directionsDisplay.setMap(map)
				// 显示路线
				directionsService.route({
					origin: source,
					destination: destination,
					travelMode:google.maps.TravelMode.DRIVING
				}, function(response, status){
					if (status == google.maps.DirectionsStatus.OK) {
						directionsDisplay.setDirections(response)
						that.dialogEditVisible = true
						google.maps.event.addListener(mapData[0], 'dragend',function(event){
							console.log(1111)
						})
					} else {
						that.$message({
							type: 'error',
							message: 'No route found'
						})
					}
				})
				
			},
			// 单行删除路径信息
			deleteInfo(index, row) {
				var id = row.id
				deleteRoute(id).then(res => {
					if (res.code) {
						// 根据 code 的值给出提示信息
						promptMessage.call(this, res.code)
					}
				}).catch(err => {
					this.$message({
						message: this.Local
						? this.Local.prop('Commands.Unknown_error')
						: 'Unknown error',
						center: true,
						type: 'error'
					})
				})
			},
			// 关联设备
			Assign(index, row) {
				this.radio = ''
				this.dialogAssignVisible = true
				this.$refs.relationDevice.openDeviceModal(row.id)
			},
			// 清除地图
			clearMap (){
				this.initMap()
				this.mapList = []
				this.radio = ''
				this.marker = null
				if(this.$refs.editDialog) {
					this.$refs.editDialog.clearInputValidate()
				}
			}
		},
		components: {
			Header,
			Nav,
			AddDialog,
			EditDialog,
			AssignDevice
		}
	}
</script>

<style lang='less'>
	.page-DrivingHistory {
		.main {
			min-height: 700px;
			height: 700px;
			form {
				display: inline-block;
				border-bottom: 1px solid #f3f3f3;
				width: 100%;
				.license-expired {
					.el-checkbox__label {
						display: inline-block;
						line-height: 40px;
						color: #868aa8;
						font-size: 14px;
					}
					.status-select {
						display: inline-block;
						width: 230px;
					}
				}
				.input-wrapper {
					display: inline-block;
					margin-bottom: 20px;
					float: left;
					height: 40px;
					padding: 0 10px;
					.el-input {
						width: 230px;
					}
				}
				.driverNo {
					padding-left: 0;
				}
				.search {
					width: 120px;
				}
			}
			.table-wrapper {
				margin: 20px 0 0 0;
				.btn-wrapper {
					display: block;
					width: 100%;
					height: 40px;
					label {
						float: left;
						margin-right: 20px;
						cursor: pointer;
						font-size: 14px;
						color: #868aa8;
						user-select: none;
						button {
							margin-right: 10px;
							padding: 6px;
							.el-icon-delete, .icon-add {
								font-size: 12px;
							}
						}
					}
					label:hover {
						color: #ccc;
					}
				}
			}
			.table {
				margin-top: 10px;
				width: 100%;
				.text {
					line-height: 30px;
					cursor: pointer;
				}
				.set {
					color: #3399FF;
				}
				table {
					width: 100% !important;
					.btn-contorl {
						padding: 6px;
					}
					.on, .off {
						font-size: 12px;
						width: 100px;
						color: #fff;
						background: #ccc;
						height: 100%;
						display: inline-block;
					}
					.on {
						background: #67c23a;
					}
					.off {
						background: #f56c6c;
					}
				}
				.pagination-wrapper {
					width: 100%;
					height: 40px;
					margin-top: 20px;
					.pagination {
						display: inline-block;
						float: right;
						font-size: 12px;
					}
					.total {
						padding: 0 4px;
						background: #fff;
						font-size: 13px;
						min-width: 35.5px;
						height: 28px;
						line-height: 28px;
						-webkit-box-sizing: border-box;
						box-sizing: border-box;
					}
				}
			}
		}
	}
</style> 
 