<template>
	<div class="page page-DrivingHistory">
		<Header />
		<div class="body-wrapper">
			<Nav :active="active" />
			<div class="main-wrapper">
				<h1>Driving History</h1>
				<div class="main">
					<form ref="form">
						<div class="input-wrapper driverNo">
							<el-input :clearable=true :maxlength=24 v-model.trim="form.driverName" :placeholder="Local ? Local.prop('Fleet.Driver.DriverNo') + '/' + Local.prop('Asset.Drivername') : 'Driver No./Driver Name'"></el-input>
						</div>
						<div class="input-wrapper phone">
							<el-input :clearable=true :maxlength=24  v-model.trim="form.phone" :placeholder="Local ? Local.prop('Fleet.Driver.Phone') : 'Phone'"></el-input>
						</div>
						<div class="input-wrapper search">
							<el-button type="primary" icon="el-icon-search" @click="onSubmit" round>
								{{ this.Local ? this.Local.prop('comm.Search') : 'Search' }}
							</el-button>
						</div>
					</form>

					<div class="table-wrapper">
						<div class="btn-wrapper">
							<label>
								<el-button type="primary" size="mini" icon="el-icon-delete" circle>
								</el-button>
								{{ this.Local ? this.Local.prop('Asset.Delete') : 'Delete' }}
							</label>
							<label>
								<el-button type="primary" size="mini" icon="icon-export" circle>
								</el-button>
								{{ this.Local ? this.Local.prop('header.ACCReport.export') : 'Export' }}
							</label>
						</div>
							<div class="table">
								<el-table
									ref="multipleTable"
									:data="tableData.list"
									stripe
									fit
									tooltip-effect="dark"
									@selection-change="handleSelectionChange"
									@select-all="handleSelectAll"
									:empty-text="Local ? Local.prop('comm.noData') : 'No data found'"
									v-loading="loading"
									:element-loading-text="Local ? Local.prop('comm.loadingData') : 'Loading...'"
									element-loading-background="rgba(0, 0, 0, 0.8)"
								>
								<el-table-column
									width="40"
									align="center"
									type="selection"
								>
								</el-table-column>
								<el-table-column
									type="index"
									width="50"
									align="center"
									:label="Local ? Local.prop('Alert.number') : 'No.'"
									:index="indexMethod"
								>
								</el-table-column>
								<el-table-column
									:label="Local ? Local.prop('') : 'Driving Time'"
								>
									<template slot-scope="scope">
										{{ timestampToTime(scope.row.drivingTime,true) }}
									</template>
								</el-table-column>

								<el-table-column
									prop="driverNo"
									:label="Local ? Local.prop('Fleet.Driver.DriverNo') : 'Driver No.'"
								>
								</el-table-column>

								<el-table-column
									prop="driverName"
									:label="Local ? Local.prop('Asset.Drivername') : 'Driver Name'"
								>
								</el-table-column>

								<el-table-column
									prop="vehicleNo"
									:label="Local ? Local.prop('Asset.Drivername') : 'Vehicle No.'"
								>
								</el-table-column>

								<el-table-column
									width="15%"
									prop="deviceIMEI"
									:label="Local ? Local.prop('Asset.Drivername') : 'Device IMEI'"
								>
								</el-table-column>

								<el-table-column
									prop="deviceName"
									:label="Local ? Local.prop('Asset.Drivername') : 'Device Name'"
								>
								</el-table-column>

								<el-table-column
									:label="Local ? Local.prop('Fleet.Driver.LicenseStatus') : 'Engine Status'"
									align="center"
								>
									<template slot-scope="scope">
										<span :class="{ 'on': scope.row.engineStatus == 'On', 'off': scope.row.engineStatus == 'Off'}"> 
											{{ scope.row.engineStatus }}
										</span> 
									</template>
								</el-table-column>

								<el-table-column
									:label="Local ? Local.prop('comm.Operate') : 'Actions'"
									align="center"
								>
									<template slot-scope="scope">
										<el-button class="btn-contorl" size="mini" type="success" icon="el-icon-edit" circle></el-button>
  										<el-button class="btn-contorl" size="mini" type="danger" icon="el-icon-delete" circle></el-button>
									</template>
								</el-table-column>

							</el-table>

							<div class="pagination-wrapper">
								<span class="total">
									{{ this.Local ? this.Local.prop('Fleet.Driver.Displaying') : 'Displaying' }} 
									{{ (currentPage-1) * limitSize}} - {{currentPage * limitSize }} 
									{{ this.Local ? this.Local.prop('Fleet.Driver.Of') : 'of' }} 
									{{ tableData.total }} 
									{{ this.Local ? this.Local.prop('Fleet.Driver.Records') : 'Records' }}
								</span>
								<el-pagination
									class="pagination"
									@current-change="handleCurrentChange"
									layout="sizes, prev, pager, next"
									@size-change="handleSizeChange"
									:page-sizes="limitSizes"
									:page-size="limitSize"
									:total="tableData.total"
									:current-page="tableData.pageNum"
								>
								</el-pagination>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script type="text/ecmascript-6">
	import Header from '@/components/Header'
	import Nav from '@/components/Nav'
	import { promptMessage } from '@/common/js/common'
	import { tableMixin } from '@/common/js/mixins'

	export default {
		name: 'DrivingHistory',
		mixins: [
			tableMixin
		],
		data() {
			return {
				// 导航栏状态
				active: 3,
				// 搜索表单内容
				form: {
					driverName: null,
					phone: null,
				},
				form2: {
					driverName: null,
					phone: null,
				}
			}
		},
		mounted() {
			this.getTableData()
		},
		methods: {
			getTableData() {
				this.tableData = {
					list: [
						{
							drivingTime: 1527984011000,
							driverNo: '654322å',
							driverName: 'darcy',
							vehicleNo: '粤-123456',
							deviceIMEI: '351609080261350',
							deviceName: 'sanny',
							engineStatus: 'On',
						},
						{
							drivingTime: 1527742311000,
							driverNo: 8226927,
							driverName: 'pipi',
							vehicleNo: '闽-456789',
							deviceIMEI: '201711079999988',
							deviceName: 'kiki',
							engineStatus: 'Off',
						}
					],
					total: 2,
					pageNum: 1,
				}
			},
			onSubmit() {
				this.form2.driverName = this.form.driverName
				this.form2.phone = this.form.phone
			},
		},
		components: {
			Header,
			Nav,
		}
	}
</script>

<style lang='less'>
	.page-DrivingHistory {
		.main {
			form {
				display: inline-block;
				border-bottom: 1px solid #f3f3f3;
				width: 100%;
				.license-expired {
					.el-checkbox__label {
						display: inline-block;
						line-height: 40px;
						color: #868aa8;
						font-size: 14px;
					}
					.status-select {
						display: inline-block;
						width: 230px;
					}
				}
				.input-wrapper {
					display: inline-block;
					margin-bottom: 20px;
					float: left;
					height: 40px;
					padding: 0 10px;
					.el-input {
						width: 230px;
					}
				}
				.driverNo {
					padding-left: 0;
				}
				.search {
					width: 120px;
				}
			}
			.table-wrapper {
				margin: 20px 0 0 0;
				.btn-wrapper {
					display: block;
					width: 100%;
					height: 40px;
					label {
						float: left;
						margin-right: 20px;
						cursor: pointer;
						font-size: 14px;
						color: #868aa8;
						user-select: none;
						button {
							margin-right: 10px;
							padding: 6px;
							.el-icon-delete, .icon-export {
								font-size: 12px;
							}
						}
					}
					label:hover {
						color: #ccc;
					}
				}
			}
			.table {
				margin-top: 10px;
				width: 100%;
				table {
					width: 100% !important;
					.btn-contorl {
						padding: 6px;
					}
					.on, .off {
						font-size: 12px;
						width: 100px;
						color: #fff;
						background: #ccc;
						height: 100%;
						display: inline-block;
					}
					.on {
						background: #67c23a;
					}
					.off {
						background: #f56c6c;
					}
				}
				.pagination-wrapper {
					width: 100%;
					height: 40px;
					margin-top: 20px;
					.pagination {
						display: inline-block;
						float: right;
						font-size: 12px;
					}
					.total {
						padding: 0 4px;
						background: #fff;
						font-size: 13px;
						min-width: 35.5px;
						height: 28px;
						line-height: 28px;
						-webkit-box-sizing: border-box;
						box-sizing: border-box;
					}
				}
			}
		}
	}
</style> 