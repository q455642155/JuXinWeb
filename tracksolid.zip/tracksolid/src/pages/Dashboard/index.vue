<template>
  <div class="page page-chart">
    <Header/>
    <div class="body-wrapper">
      <Nav :active="active"/>
      <div class="main-wrapper">
        <h1>{{ this.Local ? this.Local.prop('header.Dashboard') : 'Dashboard' }}</h1>
        <!--DATA overview-->
        <over-view></over-view>
        <section class="section">
          <el-row :gutter="10">
            <!--Top Fuel Consumption Units-->
            <el-col :xl="16" :lg="14" :md="14" :sm="14">
              <fuel-consump></fuel-consump>
            </el-col>
            <!--task-->
            <el-col :xl="8" :lg="10" :md="14" :sm="10">
              <task></task>
            </el-col>
          </el-row>
        </section>
        <section class="section">
          <el-row :gutter="10">
            <!--Top Mileage Drived Units-->
            <el-col :xl="16" :lg="14" :md="14" :sm="14">
              <drive-mile></drive-mile>
            </el-col>
            <!--Driving Behavior Ratings-->
            <el-col :xl="8" :lg="10" :md="10" :sm="10">
              <drive-behavior></drive-behavior>
            </el-col>
          </el-row>
        </section>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import Header from "@/components/Header";
import Nav from "@/components/Nav";
import OverView from "@/components/Dashboard/OverView";
import FuelConsump from "@/components/Dashboard/FuelConsump";
import Task from "@/components/Dashboard/Task";
import DriveMile from "@/components/Dashboard/DriveMile";
import DriveBehavior from "@/components/Dashboard/DriveBehavior";
export default {
  data() {
    return {
      // 导航栏状态
      active: 0
    };
  },
  components: {
    Header,
    Nav,
    OverView,
    FuelConsump,
    Task,
    DriveMile,
    DriveBehavior
  },
  methods: {}
};
</script>

<style lang='less'>
.section {
  margin-top: 20px;
  .task {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
</style>

