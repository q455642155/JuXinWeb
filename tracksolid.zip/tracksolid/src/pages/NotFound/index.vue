<template>
  <div class="page page-NotFound">
    <div class="main">
      <div class="des-wrapper">
        <img src="@/common/images/404.png">
        <p
          class="des"
        >{{ this.Local ? this.Local.prop('error.messageyi') : 'This page does not exist or has been deleted.' }}</p>
        <p
          class="tips"
        >{{ this.Local ? this.Local.prop('error.messagesContact') : 'Please contact our customer service or press F5 to refresh.' }}</p>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: "NotFound"
};
</script>

<style lang='less'>
.page-NotFound {
  background: #fff;
  .main {
    display: table;
    width: 100%;
    height: 100%;
    .des-wrapper {
      display: table-cell;
      vertical-align: middle;
      text-align: center;
      img {
        min-width: 500px;
        width: 40%;
      }
      .des {
        font-weight: 400;
        font-size: 18px;
        color: #666;
      }
      .tips {
        margin-top: 10px;
        font-weight: 300;
        font-size: 14px;
        color: #666;
      }
    }
  }
}
</style> 