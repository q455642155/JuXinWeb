import Mock from 'mockjs'
import { URL } from '@/config'

const monitorInit = () => {
  // 获取驾驶员的数据
  Mock.mock(URL + '/driver/list', {
    'code': 0,
    'data': {
      'list': [
        {
          'address': 'ymyd',
          'city': 'xrcvkixki',
          'driverName': 'wdmx',
          'driverNo': 'imvhgsner',
          'email': 'l.white@robinson.org',
          'expiredDate': '1993-09-08',
          'ext1': 'mlt',
          'ext2': 'rkqbkwyty',
          'ext3': 'ndizlue',
          'ext4': 'rufiher',
          'id': 5,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'clepkajbw',
          'phone': 14526542671,
          'registerDate': '2006-10-09',
          'registerPlace': 'ivis',
          'remark': 'dqlq',
          'userId': 61
        },
        {
          'address': 'nyklscoy',
          'city': 'bekh',
          'driverName': 'cera',
          'driverNo': 'bjxn',
          'email': 'z.davis@davis.gov',
          'expiredDate': '2014-11-03',
          'ext1': 'jtwqied',
          'ext2': 'qtuiyktft',
          'ext3': 'vpmwfk',
          'ext4': 'peqdrqz',
          'id': 99,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'dtpucx',
          'phone': 19087892245,
          'registerDate': '1979-05-04',
          'registerPlace': 'mdh',
          'remark': 'xxhkuum',
          'userId': 27
        },
        {
          'address': 'hkr',
          'city': 'crk',
          'driverName': 'egqhqgmxfm',
          'driverNo': 'ipq',
          'email': 'w.jackson@thompson.com',
          'expiredDate': '1998-07-03',
          'ext1': 'tdhof',
          'ext2': 'fubt',
          'ext3': 'lgprm',
          'ext4': 'yyfdbrcju',
          'id': 2,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'ynhubkztd',
          'phone': 15803944301,
          'registerDate': '1976-05-12',
          'registerPlace': 'uchbh',
          'remark': 'roymr',
          'userId': 53
        },
        {
          'address': 'uwhrqspws',
          'city': 'fpyszmwsmn',
          'driverName': 'njbetnbgq',
          'driverNo': 'qfo',
          'email': 'o.taylor@gonzalez.io',
          'expiredDate': '2009-12-08',
          'ext1': 'vlidx',
          'ext2': 'mryzc',
          'ext3': 'fgqqiwkxyg',
          'ext4': 'fqtoceu',
          'id': 76,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'fjd',
          'phone': 16872515148,
          'registerDate': '1995-12-12',
          'registerPlace': 'mknoovr',
          'remark': 'ysnz',
          'userId': 96
        },
        {
          'address': 'gjon',
          'city': 'mqiek',
          'driverName': 'wgrkcptm',
          'driverNo': 'cllnwu',
          'email': 'k.walker@smith.org',
          'expiredDate': '2014-02-18',
          'ext1': 'hxds',
          'ext2': 'kzhib',
          'ext3': 'sdkplzn',
          'ext4': 'hdged',
          'id': 30,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'vrmzcmrjwi',
          'phone': 19991869245,
          'registerDate': '2005-02-26',
          'registerPlace': 'wjvgb',
          'remark': 'rwurd',
          'userId': 95
        },
        {
          'address': 'bykgiwap',
          'city': 'cdrhmwol',
          'driverName': 'tzxhloupg',
          'driverNo': 'junuikm',
          'email': 'i.martinez@taylor.net',
          'expiredDate': '1978-03-19',
          'ext1': 'motv',
          'ext2': 'zilhfqxge',
          'ext3': 'letkygfi',
          'ext4': 'oisxpp',
          'id': 19,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'xhulmrhn',
          'phone': 19673396498,
          'registerDate': '1997-05-04',
          'registerPlace': 'xzbqq',
          'remark': 'rvtli',
          'userId': 80
        },
        {
          'address': 'xuixnwvma',
          'city': 'okaxvxtx',
          'driverName': 'kyrnwqenp',
          'driverNo': 'xkitgwryox',
          'email': 'j.miller@martin.net',
          'expiredDate': '1994-01-21',
          'ext1': 'iqdsgvgbge',
          'ext2': 'bgbgjkdh',
          'ext3': 'vnnsscxpyp',
          'ext4': 'urf',
          'id': 91,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'kyw',
          'phone': 16965910701,
          'registerDate': '1999-08-27',
          'registerPlace': 'mlone',
          'remark': 'pijasr',
          'userId': 46
        },
        {
          'address': 'fjkhf',
          'city': 'seww',
          'driverName': 'run',
          'driverNo': 'gkbtsw',
          'email': 'c.miller@gonzalez.edu',
          'expiredDate': '2000-09-11',
          'ext1': 'sribfg',
          'ext2': 'xpxupfeg',
          'ext3': 'ebfmu',
          'ext4': 'xxpbrdpx',
          'id': 36,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'xicdyyth',
          'phone': 18026681074,
          'registerDate': '2016-08-12',
          'registerPlace': 'noaz',
          'remark': 'luvhn',
          'userId': 78
        },
        {
          'address': 'clyo',
          'city': 'molkbgog',
          'driverName': 'lermps',
          'driverNo': 'lpqb',
          'email': 'p.jackson@taylor.edu',
          'expiredDate': '1977-04-05',
          'ext1': 'uefmhyexil',
          'ext2': 'tzomyhv',
          'ext3': 'kmfkhr',
          'ext4': 'jnhufp',
          'id': 12,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'dtlblqg',
          'phone': 18538458985,
          'registerDate': '1983-03-16',
          'registerPlace': 'zrcsyolwt',
          'remark': 'tfxpap',
          'userId': 9
        },
        {
          'address': 'cgddep',
          'city': 'mche',
          'driverName': 'dttcdpjo',
          'driverNo': 'tuggbu',
          'email': 'y.thomas@wilson.gov',
          'expiredDate': '2018-09-26',
          'ext1': 'npq',
          'ext2': 'ywy',
          'ext3': 'ozjw',
          'ext4': 'xpznh',
          'id': 89,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'ewispsfr',
          'phone': 13432306346,
          'registerDate': '2007-07-01',
          'registerPlace': 'msycpjwpi',
          'remark': 'opnjy',
          'userId': 60
        },
        {
          'address': 'sdtmeeh',
          'city': 'eqkmxiab',
          'driverName': 'giboix',
          'driverNo': 'wujdmig',
          'email': 'y.walker@white.com',
          'expiredDate': '2015-06-22',
          'ext1': 'xwjcksvh',
          'ext2': 'ipiylsrioq',
          'ext3': 'frh',
          'ext4': 'rbbr',
          'id': 64,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'aqmadx',
          'phone': 16475415353,
          'registerDate': '1980-09-17',
          'registerPlace': 'oqkcjx',
          'remark': 'vlhakfdyob',
          'userId': 28
        },
        {
          'address': 'gyfxr',
          'city': 'byajrlm',
          'driverName': 'wokkw',
          'driverNo': 'clzoxeidk',
          'email': 'd.hernandez@davis.co.uk',
          'expiredDate': '1999-02-06',
          'ext1': 'rjfljjcbi',
          'ext2': 'frlhstgy',
          'ext3': 'giig',
          'ext4': 'lslexusn',
          'id': 88,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'panyser',
          'phone': 19921418792,
          'registerDate': '2010-09-24',
          'registerPlace': 'rlcjlhm',
          'remark': 'ymcmagni',
          'userId': 62
        },
        {
          'address': 'hqrpzkd',
          'city': 'gvtmdd',
          'driverName': 'tesphc',
          'driverNo': 'csvionffm',
          'email': 'm.garcia@walker.com',
          'expiredDate': '1990-10-12',
          'ext1': 'sikyyfa',
          'ext2': 'usggkdyqq',
          'ext3': 'tdf',
          'ext4': 'yocer',
          'id': 72,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'jbdxeq',
          'phone': 18508137231,
          'registerDate': '1970-10-01',
          'registerPlace': 'bndwugyhfn',
          'remark': 'qdnxado',
          'userId': 23
        },
        {
          'address': 'sfbl',
          'city': 'myldku',
          'driverName': 'pwvszozr',
          'driverNo': 'gyvl',
          'email': 'k.allen@white.org',
          'expiredDate': '2011-09-20',
          'ext1': 'pikxvq',
          'ext2': 'hgyavs',
          'ext3': 'xbx',
          'ext4': 'enbi',
          'id': 31,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'mcbizky',
          'phone': 13295374347,
          'registerDate': '1978-03-31',
          'registerPlace': 'eqjr',
          'remark': 'fgdrfabt',
          'userId': 40
        },
        {
          'address': 'zvghxrmw',
          'city': 'wblu',
          'driverName': 'ylmqn',
          'driverNo': 'hyenc',
          'email': 't.williams@williams.co.uk',
          'expiredDate': '1986-01-14',
          'ext1': 'vnthmvj',
          'ext2': 'kxjpcvcw',
          'ext3': 'uxhei',
          'ext4': 'gttfr',
          'id': 5,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'ghm',
          'phone': 19878033936,
          'registerDate': '2005-06-23',
          'registerPlace': 'bkyrq',
          'remark': 'cilbtypr',
          'userId': 41
        },
        {
          'address': 'vofyfxyr',
          'city': 'lajmbwuy',
          'driverName': 'sdtxbuuo',
          'driverNo': 'unmzcvr',
          'email': 'o.brown@wilson.gov',
          'expiredDate': '1980-07-21',
          'ext1': 'movtqg',
          'ext2': 'qcdxzeyqgi',
          'ext3': 'opumde',
          'ext4': 'xvieqqd',
          'id': 19,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'tkmk',
          'phone': 15381453812,
          'registerDate': '1974-05-21',
          'registerPlace': 'bmnbfbq',
          'remark': 'fddcbtdfw',
          'userId': 60
        },
        {
          'address': 'yhrl',
          'city': 'blkiu',
          'driverName': 'euyrogix',
          'driverNo': 'ibyk',
          'email': 'w.white@lewis.gov',
          'expiredDate': '1970-08-16',
          'ext1': 'lccdhtl',
          'ext2': 'bojex',
          'ext3': 'cofwulgfc',
          'ext4': 'yrtvjlsjo',
          'id': 66,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'fwgwjjh',
          'phone': 14717893284,
          'registerDate': '1987-03-16',
          'registerPlace': 'ocbfjhqwif',
          'remark': 'vdsbv',
          'userId': 3
        },
        {
          'address': 'yjum',
          'city': 'mdhljfhxg',
          'driverName': 'piokxnuc',
          'driverNo': 'kcojnx',
          'email': 'h.lee@jackson.edu',
          'expiredDate': '2002-07-31',
          'ext1': 'sebytfhvg',
          'ext2': 'erfihkzxr',
          'ext3': 'ngqxl',
          'ext4': 'iitymecoa',
          'id': 73,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'hlunqdo',
          'phone': 13712672913,
          'registerDate': '2014-06-03',
          'registerPlace': 'emwwlkyena',
          'remark': 'jghuqt',
          'userId': 80
        },
        {
          'address': 'ltcwhj',
          'city': 'yurrrrlrt',
          'driverName': 'msrjes',
          'driverNo': 'rqnea',
          'email': 'i.lewis@lopez.org',
          'expiredDate': '1997-01-15',
          'ext1': 'syfr',
          'ext2': 'dwmxacyw',
          'ext3': 'wgxzek',
          'ext4': 'oxbkeyxjj',
          'id': 13,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'fsbg',
          'phone': 16404115944,
          'registerDate': '2017-11-24',
          'registerPlace': 'umnqnmhu',
          'remark': 'mjursxst',
          'userId': 55
        },
        {
          'address': 'oaybrn',
          'city': 'xfjvwg',
          'driverName': 'hvesjnl',
          'driverNo': 'gxkdq',
          'email': 'i.davis@gonzalez.net',
          'expiredDate': '1997-01-06',
          'ext1': 'ehrfqbsw',
          'ext2': 'orbxxezm',
          'ext3': 'nbw',
          'ext4': 'vqcbm',
          'id': 94,
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo': 'qwvnvmr',
          'phone': 19066089563,
          'registerDate': '1998-09-12',
          'registerPlace': 'ucewemd',
          'remark': 'wotcyifq',
          'userId': 28
        }
      ],
      'nextPage': 2,
      'pageNum': 1,
      'pageSize': 10,
      'pages': 10,
      'size': 20,
      'total': 200
    },
    'msg': 'success'
  })

  // 获取车辆相关统计数据
  Mock.mock(URL + '/dashboard/getVehicleStatistics', {
    'code': 0,
    'data': {
      'distanceTraveled': 257,
      'engineOnHours': 327,
      'fuelConsumption': 548,
      'totalDrivers': 623,
      'totalVehicles': 482
    },
    'msg': 'success'
  })

  // 获得油感消耗排序统计
  Mock.mock(URL + '/dashboard/getTopFuelConsumption', {
    'code': 0,
    'data': [
      {
        'date': '2019-03-25',
        'dayList': [
          {
            'vehicleName': 'caxuom',
            'fuelconsumption': 62
          },
          {
            'vehicleName': 'ipdiph',
            'fuelconsumption': 82
          },
          {
            'vehicleName': 'ykwuuuvfjd',
            'fuelconsumption': 122
          },
          {
            'vehicleName': 'uqhm',
            'fuelconsumption': 233
          },
          {
            'vehicleName': 'qxfobgtyz',
            'fuelconsumption': 144
          },
          {
            'vehicleName': 'htnqqx',
            'fuelconsumption': 104
          }
        ]
      },
      {
        'date': '2019-03-26',
        'dayList': [
          {
            'vehicleName': 'caxuom',
            'fuelconsumption': 102
          },
          {
            'vehicleName': 'ipdiph',
            'fuelconsumption': 220
          },
          {
            'vehicleName': 'ykwuuuvfjd',
            'fuelconsumption': 202
          },
          {
            'vehicleName': 'uqhm',
            'fuelconsumption': 133
          },
          {
            'vehicleName': 'qxfobgtyz',
            'fuelconsumption': 74
          },
          {
            'vehicleName': 'htnqqx',
            'fuelconsumption': 54
          }
        ]
      },
      {
        'date': '2019-03-27',
        'dayList': [
          {
            'vehicleName': 'caxuom',
            'fuelconsumption': 125
          },
          {
            'vehicleName': 'ipdiph',
            'fuelconsumption': 122
          },
          {
            'vehicleName': 'ykwuuuvfjd',
            'fuelconsumption': 122
          },
          {
            'vehicleName': 'uqhm',
            'fuelconsumption': 133
          },
          {
            'vehicleName': 'qxfobgtyz',
            'fuelconsumption': 144
          },
          {
            'vehicleName': 'htnqqx',
            'fuelconsumption': 144
          }
        ]
      },
      {
        'date': '2019-03-28',
        'dayList': [
          {
            'vehicleName': 'caxuom',
            'fuelconsumption': 212
          },
          {
            'vehicleName': 'ipdiph',
            'fuelconsumption': 222
          },
          {
            'vehicleName': 'ykwuuuvfjd',
            'fuelconsumption': 242
          },
          {
            'vehicleName': 'uqhm',
            'fuelconsumption': 233
          },
          {
            'vehicleName': 'qxfobgtyz',
            'fuelconsumption': 234
          },
          {
            'vehicleName': 'htnqqx',
            'fuelconsumption': 144
          }
        ]
      },
      {
        'date': '2019-03-29',
        'dayList': [
          {
            'vehicleName': 'caxuom',
            'fuelconsumption': 312
          },
          {
            'vehicleName': 'ipdiph',
            'fuelconsumption': 322
          },
          {
            'vehicleName': 'ykwuuuvfjd',
            'fuelconsumption': 322
          },
          {
            'vehicleName': 'uqhm',
            'fuelconsumption': 333
          },
          {
            'vehicleName': 'qxfobgtyz',
            'fuelconsumption': 344
          },
          {
            'vehicleName': 'htnqqx',
            'fuelconsumption': 344
          }
        ]
      },
      {
        'date': '2019-03-30',
        'dayList': [
          {
            'vehicleName': 'caxuom',
            'fuelconsumption': 33
          },
          {
            'vehicleName': 'ipdiph',
            'fuelconsumption': 44
          },
          {
            'vehicleName': 'ykwuuuvfjd',
            'fuelconsumption': 55
          },
          {
            'vehicleName': 'uqhm',
            'fuelconsumption': 66
          },
          {
            'vehicleName': 'qxfobgtyz',
            'fuelconsumption': 77
          },
          {
            'vehicleName': 'htnqqx',
            'fuelconsumption': 88
          }
        ]
      },
      {
        'date': '2019-03-31',
        'dayList': [
          {
            'vehicleName': 'caxuom',
            'fuelconsumption': 112
          },
          {
            'vehicleName': 'ipdiph',
            'fuelconsumption': 212
          },
          {
            'vehicleName': 'ykwuuuvfjd',
            'fuelconsumption': 212
          },
          {
            'vehicleName': 'uqhm',
            'fuelconsumption': 313
          },
          {
            'vehicleName': 'qxfobgtyz',
            'fuelconsumption': 144
          },
          {
            'vehicleName': 'htnqqx',
            'fuelconsumption': 84
          }
        ]
      }
    ],
    'msg': 'success'
  })

  // 获取提醒
  Mock.mock(URL + '/dashboard/reminderOverview', {
    'code': 0,
    'data': {
      'delayedCount': 16,
      'normalCount': 13,
      'waitingCount': 6
    },
    'msg': 'success'
  })

  // 获取行驶里程
  Mock.mock(URL + '/dashboard/drivingMileageStatistics', {
    'code': 0,
    'msg': 'success',
    'data': [
      {
        'date': '2019-03-20',
        'dayList': [
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·66666',
            'imei': '201711071234010',
            'atDay': '2019-03-20'
          },
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·88888',
            'imei': '201711076666605',
            'atDay': '2019-03-20'
          }
        ]
      },
      {
        'date': '2019-03-21',
        'dayList': [
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·66666',
            'imei': '201711071234010',
            'atDay': '2019-03-21'
          },
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·88888',
            'imei': '201711076666605',
            'atDay': '2019-03-21'
          }
        ]
      },
      {
        'date': '2019-03-22',
        'dayList': [
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·66666',
            'imei': '201711071234010',
            'atDay': '2019-03-22'
          },
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·88888',
            'imei': '201711076666605',
            'atDay': '2019-03-22'
          }
        ]
      },
      {
        'date': '2019-03-23',
        'dayList': [
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·66666',
            'imei': '201711071234010',
            'atDay': '2019-03-23'
          },
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·88888',
            'imei': '201711076666605',
            'atDay': '2019-03-23'
          }
        ]
      },
      {
        'date': '2019-03-24',
        'dayList': [
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·66666',
            'imei': '201711071234010',
            'atDay': '2019-03-24'
          },
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·88888',
            'imei': '201711076666605',
            'atDay': '2019-03-24'
          }
        ]
      },
      {
        'date': '2019-03-25',
        'dayList': [
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·66666',
            'imei': '201711071234010',
            'atDay': '2019-03-25'
          },
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·88888',
            'imei': '201711076666605',
            'atDay': '2019-03-25'
          }
        ]
      },
      {
        'date': '2019-03-26',
        'dayList': [
          {
            'distance': 3098875.1084397184,
            'fuelconsumption': 247.91,
            'vehicleName': '湘A·88888',
            'imei': '201711076666605',
            'atDay': '2019-03-26'
          },
          {
            'distance': 996126.6499720316,
            'fuelconsumption': 79.69015999999999,
            'vehicleName': '湘A·66666',
            'imei': '201711071234010',
            'atDay': '2019-03-26'
          }
        ]
      },
      {
        'date': '2019-03-27',
        'dayList': [
          {
            'distance': 4874056.748120955,
            'fuelconsumption': 389.92456,
            'vehicleName': '湘A·66666',
            'imei': '201711071234010',
            'atDay': '2019-03-27'
          },
          {
            'distance': '0',
            'fuelconsumption': '0',
            'vehicleName': '湘A·88888',
            'imei': '201711076666605',
            'atDay': '2019-03-27'
          }
        ]
      }
    ]
  })
  // 获得驾驶行为信息
  Mock.mock(URL + '/dashboard/getDrivingBehavior', {
    'code': 0,
    'data': [
      {
        'alarmCount': 72,
        'vehicleName': 'pkgcifzd'
      },
      {
        'alarmCount': 32,
        'vehicleName': 'oifbwkfx'
      },
      {
        'alarmCount': 55,
        'vehicleName': 'hfaalrf'
      },
      {
        'alarmCount': 46,
        'vehicleName': 'vzkex'
      },
      {
        'alarmCount': 78,
        'vehicleName': 'hiexdpxwg'
      }
    ],
    'msg': 'success'
  })

  // 获取车辆
  Mock.mock(URL + '/vehicle/list', {
    'data': {
      'total': 200,
      'pageNum': 1,
      'pageSize': 20,
      'list': [
        {
          'model': 'otgoptgv',
          'ext3': 'naspvfplvp',
          'productionYear': 'jurrcqpx',
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color': 'omkqae',
          'ext4': 'jljmmvmap',
          'engineNo': 'zfubmwugi',
          'brand': 'pomqswpia',
          'vin': 'inbuayooym',
          'maxSpeed': 5,
          'ext2': 'uzabs',
          'fuel': 41,
          'id': 20,
          'remark': 'moitfms',
          'imei': 17566282949,
          'ext1': 'pihe',
          'status': 1,
          'plateNo': 'dzhjwqdhh',
          'plateType': 'spptv'
        },
        {
          'model': 'llyrrs',
          'ext3': 'spvtjefm',
          'productionYear': 'begdz',
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color': 'sfjpboma',
          'ext4': 'qjrtqpt',
          'engineNo': 'fkcvnsogu',
          'brand': 'otdlro',
          'vin': 'bbvgl',
          'maxSpeed': 12,
          'ext2': 'deouqycon',
          'fuel': 69,
          'id': 16,
          'remark': 'idytyg',
          'imei': 17516982848,
          'ext1': 'fuotd',
          'status': 2,
          'plateNo': 'gsumom',
          'plateType': 'ifpnrb'
        },
        {
          'model': 'sycejzqvaz',
          'ext3': 'jrikpbnmd',
          'productionYear': 'cpxv',
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color': 'qfzlo',
          'ext4': 'whaqzivz',
          'engineNo': 'aev',
          'brand': 'oicsjgngo',
          'vin': 'yoi',
          'maxSpeed': 5,
          'ext2': 'rdakuw',
          'fuel': 5,
          'id': 74,
          'remark': 'pkvpd',
          'imei': 19283587850,
          'ext1': 'kqy',
          'status': 1,
          'plateNo': 'mdullyk',
          'plateType': 'mjfthex'
        }
      ],
      'size': 200,
      'nextPage': 20,
      'pages': 10
    },
    'code': 0,
    'msg': 'success'
  })

  // 获取rfid
  Mock.mock(URL + '/rfid/list', {
    'data': {
      'total': 200,
      'pageNum': 1,
      'pageSize': 20,
      'list': [
        {
          'model': 'otgoptgv',
          'ext3': 'naspvfplvp',
          'productionYear': 'jurrcqpx',
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color': 'omkqae',
          'ext4': 'jljmmvmap',
          'engineNo': 'zfubmwugi',
          'brand': 'pomqswpia',
          'vin': 'inbuayooym',
          'maxSpeed': 5,
          'ext2': 'uzabs',
          'fuel': 41,
          'id': 20,
          'remark': 'moitfms',
          'imei': 17566282949,
          'ext1': 'pihe',
          'status': 1,
          'plateNo': 'dzhjwqdhh',
          'plateType': 'spptv',
          'driverName': 'asdasd',
          'vehicleName': 'ufhsn',
          'creationDate': '2019-03-29 10:08:30'
        },
        {
          'model': 'llyrrs',
          'ext3': 'spvtjefm',
          'productionYear': 'begdz',
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color': 'sfjpboma',
          'ext4': 'qjrtqpt',
          'engineNo': 'fkcvnsogu',
          'brand': 'otdlro',
          'vin': 'bbvgl',
          'maxSpeed': 12,
          'ext2': 'deouqycon',
          'fuel': 69,
          'id': 16,
          'remark': 'idytyg',
          'imei': 17516982848,
          'ext1': 'fuotd',
          'status': 2,
          'plateNo': 'gsumom',
          'plateType': 'ifpnrb',
          'driverName': 'osjfff',
          'vehicleName': 'fweewr',
          'creationDate': '2019-03-29 10:08:30'
        },
        {
          'model': 'sycejzqvaz',
          'ext3': 'jrikpbnmd',
          'productionYear': 'cpxv',
          'imagePath': 'http://tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color': 'qfzlo',
          'ext4': 'whaqzivz',
          'engineNo': 'aev',
          'brand': 'oicsjgngo',
          'vin': 'yoi',
          'maxSpeed': 5,
          'ext2': 'rdakuw',
          'fuel': 5,
          'id': 74,
          'remark': 'pkvpd',
          'imei': 19283587850,
          'ext1': 'kqy',
          'status': 1,
          'plateNo': 'mdullyk',
          'plateType': 'mjfthex',
          'driverName': 'ldgdja',
          'vehicleName': 'hghhs',
          'creationDate': '2019-03-29 10:08:30'
        }
      ],
      'size': 200,
      'nextPage': 20,
      'pages': 10
    },
    'code': 0,
    'msg': 'success'
  })

  // 获取通知数量的列表
  Mock.mock(URL + '/notification/list', {
    'code': 0,
    'msg': 'sucess',
    'data': {
      'pageSize': 20,
      'nextPage': 2,
      'list': [
        {
          'notificationTime': '2008-07-26',
          'id': -8470721529353692,
          'content': 'ozhrdzpn',
          'currentValue': 'zapa',
          'status': 2,
          'source': 'otsw',
          'reminderName': 'zlpthd'
        },
        {
          'notificationTime': '1978-03-31',
          'id': 127394543386204,
          'content': 'orepjx',
          'currentValue': 'mkv',
          'status': 1,
          'source': 'uwo',
          'reminderName': 'xjh'
        },
        {
          'notificationTime': '1974-04-28',
          'id': 6397684712599370,
          'content': 'wfdq',
          'currentValue': 'fau',
          'status': 2,
          'source': 'fmiff',
          'reminderName': 'yowtjp'
        },
        {
          'notificationTime': '2007-03-04',
          'id': 2690151894234134,
          'content': 'dmw',
          'currentValue': 'jjmg',
          'status': 2,
          'source': 'knvghg',
          'reminderName': 'xvk'
        },
        {
          'notificationTime': '1990-01-25',
          'id': 8622257859703086,
          'content': 'bwtmlc',
          'currentValue': 'twzjc',
          'status': 2,
          'source': 'fijx',
          'reminderName': 'bptp'
        },
        {
          'notificationTime': '1989-05-28',
          'id': -6596855571858366,
          'content': 'ivp',
          'currentValue': 'drjnqozvs',
          'status': 2,
          'source': 'rtd',
          'reminderName': 'wrrihbxgwo'
        },
        {
          'notificationTime': '1987-12-15',
          'id': -8016387988269924,
          'content': 'cxrq',
          'currentValue': 'xpryhpis',
          'status': 1,
          'source': 'bmmoftnzun',
          'reminderName': 'tbjvmpev'
        },
        {
          'notificationTime': '2002-05-07',
          'id': -7177694661269250,
          'content': 'sghtv',
          'currentValue': 'cxuapri',
          'status': 1,
          'source': 'tkvjhbi',
          'reminderName': 'iaj'
        },
        {
          'notificationTime': '1974-11-01',
          'id': 3954141649430698,
          'content': 'fed',
          'currentValue': 'bstwroyqm',
          'status': 2,
          'source': 'pjxvtdlxu',
          'reminderName': 'smvcgx'
        }
      ],
      'size': 20,
      'total': 20,
      'pages': 10,
      'pageNum': 1
    }
  })

  // 获取里程阈值
  Mock.mock(window._ctx + '/device/querymileageThreshold', {
    'code': 0,
    'msg': 'success',
    'data': {
      'mileageThreshold': 158,
      'aCCOnDurtionThreshold': 123
    }
  })

  // 获取里程阈值
  Mock.mock(window._ctx + '/device/getTotalMilage', {
    'code': 0,
    'msg': 'success',
    'data': {
      'maintenanceAlertFlag': 1,
      'mileage': 333,
      'runTime': 444
    }
  })
}

export {monitorInit}
