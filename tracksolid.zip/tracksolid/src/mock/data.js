import Mock from 'mockjs'
import { URL } from '@/config'

const monitorInit = () => {
  // 获取驾驶员的数据
  Mock.mock(URL + '/driver/list', {
    'code':  0,
    'data':  {
      'list':  [
        {
          'address':  'ymyd',
          'city':  'xrcvkixki',
          'driverName':  'wdmx',
          'driverNo':  'imvhgsner',
          'email':  'l.white@robinson.org',
          'expiredDate':  '1993-09-08',
          'ext1':  'mlt',
          'ext2':  'rkqbkwyty',
          'ext3':  'ndizlue',
          'ext4':  'rufiher',
          'id':  5,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'clepkajbw',
          'phone':  14526542671,
          'registerDate':  '2006-10-09',
          'registerPlace':  'ivis',
          'remark':  'dqlq',
          'reminderStatus':  0,
          'userId':  61
        },
        {
          'address':  'nyklscoy',
          'city':  'bekh',
          'driverName':  'cera',
          'driverNo':  'bjxn',
          'email':  'z.davis@davis.gov',
          'expiredDate':  '2014-11-03',
          'ext1':  'jtwqied',
          'ext2':  'qtuiyktft',
          'ext3':  'vpmwfk',
          'ext4':  'peqdrqz',
          'reminderStatus':  1,
          'id':  99,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'dtpucx',
          'phone':  19087892245,
          'registerDate':  '1979-05-04',
          'registerPlace':  'mdh',
          'remark':  'xxhkuum',
          'userId':  27
        },
        {
          'address':  'hkr',
          'city':  'crk',
          'driverName':  'egqhqgmxfm',
          'driverNo':  'ipq',
          'email':  'w.jackson@thompson.com',
          'expiredDate':  '1998-07-03',
          'ext1':  'tdhof',
          'ext2':  'fubt',
          'ext3':  'lgprm',
          'ext4':  'yyfdbrcju',
          'reminderStatus':  2,
          'id':  2,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'ynhubkztd',
          'phone':  15803944301,
          'registerDate':  '1976-05-12',
          'registerPlace':  'uchbh',
          'remark':  'roymr',
          'userId':  53
        },
        {
          'reminderStatus':  0,
          'address':  'uwhrqspws',
          'city':  'fpyszmwsmn',
          'driverName':  'njbetnbgq',
          'driverNo':  'qfo',
          'email':  'o.taylor@gonzalez.io',
          'expiredDate':  '2009-12-08',
          'ext1':  'vlidx',
          'ext2':  'mryzc',
          'ext3':  'fgqqiwkxyg',
          'ext4':  'fqtoceu',
          'id':  76,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'fjd',
          'phone':  16872515148,
          'registerDate':  '1995-12-12',
          'registerPlace':  'mknoovr',
          'remark':  'ysnz',
          'userId':  96
        },
        {
          'reminderStatus':  2,
          'address':  'gjon',
          'city':  'mqiek',
          'driverName':  'wgrkcptm',
          'driverNo':  'cllnwu',
          'email':  'k.walker@smith.org',
          'expiredDate':  '2014-02-18',
          'ext1':  'hxds',
          'ext2':  'kzhib',
          'ext3':  'sdkplzn',
          'ext4':  'hdged',
          'id':  30,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'vrmzcmrjwi',
          'phone':  19991869245,
          'registerDate':  '2005-02-26',
          'registerPlace':  'wjvgb',
          'remark':  'rwurd',
          'userId':  95
        },
        {
          'reminderStatus':  '',
          'address':  'bykgiwap',
          'city':  'cdrhmwol',
          'driverName':  'tzxhloupg',
          'driverNo':  'junuikm',
          'email':  'i.martinez@taylor.net',
          'expiredDate':  '1978-03-19',
          'ext1':  'motv',
          'ext2':  'zilhfqxge',
          'ext3':  'letkygfi',
          'ext4':  'oisxpp',
          'id':  19,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'xhulmrhn',
          'phone':  19673396498,
          'registerDate':  '1997-05-04',
          'registerPlace':  'xzbqq',
          'remark':  'rvtli',
          'userId':  80
        },
        {
          'reminderStatus':  2,
          'address':  'xuixnwvma',
          'city':  'okaxvxtx',
          'driverName':  'kyrnwqenp',
          'driverNo':  'xkitgwryox',
          'email':  'j.miller@martin.net',
          'expiredDate':  '1994-01-21',
          'ext1':  'iqdsgvgbge',
          'ext2':  'bgbgjkdh',
          'ext3':  'vnnsscxpyp',
          'ext4':  'urf',
          'id':  91,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'kyw',
          'phone':  16965910701,
          'registerDate':  '1999-08-27',
          'registerPlace':  'mlone',
          'remark':  'pijasr',
          'userId':  46
        },
        {
          'reminderStatus':  0,
          'address':  'fjkhf',
          'city':  'seww',
          'driverName':  'run',
          'driverNo':  'gkbtsw',
          'email':  'c.miller@gonzalez.edu',
          'expiredDate':  '2000-09-11',
          'ext1':  'sribfg',
          'ext2':  'xpxupfeg',
          'ext3':  'ebfmu',
          'ext4':  'xxpbrdpx',
          'id':  36,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'xicdyyth',
          'phone':  18026681074,
          'registerDate':  '2016-08-12',
          'registerPlace':  'noaz',
          'remark':  'luvhn',
          'userId':  78
        },
        {
          'reminderStatus':  1,
          'address':  'clyo',
          'city':  'molkbgog',
          'driverName':  'lermps',
          'driverNo':  'lpqb',
          'email':  'p.jackson@taylor.edu',
          'expiredDate':  '1977-04-05',
          'ext1':  'uefmhyexil',
          'ext2':  'tzomyhv',
          'ext3':  'kmfkhr',
          'ext4':  'jnhufp',
          'id':  12,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'dtlblqg',
          'phone':  18538458985,
          'registerDate':  '1983-03-16',
          'registerPlace':  'zrcsyolwt',
          'remark':  'tfxpap',
          'userId':  9
        },
        {
          'reminderStatus':  2,
          'address':  'cgddep',
          'city':  'mche',
          'driverName':  'dttcdpjo',
          'driverNo':  'tuggbu',
          'email':  'y.thomas@wilson.gov',
          'expiredDate':  '2018-09-26',
          'ext1':  'npq',
          'ext2':  'ywy',
          'ext3':  'ozjw',
          'ext4':  'xpznh',
          'id':  89,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'ewispsfr',
          'phone':  13432306346,
          'registerDate':  '2007-07-01',
          'registerPlace':  'msycpjwpi',
          'remark':  'opnjy',
          'userId':  60
        },
        {
          'reminderStatus':  '',
          'address':  'sdtmeeh',
          'city':  'eqkmxiab',
          'driverName':  'giboix',
          'driverNo':  'wujdmig',
          'email':  'y.walker@white.com',
          'expiredDate':  '2015-06-22',
          'ext1':  'xwjcksvh',
          'ext2':  'ipiylsrioq',
          'ext3':  'frh',
          'ext4':  'rbbr',
          'id':  64,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'aqmadx',
          'phone':  16475415353,
          'registerDate':  '1980-09-17',
          'registerPlace':  'oqkcjx',
          'remark':  'vlhakfdyob',
          'userId':  28
        },
        {
          'reminderStatus':  0,
          'address':  'gyfxr',
          'city':  'byajrlm',
          'driverName':  'wokkw',
          'driverNo':  'clzoxeidk',
          'email':  'd.hernandez@davis.co.uk',
          'expiredDate':  '1999-02-06',
          'ext1':  'rjfljjcbi',
          'ext2':  'frlhstgy',
          'ext3':  'giig',
          'ext4':  'lslexusn',
          'id':  88,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'panyser',
          'phone':  19921418792,
          'registerDate':  '2010-09-24',
          'registerPlace':  'rlcjlhm',
          'remark':  'ymcmagni',
          'userId':  62
        },
        {
          'reminderStatus':  0,
          'address':  'hqrpzkd',
          'city':  'gvtmdd',
          'driverName':  'tesphc',
          'driverNo':  'csvionffm',
          'email':  'm.garcia@walker.com',
          'expiredDate':  '1990-10-12',
          'ext1':  'sikyyfa',
          'ext2':  'usggkdyqq',
          'ext3':  'tdf',
          'ext4':  'yocer',
          'id':  72,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'jbdxeq',
          'phone':  18508137231,
          'registerDate':  '1970-10-01',
          'registerPlace':  'bndwugyhfn',
          'remark':  'qdnxado',
          'userId':  23
        },
        {
          'reminderStatus':  0,
          'address':  'sfbl',
          'city':  'myldku',
          'driverName':  'pwvszozr',
          'driverNo':  'gyvl',
          'email':  'k.allen@white.org',
          'expiredDate':  '2011-09-20',
          'ext1':  'pikxvq',
          'ext2':  'hgyavs',
          'ext3':  'xbx',
          'ext4':  'enbi',
          'id':  31,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'mcbizky',
          'phone':  13295374347,
          'registerDate':  '1978-03-31',
          'registerPlace':  'eqjr',
          'remark':  'fgdrfabt',
          'userId':  40
        },
        {
          'reminderStatus':  0,
          'address':  'zvghxrmw',
          'city':  'wblu',
          'driverName':  'ylmqn',
          'driverNo':  'hyenc',
          'email':  't.williams@williams.co.uk',
          'expiredDate':  '1986-01-14',
          'ext1':  'vnthmvj',
          'ext2':  'kxjpcvcw',
          'ext3':  'uxhei',
          'ext4':  'gttfr',
          'id':  5,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'ghm',
          'phone':  19878033936,
          'registerDate':  '2005-06-23',
          'registerPlace':  'bkyrq',
          'remark':  'cilbtypr',
          'userId':  41
        },
        {
          'reminderStatus':  0,
          'address':  'vofyfxyr',
          'city':  'lajmbwuy',
          'driverName':  'sdtxbuuo',
          'driverNo':  'unmzcvr',
          'email':  'o.brown@wilson.gov',
          'expiredDate':  '1980-07-21',
          'ext1':  'movtqg',
          'ext2':  'qcdxzeyqgi',
          'ext3':  'opumde',
          'ext4':  'xvieqqd',
          'id':  19,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'tkmk',
          'phone':  15381453812,
          'registerDate':  '1974-05-21',
          'registerPlace':  'bmnbfbq',
          'remark':  'fddcbtdfw',
          'userId':  60
        },
        {
          'reminderStatus':  0,
          'address':  'yhrl',
          'city':  'blkiu',
          'driverName':  'euyrogix',
          'driverNo':  'ibyk',
          'email':  'w.white@lewis.gov',
          'expiredDate':  '1970-08-16',
          'ext1':  'lccdhtl',
          'ext2':  'bojex',
          'ext3':  'cofwulgfc',
          'ext4':  'yrtvjlsjo',
          'id':  66,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'fwgwjjh',
          'phone':  14717893284,
          'registerDate':  '1987-03-16',
          'registerPlace':  'ocbfjhqwif',
          'remark':  'vdsbv',
          'userId':  3
        },
        {
          'reminderStatus':  0,
          'address':  'yjum',
          'city':  'mdhljfhxg',
          'driverName':  'piokxnuc',
          'driverNo':  'kcojnx',
          'email':  'h.lee@jackson.edu',
          'expiredDate':  '2002-07-31',
          'ext1':  'sebytfhvg',
          'ext2':  'erfihkzxr',
          'ext3':  'ngqxl',
          'ext4':  'iitymecoa',
          'id':  73,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'hlunqdo',
          'phone':  13712672913,
          'registerDate':  '2014-06-03',
          'registerPlace':  'emwwlkyena',
          'remark':  'jghuqt',
          'userId':  80
        },
        {
          'reminderStatus':  0,
          'address':  'ltcwhj',
          'city':  'yurrrrlrt',
          'driverName':  'msrjes',
          'driverNo':  'rqnea',
          'email':  'i.lewis@lopez.org',
          'expiredDate':  '1997-01-15',
          'ext1':  'syfr',
          'ext2':  'dwmxacyw',
          'ext3':  'wgxzek',
          'ext4':  'oxbkeyxjj',
          'id':  13,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'fsbg',
          'phone':  16404115944,
          'registerDate':  '2017-11-24',
          'registerPlace':  'umnqnmhu',
          'remark':  'mjursxst',
          'userId':  55
        },
        {
          'reminderStatus':  0,
          'address':  'oaybrn',
          'city':  'xfjvwg',
          'driverName':  'hvesjnl',
          'driverNo':  'gxkdq',
          'email':  'i.davis@gonzalez.net',
          'expiredDate':  '1997-01-06',
          'ext1':  'ehrfqbsw',
          'ext2':  'orbxxezm',
          'ext3':  'nbw',
          'ext4':  'vqcbm',
          'id':  94,
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'licenseNo':  'qwvnvmr',
          'phone':  19066089563,
          'registerDate':  '1998-09-12',
          'registerPlace':  'ucewemd',
          'remark':  'wotcyifq',
          'userId':  28
        }
      ],
      'nextPage':  2,
      'pageNum':  1,
      'pageSize':  20,
      'pages':  10,
      'size':  2,
      'total':  20
    },
    'msg':  'success'
  })

  // 获取车辆相关统计数据
  Mock.mock(URL + '/dashboard/getVehicleStatistics', {
    'code':  0,
    'data':  {
      'distanceTraveled':  null,
      'engineOnHours':  null,
      'fuelConsumption':  548,
      'totalDrivers':  623,
      'totalVehicles':  482
    },
    'msg':  'success'
  })

  // 获得油感消耗排序统计
  Mock.mock(URL + '/dashboard/getTopFuelConsumption', {
    'code':  0,
    'data':  [
      {
        'date':  '2019-03-29',
        'dayList':  [
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw12'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw32'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw123'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw45'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw45'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw12'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw34'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw23'
          }
        ]
      },
      {
        'date':  '2019-03-30',
        'dayList':  [
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw12'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw32'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw123'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw45'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw45'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw12'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw34'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw23'
          }
        ]
      },
      {
        'date':  '2019-03-31',
        'dayList':  [
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw12'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw32'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw123'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw45'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw45'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw12'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw34'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw23'
          }
        ]
      },
      {
        'date':  '2019-04-01',
        'dayList':  [
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw12'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw32'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw123'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw45'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw45'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw12'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw34'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw23'
          }
        ]
      },
      {
        'date':  '2019-04-02',
        'dayList':  [
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw12'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw32'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw123'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw45'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw45'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw12'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw34'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw23'
          }
        ]
      },
      {
        'date':  '2019-04-03',
        'dayList':  [
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw12'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw32'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw123'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw45'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw45'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw12'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw34'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw23'
          }
        ]
      },
      {
        'date':  '2019-04-04',
        'dayList':  [
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw12'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw32'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw123'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw45'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw45'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw12'
          },
          {
            'fuelconsumption':  55,
            'vehicleName':  'wsrswxkyw34'
          },
          {
            'fuelconsumption':  155,
            'vehicleName':  'swxkyw23'
          }
        ]
      }
    ],
    'msg':  'success'
  })

  // 获取提醒
  Mock.mock(URL + '/dashboard/reminderOverview', {
    'code':  0,
    'data':  {
      'Delayed':  0,
      'Normal':  0,
      'Waiting':  0
    },
    'msg':  'success'
  })

  // 获取行驶里程
  Mock.mock(URL + '/dashboard/drivingMileageStatistics', {
    'code':  0,
    'data':  [
      {
        'date':  '2019-03-29',
        'dayList':  [
          {
            'distance':  55,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'distance':  155,
            'vehicleName':  'swxkyw'
          }
        ]
      },
      {
        'date':  '2019-03-30',
        'dayList':  [
          {
            'distance':  155,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'distance':  255,
            'vehicleName':  'swxkyw'
          }
        ]
      },
      {
        'date':  '2019-03-31',
        'dayList':  [
          {
            'distance':  125,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'distance':  87,
            'vehicleName':  'swxkyw'
          }
        ]
      },
      {
        'date':  '2019-04-01',
        'dayList':  [
          {
            'distance':  100,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'distance':  300,
            'vehicleName':  'swxkyw'
          }
        ]
      },
      {
        'date':  '2019-04-02',
        'dayList':  [
          {
            'distance':  112,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'distance':  355,
            'vehicleName':  'swxkyw'
          }
        ]
      },
      {
        'date':  '2019-04-03',
        'dayList':  [
          {
            'distance':  212,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'distance':  155,
            'vehicleName':  'swxkyw'
          }
        ]
      },
      {
        'date':  '2019-04-04',
        'dayList':  [
          {
            'distance':  312,
            'vehicleName':  'wsrswxkyw'
          },
          {
            'distance':  55,
            'vehicleName':  'swxkyw'
          }
        ]
      }
    ],
    'msg':  'success'
  })

  // 获取行驶行为
  Mock.mock(URL + '/dashboard/getDrivingBehavior', {
    'code':  0,
    'data':  [
      {
        'alarmCount':  84,
        'vehicleName':  'aaaa'
      },
      {
        'alarmCount':  42,
        'vehicleName':  'bbbb'
      },
      {
        'alarmCount':  47,
        'vehicleName':  'cccc'
      },
      {
        'alarmCount':  12,
        'vehicleName':  'dddd'
      },
      {
        'alarmCount':  71,
        'vehicleName':  'eeee'
      },
      {
        'alarmCount':  13,
        'vehicleName':  'ffff'
      },
      {
        'alarmCount':  39,
        'vehicleName':  'hhhhh'
      },
      {
        'alarmCount':  88,
        'vehicleName':  'qqqq'
      },
      {
        'alarmCount':  98,
        'vehicleName':  'rrrrr'
      },
      {
        'alarmCount':  95,
        'vehicleName':  'jjjjj'
      }
    ],
    'msg':  'success'
  })
  // 获取车辆
  Mock.mock(URL + '/vehicle/list', {
    'data':  {
      'total':  200,
      'pageNum':  1,
      'pageSize':  20,
      'list':  [
        {
          'reminderStatus':  0,
          'model':  'otgoptgv',
          'ext3':  'naspvfplvp',
          'productionYear':  'jurrcqpx',
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color':  'omkqae',
          'ext4':  'jljmmvmap',
          'engineNo':  'zfubmwugi',
          'brand':  'pomqswpia',
          'vin':  'inbuayooym',
          'maxSpeed':  5,
          'ext2':  'uzabs',
          'fuel':  41,
          'id':  20,
          'remark':  'moitfms',
          'imei':  17566282949,
          'ext1':  'pihe',
          'status':  1,
          'plateNo':  'dzhjwqdhh',
          'plateType':  'spptv'
        },
        {
          'reminderStatus':  1,
          'model':  'llyrrs',
          'ext3':  'spvtjefm',
          'productionYear':  'begdz',
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color':  'sfjpboma',
          'ext4':  'qjrtqpt',
          'engineNo':  'fkcvnsogu',
          'brand':  'otdlro',
          'vin':  'bbvgl',
          'maxSpeed':  12,
          'ext2':  'deouqycon',
          'fuel':  69,
          'id':  16,
          'remark':  'idytyg',
          'imei':  17516982848,
          'ext1':  'fuotd',
          'status':  2,
          'plateNo':  'gsumom',
          'plateType':  'ifpnrb'
        },
        {
          'reminderStatus':  2,
          'model':  'sycejzqvaz',
          'ext3':  'jrikpbnmd',
          'productionYear':  'cpxv',
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color':  'qfzlo',
          'ext4':  'whaqzivz',
          'engineNo':  'aev',
          'brand':  'oicsjgngo',
          'vin':  'yoi',
          'maxSpeed':  5,
          'ext2':  'rdakuw',
          'fuel':  5,
          'id':  74,
          'remark':  'pkvpd',
          'imei':  19283587850,
          'ext1':  'kqy',
          'status':  1,
          'plateNo':  'mdullyk',
          'plateType':  'mjfthex'
        },
        {
          'reminderStatus':  '',
          'model':  'szqvaz',
          'ext3':  'jrikpbnmd',
          'productionYear':  'cpxv',
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color':  'qfzlo',
          'ext4':  'whaqzivz',
          'engineNo':  'aev',
          'brand':  'oicsjgngo',
          'vin':  'yoi',
          'maxSpeed':  5,
          'ext2':  'rdakuw',
          'fuel':  5,
          'id':  74,
          'remark':  'pkvpd',
          'imei':  1921231250,
          'ext1':  'kqy',
          'status':  1,
          'plateNo':  'mdullykasd',
          'plateType':  'mjfthexasd'
        }
      ],
      'size':  200,
      'nextPage':  20,
      'pages':  10
    },
    'code':  0,
    'msg':  'success'
  })

  // 获取rfid
  Mock.mock(URL + '/rfid/list', {
    'data':  {
      'total':  200,
      'pageNum':  1,
      'pageSize':  20,
      'list':  [
        {
          'model':  'otgoptgv',
          'ext3':  'naspvfplvp',
          'productionYear':  'jurrcqpx',
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color':  'omkqae',
          'ext4':  'jljmmvmap',
          'engineNo':  'zfubmwugi',
          'brand':  'pomqswpia',
          'vin':  'inbuayooym',
          'maxSpeed':  5,
          'ext2':  'uzabs',
          'fuel':  41,
          'id':  20,
          'remark':  'moitfms',
          'imei':  17566282949,
          'ext1':  'pihe',
          'status':  1,
          'plateNo':  'dzhjwqdhh',
          'plateType':  'spptv',
          'driverName':  'asdasd',
          'vehicleName':  'ufhsn',
          'creationDate':  '2019-03-29 10: 08: 30'
        },
        {
          'model':  'llyrrs',
          'ext3':  'spvtjefm',
          'productionYear':  'begdz',
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color':  'sfjpboma',
          'ext4':  'qjrtqpt',
          'engineNo':  'fkcvnsogu',
          'brand':  'otdlro',
          'vin':  'bbvgl',
          'maxSpeed':  12,
          'ext2':  'deouqycon',
          'fuel':  69,
          'id':  16,
          'remark':  'idytyg',
          'imei':  17516982848,
          'ext1':  'fuotd',
          'status':  2,
          'plateNo':  'gsumom',
          'plateType':  'ifpnrb',
          'driverName':  'osjfff',
          'vehicleName':  'fweewr',
          'creationDate':  '2019-03-29 10: 08: 30'
        },
        {
          'model':  'sycejzqvaz',
          'ext3':  'jrikpbnmd',
          'productionYear':  'cpxv',
          'imagePath':  'http: //tx.haiqq.com/uploads/allimg/170508/0954333D7-2.jpg',
          'color':  'qfzlo',
          'ext4':  'whaqzivz',
          'engineNo':  'aev',
          'brand':  'oicsjgngo',
          'vin':  'yoi',
          'maxSpeed':  5,
          'ext2':  'rdakuw',
          'fuel':  5,
          'id':  74,
          'remark':  'pkvpd',
          'imei':  19283587850,
          'ext1':  'kqy',
          'status':  1,
          'plateNo':  'mdullyk',
          'plateType':  'mjfthex',
          'driverName':  'ldgdja',
          'vehicleName':  'hghhs',
          'creationDate':  '2019-03-29 10: 08: 30'
        }
      ],
      'size':  200,
      'nextPage':  20,
      'pages':  10
    },
    'code':  0,
    'msg':  'success'
  })

  // 获取通知数量的列表
  Mock.mock(URL + '/notification/list', {
    'code':  0,
    'msg':  'sucess',
    'data':  {
      'pageSize':  20,
      'nextPage':  2,
      'list':  [
        {
          'notificationTime':  '2008-07-26',
          'id':  -8470721529353692,
          'content':  'ozhrdzpn',
          'currentValue':  'zapa',
          'status':  2,
          'source':  'otsw',
          'reminderName':  'zlpthd'
        },
        {
          'notificationTime':  '1978-03-31',
          'id':  127394543386204,
          'content':  'orepjx',
          'currentValue':  'mkv',
          'status':  1,
          'source':  'uwo',
          'reminderName':  'xjh'
        },
        {
          'notificationTime':  '1974-04-28',
          'id':  6397684712599370,
          'content':  'wfdq',
          'currentValue':  'fau',
          'status':  2,
          'source':  'fmiff',
          'reminderName':  'yowtjp'
        },
        {
          'notificationTime':  '2007-03-04',
          'id':  2690151894234134,
          'content':  'dmw',
          'currentValue':  'jjmg',
          'status':  2,
          'source':  'knvghg',
          'reminderName':  'xvk'
        },
        {
          'notificationTime':  '1990-01-25',
          'id':  8622257859703086,
          'content':  'bwtmlc',
          'currentValue':  'twzjc',
          'status':  2,
          'source':  'fijx',
          'reminderName':  'bptp'
        },
        {
          'notificationTime':  '1989-05-28',
          'id':  -6596855571858366,
          'content':  'ivp',
          'currentValue':  'drjnqozvs',
          'status':  2,
          'source':  'rtd',
          'reminderName':  'wrrihbxgwo'
        },
        {
          'notificationTime':  '1987-12-15',
          'id':  -8016387988269924,
          'content':  'cxrq',
          'currentValue':  'xpryhpis',
          'status':  1,
          'source':  'bmmoftnzun',
          'reminderName':  'tbjvmpev'
        },
        {
          'notificationTime':  '2002-05-07',
          'id':  -7177694661269250,
          'content':  'sghtv',
          'currentValue':  'cxuapri',
          'status':  1,
          'source':  'tkvjhbi',
          'reminderName':  'iaj'
        },
        {
          'notificationTime':  '1974-11-01',
          'id':  3954141649430698,
          'content':  'fed',
          'currentValue':  'bstwroyqm',
          'status':  2,
          'source':  'pjxvtdlxu',
          'reminderName':  'smvcgx'
        }
      ],
      'size':  20,
      'total':  20,
      'pages':  10,
      'pageNum':  1
    }
  })

  // 获取里程阈值
  Mock.mock(window._ctx + '/device/querymileageThreshold', {
    'code':  0,
    'msg':  'success',
    'data':  {
      'mileageThreshold':  158,
      'aCCOnDurtionThreshold':  123
    }
  })

  // 获取里程阈值
  Mock.mock(window._ctx + '/device/getTotalMilage', {
    'code':  0,
    'msg':  'success',
    'data':  {
      'maintenanceAlertFlag':  1,
      'mileage':  333,
      'runTime':  444
    }
  })

  // 获取提醒列表
  Mock.mock(URL + '/reminder/list', {
    'code':  0,
    'msg':  'success',
    'data':  [
      {'reminderName':  'asfdasd'}
    ]
  })

  Mock.mock(URL + '/routeplan/list', {
    'data':  {
      'list':  [
        {
          'imeis':  'ysfjll',
          'id':  '760a638f06164cf689b4419bdcb8432c',
          'description':  'nhpzwpib',
          'pathJson':  [
            {
              "lat": 32.565449,
              "lng": 102.711364
            },
            {
              "lat": 32.565449,
              "lng": 103.711364
            },
            {
              "lat": 32.565449,
              "lng": 104.711364
            },
            {
              "lat": 32.565449,
              "lng": 106.711364
            }
          ],
          'pathName':  'eotgvcsdu'
        },
        {
          'imeis':  'nrcfryc',
          'id':  44,
          'description':  'wcj',
          'pathJson':  [
            {
              "lat": 49.2761419673641,
              "lng": -123.118069007778
            },
            {
              "lat": 49.2791259862655,
              "lng": -123.129144031353
            },
            {
              "lat": 49.2704849721733,
              "lng": -123.125236002048
            },
            {
              "lat": 49.2732990317854,
              "lng": -123.117229946411
            }
          ],
          'pathName':  'bhyorf'
        },
        {
          'imeis':  'sdkn',
          'id':  38,
          'description':  'smoraxmm',
          'pathJson':  [
            {
              "lat": 37.772323,
              "lng": -122.214897
            },
            {
              "lat": 21.291982,
              "lng": -157.821856
            },
            {
              "lat": -18.142599,
              "lng": 178.431
            },
            {
              "lat": -27.46758,
              "lng": 153.027892
            }
          ],
          'pathName':  'ftdl'
        }
      ],
      'nextPage':  2,
      'pageNum':  1,
      'size':  20,
      'total':  200,
      'pages':  10,
      'pageSize':  10
    },
    'code':  0,
    'msg':  'success'
  })

  // 查询告警信息
  Mock.mock(URL + '/geozone/queryalarminfo', {
    'code':  0,
    'msg':  'success',
    'ok':  true,
    'data':  []
  })

  // 获取用户树初始化节点数据
  Mock.mock(URL + '/customer/getOrgUserTree', {
    'code':  0,
    'data':  [
      {
        'account':  'aaa',
        'appUpdateDevFlag':  '1',
        'checked':  false,
        'chkDisabled':  false,
        'deviceCount':  {
          'aboutToExpire': 0,
          'active': 4,
          'enabledFlag': 1,
          'expired': 0,
          'noOnlineNum': 0,
          'noactive': 0,
          'numStr': '4,4,0',
          'onLineNum': 0,
          'perActive': 4,
          'perNoActive': 0,
          'repertory': 4,
          'stock': 4,
          'userId': '76336',
          'userNum': 0
        },
        'fullParentId': '1,130396,130395,129765,',
        'iconSkin': 'onepoxy',
        'id': '76336',
        'isBatchSendFM': '1',
        'isBatchSendIns': '1',
        'isParent': false,
        'name': ' aaaa',
        'nickName': ' aaaa',
        'open': true,
        'pId': '129765',
        'phone': '',
        'type': 8,
        'updateDevFlag': '1'
      },
          {
              'account': '111222',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 2,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '2,2,0',
                  'onLineNum': 0,
                  'perActive': 1,
                  'perNoActive': 0,
                  'repertory': 2,
                  'stock': 1,
                  'userId': '130309',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130309',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': true,
              'name': '111222',
              'nickName': '111222',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '0'
          },
          {
              'account': '201711076666627',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 10,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 5,
                  'numStr': '15,10,5',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 1,
                  'repertory': 15,
                  'stock': 1,
                  'userId': '129882',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129882',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': true,
              'name': '2017110766666',
              'nickName': '2017110766666',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 9,
              'updateDevFlag': '1'
          },
          {
              'account': '201711076666628',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 1,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 1,
                  'numStr': '2,1,1',
                  'onLineNum': 0,
                  'perActive': 1,
                  'perNoActive': 1,
                  'repertory': 2,
                  'stock': 2,
                  'userId': '129883',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129883',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': false,
              'name': '201711076666628',
              'nickName': '201711076666628',
              'open': true,
              'pId': '129765',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '201711076666629',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 1,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 1,
                  'numStr': '2,1,1',
                  'onLineNum': 0,
                  'perActive': 1,
                  'perNoActive': 1,
                  'repertory': 2,
                  'stock': 2,
                  'userId': '129884',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129884',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': false,
              'name': '201711076666629',
              'nickName': '201711076666629',
              'open': true,
              'pId': '129765',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '201711076666630',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 2,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 2,
                  'numStr': '4,2,2',
                  'onLineNum': 0,
                  'perActive': 2,
                  'perNoActive': 2,
                  'repertory': 4,
                  'stock': 4,
                  'userId': '129885',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129885',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': false,
              'name': '201711076666630',
              'nickName': '201711076666630',
              'open': true,
              'pId': '129765',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '201711076666631',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 1,
                  'numStr': '1,0,1',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 1,
                  'repertory': 1,
                  'stock': 1,
                  'userId': '129888',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129888',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': true,
              'name': '201711076666631',
              'nickName': '201711076666631',
              'open': true,
              'pId': '129765',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '201711076666633',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 1,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '1,1,0',
                  'onLineNum': 0,
                  'perActive': 1,
                  'perNoActive': 0,
                  'repertory': 1,
                  'stock': 1,
                  'userId': '129890',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129890',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': false,
              'name': '201711076666633',
              'nickName': '201711076666633',
              'open': true,
              'pId': '129765',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '201711076666635',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 1,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 3,
                  'numStr': '4,1,3',
                  'onLineNum': 0,
                  'perActive': 1,
                  'perNoActive': 3,
                  'repertory': 4,
                  'stock': 4,
                  'userId': '129896',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129896',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': false,
              'name': '201711076666635',
              'nickName': '201711076666635',
              'open': true,
              'pId': '129765',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '201711076666651',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 1,
                  'numStr': '1,0,1',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 1,
                  'repertory': 1,
                  'stock': 1,
                  'userId': '129911',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129911',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': false,
              'name': '201711076666651',
              'nickName': '201711076666651',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '201711076666652',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 1,
                  'numStr': '1,0,1',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 1,
                  'repertory': 1,
                  'stock': 1,
                  'userId': '129912',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129912',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': false,
              'name': '201711076666652',
              'nickName': '201711076666652',
              'open': true,
              'pId': '129765',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '201711076666654',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 1,
                  'numStr': '1,0,1',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 1,
                  'repertory': 1,
                  'stock': 1,
                  'userId': '129914',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129914',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': false,
              'name': '201711076666654',
              'nickName': '201711076666654',
              'open': true,
              'pId': '129765',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '201711079999906',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '129915',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129915',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '201711079999906',
              'nickName': '201711079999906',
              'open': true,
              'pId': '129765',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': '2222222222222222222222222',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '130006',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130006',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '22222222222222',
              'nickName': '22222222222222',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '0'
          },
          {
              'account': '33.3',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '130306',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130306',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '33.3',
              'nickName': '33.3',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '1'
          },
          {
              'account': '333',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 4,
                  'numStr': '4,0,4',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 4,
                  'repertory': 4,
                  'stock': 4,
                  'userId': '130010',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130010',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '333',
              'nickName': '333',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '0'
          },
          {
              'account': '5544',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '130387',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '5544',
              'nickName': '5544',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '1'
          },
          {
              'account': '5566',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '130385',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '130385',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '5566',
              'nickName': '5566',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '1'
          },
          {
              'account': '659323981@qq.com',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '129994',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '129994',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '659323981@qq.com',
              'nickName': '659323981@qq.com',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '0'
          },
          {
              'account': '6655',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '130388',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '6655',
              'nickName': '6655',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '1'
          },
          {
              'account': '6688',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '130391',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '6688',
              'nickName': '6688',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '1'
          },
          {
              'account': '9999988888',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '129966',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '129966',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': '9999988888',
              'nickName': '9999988888',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '0'
          },
          {
              'account': 'aaaaaaaaa',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 1,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '1,1,0',
                  'onLineNum': 0,
                  'perActive': 1,
                  'perNoActive': 0,
                  'repertory': 1,
                  'stock': 1,
                  'userId': '129939',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '129939',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': 'aaaaaaaaa',
              'nickName': 'aaaaaaaaa',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '0'
          },
          {
              'account': 'b-b88@vip.163.com',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 2,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 7,
                  'numStr': '9,1,8',
                  'onLineNum': 0,
                  'perActive': 1,
                  'perNoActive': 8,
                  'repertory': 9,
                  'stock': 9,
                  'userId': '129775',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129775',
              'isBatchSendFM': '0',
              'isBatchSendIns': '0',
              'isParent': false,
              'name': 'b-b88@vip.163.com',
              'nickName': 'b-b88@vip.163.com',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': 'bbbbb',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 2,
                  'numStr': '2,0,2',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 2,
                  'repertory': 2,
                  'stock': 2,
                  'userId': '130299',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '130299',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': 'bbbbb',
              'nickName': 'bbbbb',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '0'
          },
          {
              'account': 'jimi111',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '130379',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '130379',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': true,
              'name': 'jimi111',
              'nickName': 'jimi111',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '1'
          },
          {
              'account': 'liuyang1',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 4,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 1,
                  'numStr': '5,4,1',
                  'onLineNum': 0,
                  'perActive': 4,
                  'perNoActive': 1,
                  'repertory': 5,
                  'stock': 5,
                  'userId': '130305',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '130305',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': 'liuyang1',
              'nickName': 'liuyang1',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 9,
              'updateDevFlag': '0'
          },
          {
              'account': 'ocean0124',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '130375',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '130375',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': true,
              'name': 'ocean0124',
              'nickName': 'ocean0124',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '1'
          },
          {
              'account': 'tan',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 7,
                  'numStr': '7,0,7',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 7,
                  'repertory': 7,
                  'stock': 7,
                  'userId': '130308',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130308',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': 'tan',
              'nickName': 'tan',
              'open': true,
              'pId': '129765',
              'phone': '65465465',
              'type': 11,
              'updateDevFlag': '1'
          },
          {
              'account': 'Tancy',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '130355',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130355',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': true,
              'name': 'Tan Chuangyu',
              'nickName': 'Tan Chuangyu',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '1'
          },
          {
              'account': 'test2222',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 32,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 49,
                  'numStr': '89,32,57',
                  'onLineNum': 0,
                  'perActive': 9,
                  'perNoActive': 30,
                  'repertory': 81,
                  'stock': 42,
                  'userId': '129766',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '129766',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': true,
              'name': 'test22222222',
              'nickName': 'test22222222',
              'open': true,
              'pId': '129765',
              'phone': '158-5858-9458',
              'type': 8,
              'updateDevFlag': '0'
          },
          {
              'account': 'ts_test111',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '130352',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130352',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': 'ts_test111',
              'nickName': 'ts_test111',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '0'
          },
          {
              'account': 'ttttss',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '130384',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'onepoxy',
              'id': '130384',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': 'ttttss',
              'nickName': 'ttttss',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 8,
              'updateDevFlag': '1'
          },
          {
              'account': 'zou',
              'appUpdateDevFlag': '0',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 5,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 1,
                  'numStr': '6,5,1',
                  'onLineNum': 0,
                  'perActive': 3,
                  'perNoActive': 1,
                  'repertory': 6,
                  'stock': 4,
                  'userId': '130003',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130003',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': true,
              'name': 'zou',
              'nickName': 'zou',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '0'
          },
          {
              'account': 'zou5',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 9,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 9,
                  'stock': 0,
                  'userId': '130363',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130363',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': true,
              'name': 'zou',
              'nickName': 'zou',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '1'
          },
          {
              'account': 'zou3',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 8,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '8,8,0',
                  'onLineNum': 0,
                  'perActive': 8,
                  'perNoActive': 0,
                  'repertory': 8,
                  'stock': 8,
                  'userId': '129992',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'ptuser',
              'id': '129992',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': 'zou3',
              'nickName': 'zou3',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 9,
              'updateDevFlag': '1'
          },
          {
              'account': 'zou4',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 0,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 0,
                  'numStr': '0,0,0',
                  'onLineNum': 0,
                  'perActive': 0,
                  'perNoActive': 0,
                  'repertory': 0,
                  'stock': 0,
                  'userId': '130362',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,129765,',
              'iconSkin': 'xiaoshou',
              'id': '130362',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': false,
              'name': 'zou4',
              'nickName': 'zou4',
              'open': true,
              'pId': '129765',
              'phone': '',
              'type': 11,
              'updateDevFlag': '1'
          },
          {
              'account': 'tanjie',
              'appUpdateDevFlag': '1',
              'checked': false,
              'chkDisabled': false,
              'deviceCount': {
                  'aboutToExpire': 0,
                  'active': 132,
                  'enabledFlag': 1,
                  'expired': 0,
                  'noOnlineNum': 0,
                  'noactive': 296,
                  'numStr': '430,135,295',
                  'onLineNum': 0,
                  'perActive': 60,
                  'perNoActive': 205,
                  'repertory': 428,
                  'stock': 263,
                  'userId': '129765',
                  'userNum': 0
              },
              'fullParentId': '1,130396,130395,',
              'iconSkin': 'onepoxy',
              'id': '129765',
              'isBatchSendFM': '1',
              'isBatchSendIns': '1',
              'isParent': true,
              'name': 'tanjie11',
              'nickName': 'tanjie11',
              'open': true,
              'pId': '130395',
              'phone': '13333333',
              'type': 8,
              'updateDevFlag': '1'
          }
      ],
      'ok': true
  })

  // 获取设备树初始化节点数据
  Mock.mock(URL + '/device/getReportDevice',{
    "code":0,
    "data":[
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"201711071234010",
            "isParent":false,
            "name":"-34010",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"-34010"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"201711076666605",
            "isParent":false,
            "name":"-66605",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"-66605"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"351510090054654",
            "isParent":false,
            "name":"A123",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"A123"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"353549090107434",
            "isParent":false,
            "name":"AATT333-07434",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"AATT333-07434"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"201711072563002",
            "isParent":false,
            "name":"AATT333-63002",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"AATT333-63002"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"201711076666604",
            "isParent":false,
            "name":"AT3-66604",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"AT3-66604"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"351608088226927",
            "isParent":false,
            "name":"GT300-26927",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"GT300-26927"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"201711078888871",
            "isParent":false,
            "name":"GT360-88871",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"GT360-88871"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"351608086729378",
            "isParent":false,
            "name":"GT710-29378",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"GT710-29378"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"357730090134207",
            "isParent":false,
            "name":"JC20000-34207",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"JC20000-34207"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"user_device",
            "id":"201711074445583",
            "isParent":false,
            "name":"我是AT3-45583",
            "open":false,
            "pId":"2304459fcaa042bd9658ca2e057609ed",
            "vehicleId":"我是AT3-45583"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"group",
            "id":"2304459fcaa042bd9658ca2e057609ed",
            "isParent":true,
            "name":"默认组(11)",
            "open":true,
            "pId":"0"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"group",
            "id":"e79165c3481f439796b6b7d99c9e741f",
            "isParent":true,
            "name":"test(14)",
            "open":false,
            "pId":"0"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"group",
            "id":"82a15c8d054448b2a8da0fec2c81c79d",
            "isParent":true,
            "name":"222(2)",
            "open":false,
            "pId":"0"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"group",
            "id":"9eea457c5e0f42b6a9132fe6740a6088",
            "isParent":true,
            "name":"特殊他.(2)",
            "open":false,
            "pId":"0"
        },
        {
            "checked":false,
            "chkDisabled":false,
            "chkExpire":false,
            "divCount":0,
            "iconSkin":"group",
            "id":"bb2f819820a649fab5cea28b323ba47b",
            "isParent":true,
            "name":"111(16)",
            "open":false,
            "pId":"0"
        }
    ],
    "ok":true
  })

  Mock.mock(URL + '/customer/getLowerUser', {
    "code":0,
    "data":[
        {
            "account":"111 111",
            "appUpdateDevFlag":"0",
            "checked":false,
            "chkDisabled":false,
            "deviceCount":{
                "aboutToExpire":0,
                "active":10,
                "enabledFlag":1,
                "expired":0,
                "noOnlineNum":0,
                "noactive":4,
                "numStr":"14,10,4",
                "onLineNum":0,
                "perActive":0,
                "perNoActive":1,
                "repertory":14,
                "stock":1,
                "userId":"130026",
                "userNum":0
            },
            "fullParentId":"1,130396,130395,129765,129882,",
            "iconSkin":"xiaoshou",
            "id":"130026",
            "isBatchSendFM":"1",
            "isBatchSendIns":"1",
            "isParent":true,
            "name":"111 111",
            "nickName":"111 111",
            "open":true,
            "pId":"129882",
            "phone":"11",
            "type":11,
            "updateDevFlag":"0"
        }
    ],
    "ok":true
  })
}

export {monitorInit}
