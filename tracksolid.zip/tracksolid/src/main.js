// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill' // es6语法补丁
import Vue from 'vue'
import App from './App'

// 引用 axios 配置
import axios from '@/axios/index'

// 引用 router 配置
import router from '@/router/index'

// 引用 vuex store 配置
import store from '@/store/index'

// 引入echarts
import echarts from 'echarts'

// 使用 element-ui
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import locale from 'element-ui/lib/locale/lang/en.js'

// 引用页面公共样式
import '@/common/less/index.less'
import '@/common/font-awesome-4.7.0/css/font-awesome.min.css'

// 引用页面公共 js
import { getLocal, getAccount } from '@/common/js/common'

// 引入MOCK数据
import {monitorInit} from '@/mock/data.js'
if (process.env.NODE_ENV === 'development') {
  monitorInit()
}

Vue.config.productionTip = false
Vue.use(ElementUI, { locale })
Vue.prototype.$echarts = echarts
// 设置全局变量 - 设置国际化语言包和账户名
Vue.prototype.Local = getLocal()
Vue.prototype.Account = getAccount()

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  axios,
  components: { App },
  template: '<App/>'
})
