/*!
 * 项目常量
 */

// import { getHost } from '@/common/js/common'

// let host = getHost()

// 异步请求地址
// export const URL = '//' + host + '/fleet'

// 无token返回的地址 / 用户退出时
// export const GO_BACK_URL = '//' + host + '/mainFrame'

// localstorage 中的用户凭证相关的key / 异步请求时head中携带用户凭证相关的key
// export const USE_TOKEN_KEY = 'token'

// localstorage 中的导航栏状态的key
// export const USE_NAV_STATUS = 'navStatus'

// 以下测试使用

// 异步请求地址
export const URL = 'http://172.16.0.121:8683'
// 'http://ceshi.track9999.com:8066/fleet';

// 无token返回的地址 / 用户退出时
export const GO_BACK_URL = 'http://172.16.0.121:8280/fleetIndex'
// localstorage 中的用户凭证相关的key / 异步请求时head中携带用户凭证相关的key
export const USE_TOKEN_KEY = 'token'

// localstorage 中的导航栏状态的key
export const USE_NAV_STATUS = 'navStatus'
