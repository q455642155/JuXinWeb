/*!
 * actions.js 用于修改 store 数据源和其他操作的方法
 */

// Action 类似于 mutation，不同在于：
// Action 提交的是 mutation，而不是直接变更状态。
// Action 可以包含任意异步操作。
// 改变多个 mutation的情况下

import * as types from './mutation-types'
import { GO_BACK_URL, USE_TOKEN_KEY, USE_NAV_STATUS } from '@/config'

// 用户退出
export const logout = function ({commit}) {
  commit(types.SET_TOKEN, '')
  commit(types.REMOVE_ORDERONE)
  commit(types.REMOVE_ORDERTWO)
  commit(types.REMOVE_ORDERTHREE)
  commit(types.REMOVE_QUANTITYONE)
  commit(types.REMOVE_QUANTITYTWO)
  commit(types.REMOVE_QUANTITYTHREE)
  commit(types.REMOVE_MAINTANCETYPE)
  commit(types.REMOVE_BEHAVIORTYPE)
  commit(types.REMOVE_DATERANGE)
  if (window.parent) {
    window.parent.localStorage.removeItem(USE_TOKEN_KEY)
    window.parent.location.href = GO_BACK_URL
    window.localStorage.removeItem('username')
    window.parent.logout()
  } else {
    window.localStorage.removeItem(USE_TOKEN_KEY)
    window.localStorage.removeItem('username')
    window.location.href = GO_BACK_URL
  }
}

// 用户控制导航栏
export const toggleNavStatus = function ({commit, state}, status) {
  commit(types.SET_NAV_STATUS, status)
  window.localStorage.setItem(USE_NAV_STATUS, status)
}

// 用户控制导航伸缩
export const slideNavStatus = function ({commit}, status) {
  commit(types.SET_NAV_SLIDE, status)
}
