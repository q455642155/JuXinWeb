/*!
 * mutation-types.js 用于保存 mutation 所需的常量
 */

export const SET_TOKEN = 'SET_TOKEN'
export const SET_NAV_STATUS = 'SET_NAV_STATUS'
export const SET_COUNT = 'SET_COUNT'
