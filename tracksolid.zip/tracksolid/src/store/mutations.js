/*!
 * mutations.js 用于修改 store 数据源的方法
 */

import * as types from './mutation-types'

// 接受两个参数 将传入的新值 赋值给store里面的数据源
const mutations = {
  [types.SET_TOKEN] (state, token) {
    state.token = token
  },
  [types.SET_NAV_STATUS] (state, status) {
    state.navStatus = status
  },
  [types.SET_COUNT] (state, count) {
    state.count = count
  }
}

export default mutations
