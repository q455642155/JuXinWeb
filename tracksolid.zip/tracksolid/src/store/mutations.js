/*!
 * mutations.js 用于修改 store 数据源的方法
 */

import * as types from './mutation-types'

// 接受两个参数 将传入的新值 赋值给store里面的数据源
const mutations = {
  [types.SET_TOKEN] (state, token) {
    state.token = token
  },
  [types.SET_NAV_STATUS] (state, status) {
    state.navStatus = status
  },
  [types.SET_NAV_SLIDE] (state, status) {
    state.navSlide = !state.navSlide
  },
  [types.SET_COUNT] (state, count) {
    state.count = count
  },
  [types.SET_ORDERONE] (state, orderByOne) {
    state.orderByOne = orderByOne
  },
  [types.SET_ORDERTWO] (state, orderByTwo) {
    state.orderByTwo = orderByTwo
  },
  [types.SET_ORDERTHREE] (state, orderByThree) {
    state.orderByThree = orderByThree
  },
  [types.SET_QUANTITYONE] (state, quantityOne) {
    state.quantityOne = quantityOne
  },
  [types.SET_QUANTITYTWO] (state, quantityTwo) {
    state.quantityTwo = quantityTwo
  },
  [types.SET_QUANTITYTHREE] (state, quantityThree) {
    state.quantityThree = quantityThree
  },
  [types.SET_MAINTANCETYPE] (state, mainTance) {
    state.mainTance = mainTance
  },
  [types.SET_BEHAVIORTYPE] (state, behaviorType) {
    state.behaviorType = behaviorType
  },
  [types.SET_DATERANGE] (state, timeRange) {
    state.timeRange = timeRange
  },
  [types.REMOVE_ORDERONE] (state, orderByOne) {
    state.orderByOne = ''
  },
  [types.REMOVE_ORDERTWO] (state, orderByTwo) {
    state.orderByTwo = ''
  },
  [types.REMOVE_ORDERTHREE] (state, orderByThree) {
    state.orderByThree = ''
  },
  [types.REMOVE_QUANTITYONE] (state, quantityOne) {
    state.quantityOne = 3
  },
  [types.REMOVE_QUANTITYTWO] (state, quantityTwo) {
    state.quantityTwo = 3
  },
  [types.REMOVE_QUANTITYTHREE] (state, quantityThree) {
    state.quantityThree = 3
  },
  [types.REMOVE_BEHAVIORTYPE] (state, behaviorType) {
    state.behaviorType = ''
  },
  [types.REMOVE_MAINTANCETYPE] (state, mainTance) {
    state.mainTance = ''
  },
  [types.REMOVE_DATERANGE] (state, timeRange) {
    state.timeRange = null
  }
}

export default mutations
