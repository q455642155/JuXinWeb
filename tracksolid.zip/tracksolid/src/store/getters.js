/*!
 * getters.js 用于在 vue 组件获取 state 里的数据源
 */

export const token = state => state.token
export const navStatus = state => state.navStatus
export const navSlide = state => state.navSlide
export const count = state => state.count
