/*!
 * Vuex 相关配置
 */

import Vue from 'vue'
import Vuex from 'vuex'
import createLogger from 'vuex/dist/logger' // vuex 调试工具 console.log(state)的改变 对性能有所损耗

import * as actions from './actions'
import * as getters from './getters'
import state from './state'
import mutations from './mutations'

// 使用 Vuex
Vue.use(Vuex)

// 非生产环境下调试
const debug = process.env.NODE_ENV !== 'production'

// 创建 Store
export default new Vuex.Store({
  state,
  getters,
  mutations,
  actions,
  strict: debug, // debug == true 时则开启严格模式，无论何时发生了状态变更且不是由 mutation 函数引起的，将会抛出错误。这能保证所有的状态变更都能被调试工具跟踪到。
  plugins: debug ? [createLogger()] : [] // debug == true 非生产环境下使用调试工具
})
