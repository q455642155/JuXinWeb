/*!
 * state.js 用于保存数据源
 */

// 获取浏览器 localstorage 中的用户凭证
import { loadToken, loadNavStatus } from '@/common/js/localStorage'

const state = {
  token: loadToken(), // 用户凭证
  navStatus: loadNavStatus(), // 导航栏状态 true-缩小/false-正常
  count: 0 // 未读消息
}

export default state
