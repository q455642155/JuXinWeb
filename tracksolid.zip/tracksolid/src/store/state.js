/*!
 * state.js 用于保存数据源
 */

// 获取浏览器 localstorage 中的用户凭证
import { loadToken, loadNavStatus } from '@/common/js/localStorage'
// import { loadToken } from '@/common/js/localStorage'

const state = {
  token: loadToken(), // 用户凭证
  navStatus: loadNavStatus(),
  navSlide: true,
  count: 0, // 未读消息
  orderByOne: '', // 油耗排序
  quantityOne: 3, // 油耗设备数量
  mainTance: '', // 保养类型
  orderByTwo: '', // 里程排序
  quantityTwo: 3, // 里程设备数量
  orderByThree: '', // 行为排序
  quantityThree: 3, // 行为设备数量
  timeRange: null, // 时间
  behaviorType: 'overSpeed,41,42,43,44,48' // 行为类型
}

export default state
