/*!
 * Vue 组件公共的部分
 */
import { timestampToTime } from '@/common/js/common'

// 页面表格公共的js
export const tableMixin = {
  data () {
    return {
      // 表格加载状态
      loading: false,
      // 表格当前页数据列表
      tableData: {},
      // 表格被选中行的集合
      multipleSelection: [],
      // 表格被选中行id的集合
      ids: [],
      // 表格当前正在操作的行
      currentSelectRow: {},
      // 表格当前页/点击分页时候的当前页 - 默认显示第一页
      currentPage: 1,
      // 表格当前每页显示多少条数据 - 默认显示10条
      limitSize: 10,
      // 设置表格当前每页显示多少条数据的选项
      limitSizes: [10, 20, 30, 40]
    }
  },
  created () {
    // Table - 获取表格数据异步请求
    this.getTableData()
  },
  methods: {
    // Table - 计算表格行的索引
    indexMethod (index) {
      return (this.currentPage * this.limitSize) - this.limitSize + index + 1
    },
    // Table - 全选/全不选
    handleSelectAll (rows) {
      // 全选
      if (rows) {
        this.ids = rows
      // 全不选
      } else {
        this.ids = rows
      }
    },
    // Table - 切换选择
    handleSelectionChange (val) {
      this.ids = []
      if (val.length) {
        this.multipleSelection = val
        val.forEach(row => {
          this.ids.push(row.id)
        })
      }
    },
    // Table - 选择分页
    handleCurrentChange (val) {
      this.currentPage = val
      this.getTableData()
    },
    // Table - 选择分页显示条数
    handleSizeChange (val) {
      this.limitSize = val
      this.getTableData()
    },
    // Table - 单行删除
    handleDelete (index, row) {
      this.ids = []
      this.ids.push(row.id)
      this.tableRowsDelete(this.ids)
    },
    // Table - 多行删除
    tableAllRowsDelete () {
      let ids = this.ids
      this.tableRowsDelete(ids)
    },
    // 时间戳转化成日期
    timestampToTime (timestamp, isTrue) {
      return timestampToTime(timestamp, isTrue)
    }
  }
}
