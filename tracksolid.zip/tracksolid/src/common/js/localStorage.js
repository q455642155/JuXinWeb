/*!
 * localStorage 相关内容
 */

import { USE_TOKEN_KEY, USE_NAV_STATUS } from '@/config'

// 获取浏览器 localstorage 中的用户凭证
export function loadToken () {
  let token
  if (window.parent.localStorage.getItem(USE_TOKEN_KEY) || window.localStorage.getItem(USE_TOKEN_KEY)) {
    token = window.parent.localStorage.getItem(USE_TOKEN_KEY) ? window.parent.localStorage.getItem(USE_TOKEN_KEY) : window.localStorage.getItem(USE_TOKEN_KEY)
  } else {
    // token = ''

    // 测试使用
    token = 'MTI5NzY1MTU1MzA2NDkwNzIzNw'
  }
  return token
}

// 获取浏览器 localstorage中的导航栏状态
export function loadNavStatus () {
  let navStatus = window.localStorage.getItem(USE_NAV_STATUS) && window.localStorage.getItem(USE_NAV_STATUS) === 'true' ? window.localStorage.getItem(USE_NAV_STATUS) : false
  return navStatus
}
