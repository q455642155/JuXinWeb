/*!
 * 公共的js
 */

// 封装 window.onload
export function addLoadEvent (func) {
  var oldonload = window.onload
  if (typeof window.onload !== 'function') {
    window.onload = func
  } else {
    window.onload = function () {
      oldonload()
      func()
    }
  }
}

// 获取父窗口的国际化语言包
export function getLocal () {
  var i18n = null
  if (window.parent && window.parent.i18Obj) {
    i18n = window.parent.i18Obj
  }
  return i18n
}

// 获取父窗口的账户信息
export function getAccount () {
  var account = ''
  if (window.parent && window.parent.account) {
    account = window.parent.account
  }
  return account
}

// 时间相关START
// 小于10 在前面自动补0
export function zeroize (val) {
  var newVal = ''
  if (val) {
    newVal = val < 10 ? '0' + val : val
  }
  return newVal
}

// 时间戳转化成日期 type-为false或者不传入日期截取到day,为true日期截取到time 格式2018-05-06 12:01:02
export function timestampToTime (timestamp, type) {
  // var date = new Date(timestamp * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
  var date = new Date(timestamp)
  var time = ''
  var Y = date.getFullYear() + '-'
  var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-'
  var D = date.getDate() < 10 ? '0' + date.getDate() + ' ' : date.getDate() + ' '

  if (type) {
    var h = date.getHours() < 10 ? '0' + date.getHours() + ':' : date.getHours() + ':'
    var m = date.getMinutes() < 10 ? '0' + date.getMinutes() + ':' : date.getMinutes() + ':'
    var s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()
    time = Y + M + D + h + m + s
  } else {
    time = Y + M + D
  }
  return time
}

// 时间戳转化成日期 type为false或者不传入日期截取到day,为true日期截取到time 格式20180506120102
export function timestampToExport (timestamp) {
  // var date = new Date(timestamp * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
  var date = new Date(timestamp)
  var time = ''
  var Y = date.getFullYear()
  var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1)
  var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate()
  var h = date.getHours() < 10 ? '0' + date.getHours() : date.getHours()
  var m = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()
  var s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()
  // eslint-disable-next-line no-new-wrappers
  time = new String(Y) + new String(M) + new String(D) + new String(h) + new String(m) + new String(s)
  return time
}

// 日期转化为时间戳
export function timeToTimestamp (time) {
  var date = new Date(time)
  // var timestamp = date.getTime(); // 精确到毫秒
  // var timestamp = date.valueOf(); // 精确到毫秒
  var timestamp = Date.parse(date) // 精确到秒 毫秒以000替代
  return timestamp
}

// 导出相关 根据请求返回的res 进行文件的下载导出
export function downloadExport (res) {
  var time = timestampToExport(Date.parse(new Date()), true)
  var fileName = 'export'
  // 获取文件的地址 修改 fileName
  if (res.config && res.config.url) {
    if (res.config.url.indexOf('driver') > 0) {
      fileName = 'Driver' + time + '.xls'
    } else if (res.config.url.indexOf('vehicle') > 0) {
      fileName = 'Vehicle' + time + '.xls'
    } else if (res.config.url.indexOf('notification') > 0) {
      fileName = 'Notification' + time + '.xls'
    } else {
      fileName = 'Export' + time + '.xls'
    }
  } else {
    fileName = 'Export' + time + '.xls'
  }
  const blob = new Blob([res.data], {type: 'application/vnd.ms-excel;charset=utf-8;'})
  if ('download' in document.createElement('a')) { // 非IE下载
    const elink = document.createElement('a')
    elink.download = fileName
    elink.style.display = 'none'
    elink.href = URL.createObjectURL(blob)
    document.body.appendChild(elink)
    elink.click()
    URL.revokeObjectURL(elink.href) // 释放URL 对象
    document.body.removeChild(elink)
  } else { // IE10+下载
    navigator.msSaveBlob(blob, fileName)
  }
}

// 请求相关 根据 code 返回值提示信息 需要call this 来调用 this.$message
export function promptMessage (resCode) {
  switch (resCode) {
    case 0:
      this.$message({
        message: this.Local ? this.Local.prop('Business.Success') : 'Success',
        center: true,
        type: 'success'
      })
      break
    case 400:
      this.$message({
        message: this.Local ? this.Local.prop('Alert.UserNoDevices') : 'Operation failed',
        center: true,
        type: 'error'
      })
      break
    case 401:
      this.$message({
        message: this.Local ? this.Local.prop('Fleet.LoginTimeout') : 'Login Timeout',
        center: true,
        type: 'error'
      })
      break
    case 402:
      this.$message({
        message: this.Local ? this.Local.prop('Fleet.InvalidRamoteIp') : 'Invalid remote ip',
        center: true,
        type: 'error'
      })
      break
    case 403:
      this.$message({
        message: this.Local ? this.Local.prop('cust.VirtualAccountPermissionDenied') : 'No permission',
        center: true,
        type: 'error'
      })
      break
    case 500:
      this.$message({
        message: this.Local ? this.Local.prop('Alert.UserNoDevices') : 'Operation failed',
        center: true,
        type: 'error'
      })
      break
    default:
      this.$message({
        message: this.Local ? this.Local.prop('Alert.UserNoDevices') : 'Operation failed',
        center: true,
        type: 'error'
      })
  }
}

// 获取域名
export function getHost () {
  let newHost
  if (window.parent && window.parent.host) {
    newHost = window.parent.host
  }
  return newHost
}

// 获取当前时间和前n天时间
export function getCurrentDayAndBeforeDay (day) {
  var today = new Date()
  var milliseconds = today.getTime() + 1000 * 60 * 60 * 24 * day
  today.setTime(milliseconds) // 注意，这行是关键代码
  var tYear = today.getFullYear()
  var tMonth = today.getMonth() < 10 ? '0' + (today.getMonth() + 1) : today.getMonth() + 1
  var tDate = today.getDate() < 10 ? '0' + today.getDate() : today.getDate()
  return tYear + '-' + tMonth + '-' + tDate
}

// 数组从大到小进行排序
export function arrayHightToLow (arr) {
  for (var i = 0; i < arr.length; i++) {
    for (var j = 0; j < arr.length - i; j++) {
      if (arr[j] < arr[j + 1]) {
        // 数值交换
        var a = arr[j]
        arr[j] = arr[j + 1]
        arr[j + 1] = a
      }
    }
  }
  return arr
}

// 数组从小到大进行排序
export function arrayLowToHight (arr) {
  for (var i = 0; i < arr.length; i++) {
    for (var j = 0; j < arr.length - i; j++) {
      if (arr[j] > arr[j + 1]) {
        // 数值交换
        var a = arr[j]
        arr[j] = arr[j + 1]
        arr[j + 1] = a
      }
    }
  }
  return arr
}
