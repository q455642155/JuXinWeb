/*!
 * axios Token与拦截器相关配置
 */

import axios from 'axios'
import store from '@/store/index'
import { downloadExport } from '@/common/js/common'

// axios 全局配置
axios.defaults.timeout = 60000
axios.defaults.headers['Access-Control-Allow-Origin'] = '*'

// http request 拦截器
axios.interceptors.request.use(
  config => {
    if (store.state.token && store.state.token !== '') {
      config.headers.token = store.state.token
    }
    return config
  },
  err => {
    return Promise.reject(err)
  }
)

// http response 拦截器
axios.interceptors.response.use(
  response => {
    if (response) {
      // 下载导出 xls
      if (response.headers && (response.headers['content-type'] === 'application/vnd.ms-excel' || response.headers['content-type'] === 'application/vnd.ms-excel;charset=utf-8')) {
        downloadExport(response)
        return
      }
      // switch (response.data.code) {
      //   case 401:
      //   // 401 清除token信息并跳转到登录页面
      //   // eslint-disable-next-line indent
      //   store.dispatch('logout')
      // }
    }
    return response
  },
  error => {
    if (error.response) {
      switch (error.response.status) {
        case 401:
        // 401 清除token信息并跳转到登录页面
          store.dispatch('logout')
      }
    }
    return Promise.reject(error.response.data)
  })

export default axios
