<template>
	<el-dialog
		class="AddReminderDialog"
		width="20%"
		:title="Local ? Local.prop('Fleet.Driver.Reminder') + ' ' + Local.prop('cust.Detail') : 'Reminder Detail'"
		:top="reminderType ==1 ? '15vh' : '8vh'"
		:visible.sync="dialogVisible"
		:before-close="beforeClose"
		:append-to-body="type"
		:close-on-click-modal="false"
		:close-on-press-escape="false"
	>
		<el-row>
			<el-table
				:data="reminders"
				height="164"
				border
				stripe
				fit
				tooltip-effect="dark"
				style="width: 100%"
				:empty-text="Local ? Local.prop('comm.noData') : 'No data found'"
				:element-loading-text="Local ? Local.prop('comm.loadingData') : 'Loading...'"
				v-loading="loading"
				highlight-current-row
    			@row-click="handleCurrentChange"
			>
				<el-table-column
					:label="Local ? Local.prop('Alert.number') : 'No.'"
					width="55"
				>
					<template slot-scope="scope">
						{{scope.$index + 1}}
					</template>
				</el-table-column>

				<el-table-column
					prop="reminderName"
					:label="Local ? Local.prop('Fleet.Reminder.ReminderName') : 'Reminder Name'"
					width="344"
				>
				</el-table-column>

				<el-table-column
					:label="Local ? Local.prop('comm.Operate') : 'Actions'"
					align="center"
					width="120"
				>
					<template slot-scope="scope">
						<el-button @click.stop="handleDelete(scope.$index, scope.row)" class="btn-contorl" size="mini" type="danger" icon="el-icon-delete" circle></el-button>
					</template>
				</el-table-column>

			</el-table>
			<el-form ref="AddReminderform" :model="AddReminderform" status-icon :rules="rules" label-width="150px">
				<el-form-item 
					:label="Local ? Local.prop('Fleet.Reminder.ReminderName') : 'Reminder Name'" 
					prop="reminderName"
				>
					<div class="reminderContorl">
						<el-tooltip class="item" effect="dark" :content="Local ? Local.prop('Geozones.reset') : 'Reset'" placement="top">
							<el-button @click="reset()" class="btn-contorl" size="mini" icon="el-icon-close" circle></el-button>
						</el-tooltip>
						<el-popover
							placement="bottom-end"
							width="334"
							popper-class="allReminders"
							trigger="click">
							<el-table
								:data="allReminders"
								height="200"
								stripe
								fit
								tooltip-effect="dark"
								style="width: 100%"
								:empty-text="Local ? Local.prop('comm.noData') : 'No data found'"
								v-loading="allRemindersLoading"
								:element-loading-text="Local ? Local.prop('comm.loadingData') : 'Loading...'"
								element-loading-background="rgba(0, 0, 0, 0.8)"
								highlight-current-row
				    			@row-click="handleCurrentChangeOfAllReminders"
							>
								<el-table-column
									prop="reminderName"
									:label="Local ? Local.prop('Fleet.Reminder.ReminderName') : 'Reminder Name'"
								>
								</el-table-column>
							</el-table>
							<el-button slot="reference" @click="searchAllReminder()" class="btn-contorl" size="mini" icon="el-icon-arrow-down" circle></el-button>
						</el-popover>
					</div>
					<el-input 
						v-model.trim="AddReminderform.reminderName" 
						:placeholder="Local ? Local.prop('Fleet.Reminder.ReminderName') : 'Reminder Name'"
						:maxlength=50
					>
					</el-input>
				</el-form-item>

				<el-form-item 
					v-if="reminderType == 2" 
					:label="Local ? Local.prop('Fleet.Reminder.ReminderFactor') : 'Reminder Factor'"
				>
					<el-radio-group 
						class="reminderFactor" 
						v-model="AddReminderform.reminderFactor"
					>
						<el-radio :disabled="noImei" :label="'1'">
							{{ this.Local ? this.Local.prop('header.MileageReport') : 'Mileage' }}
							(
							{{ this.Local ? this.Local.prop('Asset.Alerts.Odometer') : 'Current Mileage' }}: 
							{{ this.mileage ? this.mileage : '0' }}{{ this.Local ? this.Local.prop('header.Statistics.Km'): 'km' }}
							)
						</el-radio>
						<el-radio :disabled="noImei" :label="'2'">
							{{ this.Local ? this.Local.prop('Asset.Alerts.ACCOnDuration') : 'ACC-ON Duration' }}
							(
							{{ this.Local ? this.Local.prop('Asset.Alerts.CurrentAccOnDuration') : 'Current Duration' }}:
							{{ this.acc ? this.acc : '0' }}{{ this.Local ? this.Local.prop('index.hour') : 'Hour' }}
							)
						</el-radio>
						<el-radio :label="'3'">
							{{ this.Local ? this.Local.prop('Commands.TimeMode') : 'Timing Mode' }}
						</el-radio>
					</el-radio-group>
				</el-form-item>

				<el-form-item 
					v-if="reminderType == 2" 
					:label="Local ? Local.prop('Fleet.Reminder.Interval') : 'Interval'" 
					prop="interval"
					ref="interval"
				>
					<div v-show="AddReminderform.reminderFactor == 1">
						<span class="unit">{{ this.Local ? this.Local.prop('header.Statistics.Km') : 'km' }}</span>
						<el-input 
							class="intervalTypesInput" 
							:maxlength=8 
							v-model.trim="AddReminderform.interval" 
							:placeholder="Local ? Local.prop('Fleet.Reminder.Interval') : 'Interval'"
						></el-input>
					</div>
					<div v-show="AddReminderform.reminderFactor == 2">
						<span class="unit">{{ this.Local ? this.Local.prop('index.hour') : 'Hour' }}</span>
						<el-input 
							class="intervalTypesInput" 
							v-model.trim="AddReminderform.interval" 
							:maxlength=8  
							:placeholder="Local ? Local.prop('Fleet.Reminder.Interval') : 'Interval'"
						></el-input>
					</div>
					<div v-show="AddReminderform.reminderFactor == 3">
						<el-select class="intervalTypes" v-model="AddReminderform.intervalType" >
							<el-option
								v-for="item in intervalTypes"
								:key="item.value"
								:label="item.label"
								:value="item.value"
							>
							</el-option>
						</el-select>
						<el-input 
							class="intervalTypesInput" 
							:maxlength=8  
							v-model.trim="AddReminderform.interval" 
							:placeholder="Local ? Local.prop('Fleet.Reminder.Interval') : 'Interval'"
						></el-input>
					</div>
				</el-form-item>

				<el-form-item 
					v-if="reminderType == 2 && AddReminderform.reminderFactor == 3" 
					:label="Local ? Local.prop('Fleet.Reminder.StartDate') : 'Start Date'"
				>
					<el-date-picker
						v-model="AddReminderform.startDate"
						type="date"
						:placeholder="Local ? Local.prop('Fleet.Reminder.StartDate') : 'Start Date'"
						class="startDate"
					>
					</el-date-picker>
				</el-form-item>

				<el-form-item 
					:label="Local ? Local.prop('Fleet.Reminder.RemindInAdvance') : 'Remind in Advance'"
					prop="remindAdvance"
				>
					<el-select class="advanceTypes" v-model="AddReminderform.advanceType" :disabled="AddReminderform.reminderFactor != 3" placeholder="">
						<el-option
							v-if="reminderType == 1"
							v-for="item in intervalTypes"
							:key="item.value"
							:label="item.label"
							:value="item.value"
						>
						</el-option>
						<el-option
							v-if="reminderType == 2 && AddReminderform.reminderFactor != 3"
							v-for="item in advanceTypes"
							:key="item.value"
							:label="item.label"
							:value="item.value"
						>
						</el-option>
						<el-option
							v-if="reminderType == 2 && AddReminderform.reminderFactor == 3"
							v-for="item in intervalTypes"
							:key="item.value"
							:label="item.label"
							:value="item.value"
						>
						</el-option>
					</el-select>
					<el-input 
						ref="intervalTypesInput"
						:maxlength=10
						class="intervalTypesInput" 
						v-model.trim="AddReminderform.remindAdvance" 
						:placeholder="Local ? Local.prop('Fleet.Reminder.RemindInAdvance') : 'Remind in Advance'"
					></el-input>
					<p class="tips" v-if="reminderType == 1">
						<i class="el-icon-warning"></i>
						{{ this.Local ? this.Local.prop('Fleet.Reminder.RemindMeInAdvance') : 'Remind me in advance.' }}
					</p>
				</el-form-item>

				<el-form-item 
					:label="Local ? Local.prop('Fleet.Reminder.NotificationEmail') : 'Notification Email'"
					prop="notificationEmail"
				>
					<el-input
						type="textarea"
						:maxlength=300 
						resize="none"
						:placeholder="Local ? Local.prop('Fleet.Reminder.NotificationEmail') : 'Notification Email'"
						:rows="2"
						v-model.trim="AddReminderform.notificationEmail"
					>
					</el-input>
					<p class="tips">
						<i class="el-icon-warning"></i>
						{{ this.Local ? this.Local.prop('Fleet.Reminder.SeperateByNewLine') : 'Seperate by new line.' }}
					</p>
				</el-form-item>
			</el-form>
		</el-row>
		<span slot="footer" class="dialog-footer">
			<el-button @click="hidden()">{{ this.Local ? this.Local.prop('index.Cancel') : 'Cancel' }}</el-button>
			<el-button type="primary" @click="save()">{{ this.Local ? this.Local.prop('comm.Save') : 'Save' }}</el-button>
		</span>
	</el-dialog>
</template>

<script type="text/ecmascript-6">
	import { getReminderData, updateReminder, deleteReminder, getCurrentMileage } from '@/api/Reminder'
	import { promptMessage,timestampToTime } from '@/common/js/common'
	
	export default {
		name: 'AddReminderDialog',
		props: {
			// 是否为嵌套的 Dialog
			type: {
				type: Boolean,
				default: false,
			},
			// 提醒关联类型 1.关联司机，2.关联车辆
			reminderType: {
				type: Number,
				default: null, 
			},
			// 提醒关联的司机或车辆id
			relationId: {
				type: String,
				default: null, 
			},
			// 提醒关联车辆的imei
			imei: {
				type: String,
				default: null,
			}
		},
		data() {
			// 定义规则

			var checkInterval = (rule, value, callback) => {
				if ( this.AddReminderform.reminderFactor == '1' ) {
					if ( !value || value < 1000 ) {
						callback(new Error(this.Local ? this.Local.prop('Alert.MilageAlarmIntervalMsg') : 'Maintenance Mileage should not less than 1000.'))
					} else {
						return callback();
					}
				} else if (this.AddReminderform.reminderFactor == '2') {
					if ( !value || value < 50 ) {
						callback(new Error(this.Local ? this.Local.prop('header.ACCONDurationThreshold') : 'ACC-ON Duration Threshold should not less than 50h.'))
					} else {
						return callback();
					}
				} else {
					return callback();
				}
			};

			var checkAdvance = (rule, value, callback) => {
				if (!value) {
					return callback();
				} else {
					function TypeToDay (type) {
						let day = 1
						switch(type) {
							case '1':
								day = 1
								break;
							case '2':
								day = 7
								break;
							case '3':
								day = 31
								break;
							case '4':
								day = 365
								break;
							default:
								day = 1
						}
						return day
					}
					let interval = this.AddReminderform.interval
					if(!interval) {
						return callback();
					}
					let intervalType = this.AddReminderform.intervalType
					let remindAdvance = value
					let advanceType = this.AddReminderform.advanceType
					let intervalTypeToDay = TypeToDay(intervalType)
					let intervalDay = interval * intervalTypeToDay
					let advanceTypeToDay = TypeToDay(advanceType)
					let remindAdvanceDay = remindAdvance * advanceTypeToDay
					if (remindAdvanceDay > intervalDay) {
						callback(new Error(this.Local ? this.Local.prop('Fleet.Reminder.RemindMeInAdvanceTip') : 'Remind in Advance time should not large than interval.'))
					} else {
						return callback();
					}
				}
			};

			return {
				// 显示隐藏
				dialogVisible: false,
				// Form - 表单内容
				AddReminderform: {
					id: null,
					reminderName: null,
					interval: null,
					intervalType: '1',
					remindAdvance: null,
					advanceType: '1',
					reminderFactor: '3',
					startDate: null,
					notificationEmail: null
				},
				// Form - 表单验证规则
				rules: {
					reminderName: [
						{ required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
					],
					interval: [
						{ required: false, message: this.Local ? this.Local.prop('Commands.FilledPositiveInteger') : 'This item can only be filled with a positive integer.', pattern: /^[0-9]+$/ },
						{ validator: checkInterval }
					],
					remindAdvance: [
						{ required: false, message: this.Local ? this.Local.prop('Commands.FilledPositiveInteger') : 'This item can only be filled with a positive integer.', pattern: /^[0-9]+$/ },
						{ validator: checkAdvance }
					],
					notificationEmail: [
						{ required: false, message: this.Local ? this.Local.prop('Alert.emailFormatError') : 'Email format error', pattern: /^((([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6}\n))*(([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})))$/ }
					]
				},
				// Form - 表单内容下 intervalType 多选框选项
				intervalTypes: [
					{
						value: '1',
						label: this.Local ? this.Local.prop('index.day') : 'Day'
					}, {
						value: '2',
						label: this.Local ? this.Local.prop('Fleet.Reminder.Week') : 'Week'
					}, {
						value: '3',
						label: this.Local ? this.Local.prop('Fleet.Reminder.Mouth') : 'Month'
					}, {
						value: '4',
						label: this.Local ? this.Local.prop('Fleet.Reminder.Year') : 'Year'
					},
				],
				// Form - 表单内容下 advanceType 多选框选项
				advanceTypes: [
					{
						value: '5',
						label: this.Local ? this.Local.prop('header.Statistics.Km') : 'km'
					}, {
						value: '6',
						label: this.Local ? this.Local.prop('index.hour') : 'Hour'
					}
				],
				// Table - 车辆或司机下 reminders 表格加载状态 
				loading: false,
				// 车辆或司机下 reminders 表格内容
				reminders: [],
				// Table - 用户下 all reminders 表格加载状态 
				allRemindersLoading: false,
				// Table - 用户下 all reminders 表格内容
				allReminders: [],
				// Form - 是否存在 imei
				noImei: true,
				// Form - 当前车辆里程
				mileage: null,
				// - 当前车辆持续时间
				acc: null,
			}
		},
		computed: {
			// 计算表单内容 reminderFactor 的类型并设置默认值
			reminderFactor() {
		　　　　return this.AddReminderform.reminderFactor ? this.AddReminderform.reminderFactor : '3'
		　　},
			// 计算传入的Imei变化与清空
			myimei: {
				get: function () {
					return this.imei ? this.imei : null
				},
				set: function (v) {
					
				}
			},
		},
		methods: {
			// Dialog - 显示并加载数据
			show() {
				this.reset()
				this.dialogVisible = true

				this.$nextTick(() => {	
					this.getReminderData()
					this.getCurrentMileage()
				})
			},
			// Dialog - 隐藏并重置表单
			hidden() {
				this.dialogVisible = false
				// 清空数据
				this.myimei = null
				this.myrelationId = null
				this.loading = true
				this.mileage = null
				this.reminders = []
				this.allReminders = []

				// this.reset()
			},
			// Form - 重置表单
			reset() {
				// 移除表单验证 重置表单
				this.AddReminderform = {
					id: null,
					reminderName: null,
					interval: null,
					intervalType: '1',
					remindAdvance: null,
					advanceType: '1',
					reminderFactor: '3',
					startDate: null,
					notificationEmail: null
				}

				this.$nextTick(() => {	
					this.$refs.AddReminderform.clearValidate()
				})
			},
			// Form - 搜索用户下所有的 Reminders
			searchAllReminder() {
				var relationId = null
				var reminderType = this.reminderType
				this.allRemindersLoading = true

				getReminderData(relationId,reminderType).then((res)=>{
					if (res.code === 0) {
						this.allRemindersLoading = false
						this.allReminders = res.data
						return
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this,res.code)
				}).catch((e)=>{
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
				})
			},
			// Form - 保存数据
			save() {
				this.$refs.AddReminderform.validate((valid) => {
					if (valid) {
						let id = this.AddReminderform.id
						let relationId = this.relationId
						let reminderType = this.reminderType
						let reminderName = this.AddReminderform.reminderName
						let interval = this.AddReminderform.interval
						let intervalType = this.AddReminderform.intervalType
						let remindAdvance = this.AddReminderform.remindAdvance
						let advanceType = this.AddReminderform.advanceType
						let reminderFactor = this.AddReminderform.reminderFactor
						let startDateStr = this.AddReminderform.startDate ? timestampToTime(this.AddReminderform.startDate,true) : null
						let notificationEmail = this.AddReminderform.notificationEmail

						updateReminder(id,relationId,reminderName,reminderType,interval,intervalType,remindAdvance,advanceType,reminderFactor,startDateStr,notificationEmail).then((res)=>{
							if (res.code === 0) {
								this.hidden();
								this.getReminderData()
								this.$emit('refresh')
								return
							}
							// ACC 和 Mileage 只能选一种
							if (res.code === 412) {
								this.$message({
									message: this.Local ? this.Local.prop('Fleet.Reminder.Inconsistent') : 'Mileage/ACC-ON Duration are not consistent with maintenance settings in device detail.',
									center: true,
									type: 'error'
								});
								return
							}
							// 根据 code 的值给出提示信息
							promptMessage.call(this,res.code)
						}).catch((e)=>{
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							});
						})
					}
				});
			},
			// Dialog - 关闭之前
			beforeClose() {
				this.hidden()
			},
			// 异步获取 车辆 当前里程
			getCurrentMileage() {
				let imei = this.imei
				if (imei) {
					getCurrentMileage(imei).then((res)=>{
						if (res.code === 0) {
							this.mileage = res.data['1'] ? res.data['1'] : 0
							this.acc = res.data['2'] ? res.data['2'] : 0
							return
						} else {
							this.mileage = null
							this.acc = null
						}
						// 根据 code 的值给出提示信息
						promptMessage.call(this,res.code)
					}).catch((e)=>{
						this.$message({
							message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
							center: true,
							type: 'error'
						});
					})
				} else {
					this.mileage = null
					this.acc = null
				}
			},
			// 异步请求获取车辆或者司机 Reminders 数据
			getReminderData() {
				var relationId = this.relationId
				var reminderType = this.reminderType
				this.loading = true

				getReminderData(relationId,reminderType).then((res)=>{
					if (res.code === 0) {
						this.loading = false
						this.reminders = res.data
						return
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this,res.code)
				}).catch((e)=>{
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
				})
			},
			// Table - 设置选中的行（车辆或者司机 Reminders Table）
			setCurrent(index,row) {
				this.$refs.singleTable.setCurrentRow(row);
			},
			// Table - 选中的行发生改变（车辆或者司机 Reminders Table）
			handleCurrentChange(val) {
				this.currentRow = val;
				if (val) {
 					// 复制对象 避免造成影响
					this.AddReminderform = JSON.parse(JSON.stringify(val))
				} else {
					this.reset()
				}
			},
			// Table - 删除选中的行（车辆或者司机 Reminders Table）
			handleDelete(index,row){
				let id = row.id
				deleteReminder(id).then((res)=>{
					if (res.code === 0) {
						this.getReminderData()
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this,res.code)
				}).catch((e)=>{
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
				})
			},
			// AllReminders Table - 选中的行发生改变
			handleCurrentChangeOfAllReminders(val) {
				this.currentRow = val;
				if (val) {
					// 复制对象 避免造成影响
					this.AddReminderform = JSON.parse(JSON.stringify(val))
					this.AddReminderform.id = null
					if (this.imei == null || this.imei == '' ) {
						this.AddReminderform.reminderFactor = '3'
					}
				} else {
					this.reset()
				}
			},
		},
		watch: {
			myimei: function (newrImei, oldImei) {
				if (newrImei == null || newrImei == '' ) {
					this.noImei = true
				} else {
					this.noImei = false
				}
			},
			'AddReminderform.reminderFactor': {
                handler: function(newVal, oldVal) {
                	if (this.$refs.interval) {
                		this.$refs.interval.clearValidate()
                	}
					if (newVal == 1) {
						this.AddReminderform.advanceType = '5'
					} else if (newVal == 2) {
						this.AddReminderform.advanceType = '6'
					} else {
						if (this.AddReminderform.advanceType != '5' && this.AddReminderform.advanceType != '6') {
							this.AddReminderform.advanceType = this.AddReminderform.advanceType
						} else {
							this.AddReminderform.advanceType = '1'
						}
					}
				},
                deep:true
            }
		}
	}
</script>

<style lang='less'>
	.AddReminderDialog {
		.el-dialog {
			min-width: 600px;
		}
		.el-dialog__header {
			background: #2d2f3e;
			padding: 15px 20px;
		}
		.el-dialog__title {
			color: #fff;
			font-weight: 300;
		}
		.el-dialog__body {
			padding: 30px 30px 0px 30px;
		}
		.el-form-item.is-required .el-form-item__label:before {
			display: none;
		}
		.el-form-item__label {
			text-align: left;
			color: #3f4047;
		}
		.reminderFactor {
			.el-radio {
				width: 100%;
				margin-left: 0!important;
				margin-top: 12px;
				color:#868aa8;
			}
		}
		.reminderContorl {
			position: absolute;
			right: 10px;
			z-index: 2;
		}
		.unit {
			position: absolute;
			top: 1px;
			bottom: 1px;
			right: 0;
			padding: 0 32px;
			border-left: 1px solid #F9F9F9;
			z-index: 2
		}
		.intervalTypes,.advanceTypes {
			position: absolute;
			right: 1px;
			z-index: 2;
			width: 120px;
			height: 38px;
			top: 1px;
			bottom: 1px;
			border: 0px;
			border-left: 1px solid #F9F9F9;
			overflow: hidden;
			input {
				border: 0;
				height: 36px;
			}
		}
		.intervalTypesInput {
			input {
				padding-right: 110px
			}
		}
		.tips {
			margin-top: 10px;
			margin-bottom: 0;
			font-size: 12px;
			line-height: 20px;
			color: #c0c4cc;
		}
		.btn-contorl {
			padding: 6px;
		}
		form {
			margin-top: 30px;
			border-bottom: 0!important;
		}
		.el-table__row {
			cursor: pointer;
		}
		.el-table td, .el-table th {
			padding: 10px 0
		}
		.startDate {
			width: 390px
		}
		.el-dialog__footer {
    		padding: 10px 30px 20px;
    	}
	}
	.allReminders {
		.el-table td, .el-table th {
			padding: 10px 0
		}
	}
</style>