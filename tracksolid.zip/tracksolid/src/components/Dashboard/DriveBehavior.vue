<template>
    <section class="behaviorPage">
        <el-card>
            <div slot="header" class="clearfix behavior">
                <span class="title">
                    {{ this.Local ? this.Local.prop('Fleet.DrivingBehavior') : 'Driving Behavior Ratings' }}
                </span>
                <div class="fuelTab">
                    <el-tabs v-model="activeName" @tab-click="handleClick">
                        <el-tab-pane :label="this.Local ? this.Local.prop('Fleet.7days') : '7 days'" name="first"></el-tab-pane>
                        <el-tab-pane :label="this.Local ? this.Local.prop('Fleet.15days') : '15 days'" name="second"></el-tab-pane>
                        <el-tab-pane :label="this.Local ? this.Local.prop('Fleet.30days') : '30 days'" name="third"></el-tab-pane>
                    </el-tabs>
                </div>
                <div class="iconAlert">
                    <i class="el-icon-more more" @click="showAlert()"></i>
                </div>
            </div>
            <div id="behaviorChart" :style="{width: '100%', height: '540px'}"></div>
            <!--弹框-->
            <div class="alertBox">
                <el-dialog :title="this.Local ? this.Local.prop('Fleet.Configuration') : 'Configuration'" @close="clearHidden()" :visible.sync="isShow">
                    <el-form ref="selectForm" :model="form" label-width="120px">
                        <el-form-item :label="this.Local ? this.Local.prop('Fleet.Sorted') : 'Sorted by:'" prop="orderBy">
                            <el-select v-model="form.orderBy" :placeholder="this.Local ? this.Local.prop('Fleet.Hightest') : 'Hightest to Lowest'">
                                <el-option v-for="item in orderByWay" :key="item.value" :label="item.label" :value="item.value"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item :label="this.Local ? this.Local.prop('Fleet.TimeRange') : 'Time range:'">
                            <el-date-picker
                                v-model.trim="form.dateTime"
                                type="daterange"
                                range-separator="-"
                                value-format="yyyy-MM-dd"
                                :start-placeholder="Local ? Local.prop('header.PositionStartTime') : 'Start Time'"
                                :end-placeholder="Local ? Local.prop('header.PositionEndTime') : 'End Time'" :picker-options="pickerOptions">
                            </el-date-picker>
                        </el-form-item>
                        <el-form-item :label="this.Local ? this.Local.prop('Fleet.ViewQuantity') : 'View quantity:'" prop="quantityNum">
                            <el-select v-model="form.quantityNum" placeholder="3">
                                <el-option v-for="item in quantity" :key="item.value" :label="item.label" :value="item.value"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item :label="this.Local ? this.Local.prop('Fleet.Data') : 'Data:'" prop="waringType">
                            <el-select v-model="form.waringType" :placeholder="this.Local ? this.Local.prop('Fleet.All') : 'All'">
                                <el-option v-for="item in type" :key="item.value" :label="item.label" :value="item.value"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="clearHidden()">{{this.Local ? this.Local.prop('Fleet.Cancel') : 'Cancel'}}</el-button>
                        <el-button type="primary" @click="confirmData()">{{this.Local ? this.Local.prop('Fleet.Confirm') : 'Confirm'}}</el-button>
                    </div>
                </el-dialog>
            </div>
        </el-card>
    </section>
</template>

<script type="text/ecmascript-6">
import { getDriveBehavior } from '@/api/Dashboard'
import { promptMessage, getCurrentDayAndBeforeDay } from '@/common/js/common'
import * as types from '@/store/mutation-types'
export default {
    data () {
        return {
            activeName: 'first', // 切换卡
            isShow: false,
            pickerMinDate: '',
            form: {
                orderBy: this.$store.state.orderByThree ? this.$store.state.orderByThree : '', // 排序方式
                quantityNum: this.$store.state.quantityThree ? this.$store.state.quantityThree : '', // 数量
                dateTime: this.$store.state.timeRange ? this.$store.state.timeRange : null,
                waringType: this.$store.state.behaviorType ? this.$store.state.behaviorType : ''
            },
            // 排序方式
            orderByWay: [
                {
                    label: this.Local ? this.Local.prop('Fleet.Hightest') : 'Hightest to Lowest',
                    value: 'desc'
                },
                {
                    label: this.Local ? this.Local.prop('Fleet.Lowest') : 'Lowest to Hightest',
                    value: 'asc'
                }
            ],
            // 数量选项
            quantity: [
                {
                    label: '1',
                    value: 1
                },
                {
                    label: '2',
                    value: 2
                },
                {
                    label: '3',
                    value: 3
                },
                {
                    label: '4',
                    value: 4
                },
                {
                    label: '5',
                    value: 5
                },
                {
                    label: '6',
                    value: 6
                },
                {
                    label: '7',
                    value: 7
                },
                {
                    label: '8',
                    value: 8
                },
                {
                    label: '9',
                    value: 9
                },
                {
                    label: '10',
                    value: 10
                }
            ],
            type: [
                {
                    'label': this.Local ? this.Local.prop('Fleet.All') : 'All',
                    'value': 'overSpeed,41,42,43,44,48'
                },
                {
                    'label': this.Local ? this.Local.prop('Fleet.Overspeed') : 'Overspeed',
                    'value': 'overSpeed'
                },
                {
                    'label': this.Local ? this.Local.prop('Fleet.Harshacceletation') : 'Harsh acceletation',
                    'value': '41'
                },
                {
                    'label': this.Local ? this.Local.prop('Fleet.Harshbraking') : 'Harsh braking',
                    'value': '48'
                },
                {
                    'label': this.Local ? this.Local.prop('Fleet.SharpLeft') : 'Sharp Left Turn',
                    'value': '42'
                },
                {
                    'label': this.Local ? this.Local.prop('Fleet.SharpRight') : 'Sharp Right Turn',
                    'value': '43'
                },
                {
                    'label': this.Local ? this.Local.prop('Fleet.SharpCrash') : 'Sharp Crash',
                    'value': '44'
                }
            ],
            pickerOptions: {
                onPick: ({ maxDate, minDate }) => {
                    this.pickerMinDate = minDate.getTime()
                    if (maxDate) {
                    this.pickerMinDate = ''
                    }
                },
                disabledDate: (time) => {
                    if (this.pickerMinDate !== '') {
                    const day30 = (30 - 1) * 24 * 3600 * 1000
                    let maxTime = this.pickerMinDate + day30
                    let minTime = this.pickerMinDate - day30
                    if (maxTime > new Date()) {
                        maxTime = new Date()
                    }
                    return time.getTime() > maxTime || time.getTime() < minTime
                    }
                    return time.getTime() > Date.now()
                }
            }
        }
    },
    mounted () {
        this.getDriveBehaviorInitData({type: this.$store.state.behaviorType ? this.$store.state.behaviorType : this.type[0].value, orderBy : this.$store.state.orderByThree ? this.$store.state.orderByThree : '', viewQuantity : this.$store.state.quantityThree ? this.$store.state.quantityThree : '', startTime : this.$store.state.timeRange ? this.$store.state.timeRange[0] : getCurrentDayAndBeforeDay(-6), endTime : this.$store.state.timeRange ? this.$store.state.timeRange[1] : getCurrentDayAndBeforeDay(0)})
    },
    methods: {
        // task 图表
        drawLine(xData){
            // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('behaviorChart'))
            var xlist = []
            var ylist = []
            xData.forEach(item => {
                xlist.push(item.alarmCount)
                ylist.push(item.vehicleName)
            })
            xlist = xlist.reverse()
            ylist = ylist.reverse()
            // 绘制图表
            myChart.setOption({
                color: ['#2E5161'],
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                grid: {
                    left: '6%',
                    right: '2%',
                    top: '3%',
                    containLabel: true
                },
                xAxis : [
                    {
                        type : 'value'
                    } 
                ],
                yAxis : [
                    {
                        type : 'category',
                        data : ylist,
                        axisTick: {
                            alignWithLabel: true
                        }
                    }
                ],
                series : [
                    {
                        name:'',
                        type:'bar',
                        barWidth: '30%',
                        data: xlist
                    }
                ]
            },true)
        },
        // 没有数据时显示的图表
        drawLine2(){
            // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('behaviorChart'))
            // 绘制图表
            myChart.setOption({
                tooltip : {
                    trigger: 'axis',
                    axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                        type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                color: ['#2E5161'],
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis : [
                    {
                        type : 'value'
                    }
                ],
                yAxis : [
                    {
                        type : 'category',
                        data : [''],
                        axisTick: {
                            alignWithLabel: true
                        }
                    }
                ],
                series : [
                    {
                        name:'',
                        type:'bar',
                        barWidth: '60%',
                        data:[0, 0, 0, 0, 0, 0, 0]
                    }
                ]
            },true)
        },
        // 获取初始化数据
        getDriveBehaviorInitData({type, orderBy, viewQuantity, startTime, endTime}){
           getDriveBehavior(type,orderBy,viewQuantity,startTime,endTime).then((res)=>{
                if(res.code === 0) {
                    this.loading = false
                    if (res.data && res.data != null && res.data.length > 0) {
                        let listData = res.data
                        this.drawLine(listData) // 渲染图表
                    } else {
                        this.drawLine2()
                    }
                }
                
            }).catch((e)=>{
                this.$message({
                    message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
                    center: true,
                    type: 'error'
                });
            })
        },
        // 获取数据
        getDriveBehaviorData({type, orderBy, viewQuantity, startTime, endTime}){
           getDriveBehavior(type,orderBy,viewQuantity,startTime,endTime).then((res)=>{
                if(res.code === 0) {
                    this.loading = false
                    if (res.data && res.data != null && res.data.length > 0) {
                        // 根据 code 的值给出提示信息
                        promptMessage.call(this,res.code)
                        let listData = res.data
                        this.drawLine(listData) // 渲染图表
                    } else {
                        this.$message({
                            message: this.Local ? this.Local.prop('comm.noData') : 'No data found.',
                            center: true,
                            type: 'warning'
                        })
                        this.drawLine2()
                    }
                }
                
            }).catch((e)=>{
                this.$message({
                    message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
                    center: true,
                    type: 'error'
                });
            })
        },
        // 点击切换卡
        handleClick(tab, event) {
            switch (tab.name) {
                case 'first': 
                    var sTime = getCurrentDayAndBeforeDay(-6)
                    var eTime = getCurrentDayAndBeforeDay(0)
                    this.getDriveBehaviorData({type: this.$store.state.behaviorType ? this.$store.state.behaviorType : this.type[0].value, orderBy: this.$store.state.orderByThree ? this.$store.state.orderByThree : '', viewQuantity: this.$store.state.quantityThree ? this.$store.state.quantityThree : '', startTime: sTime, endTime: eTime})
                    break
                case 'second':
                    var sTime = getCurrentDayAndBeforeDay(-14)
                    var eTime = getCurrentDayAndBeforeDay(0)
                    this.getDriveBehaviorData({type: this.$store.state.behaviorType ? this.$store.state.behaviorType : this.type[0].value, orderBy: this.$store.state.orderByThree ? this.$store.state.orderByThree : '', viewQuantity: this.$store.state.quantityThree ? this.$store.state.quantityThree : '', startTime: sTime, endTime: eTime})
                    break
                case 'third':
                    var sTime = getCurrentDayAndBeforeDay(-29)
                    var eTime = getCurrentDayAndBeforeDay(0)
                    this.getDriveBehaviorData({type: this.$store.state.behaviorType ? this.$store.state.behaviorType : this.type[0].value, orderBy: this.$store.state.orderByThree ? this.$store.state.orderByThree : '', viewQuantity: this.$store.state.quantityThree ? this.$store.state.quantityThree : '', startTime: sTime, endTime: eTime})
                    break
            }
        },
        // 点击显示弹框
        showAlert() {
            this.isShow = true
        },
        // 取消
        clearHidden() {
            this.isShow = false
            // this.form.orderBy = '' // 点击取消按钮把输入的值清空
            // this.form.quantityNum = '' // 点击取消按钮把输入的值清空
            // this.form.dateTime = '' // 点击取消按钮把输入的值清空
            // this.form.waringType = '' // 点击取消按钮把输入的值清空
        },
        // 确认
        confirmData() {
            this.isShow = false
            // this.$message({
            //     message: this.Local ? this.Local.prop('Business.Success') : 'Success',
            //     center: true,
            //     type: 'success'
            // })
            this.getDriveBehaviorData({type: this.form.waringType, orderBy: this.form.orderBy, viewQuantity: this.form.quantityNum, startTime: this.form.dateTime !== null ? this.form.dateTime[0] : getCurrentDayAndBeforeDay(-6), endTime: this.form.dateTime !== null ? this.form.dateTime[1] : getCurrentDayAndBeforeDay(0)})
            this.activeName = 'first'
            this.$store.commit('SET_ORDERTHREE', this.form.orderBy)
            this.$store.commit('SET_QUANTITYTHREE', this.form.quantityNum)
            this.$store.commit('SET_DATERANGE', this.form.dateTime)
            this.$store.commit('SET_BEHAVIORTYPE', this.form.waringType)
        }
    }
}
</script>

<style lang="less">
@media screen and (min-width: 1200px) and (max-width: 1900px) {
    .behavior {
        .title {
            font-size: 16px;
        }
    }
}
.behaviorPage {
   .el-card__header {
      padding: 8px 20px;
  } 
}
.behavior {
    display: flex;
    justify-content: space-between;
    align-items: center;
    .title{
        font-weight: 600;
    }
    .fuelTab {
        .el-tabs__header {
            margin-bottom: 0;
            .el-tabs__nav-wrap {
                overflow: visible;
                .el-tabs__nav-scroll {
                    overflow: visible;
                    .el-tabs__active-bar {
                        bottom: -9px;
                        height: 3px;
                        left: -2px;
                        padding: 0 6px;
                    }
                }
            }
        }
        .el-tabs__nav-wrap::after {
            background: none;
        }
    }
    .iconAlert {
        .more {
            font-size: 24px;
            transform: rotate(90deg);
            cursor: pointer;
        }
    }
}
.alertBox {
    .el-dialog {
        width: 520px;
    }
    .el-dialog__header {
        border-bottom: 1px solid #E4E4E4;
    }
    .el-dialog__footer {
        border-top: 1px solid #e4e4e4;
    }
}
</style>
