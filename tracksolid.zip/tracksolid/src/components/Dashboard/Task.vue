<template>
    <el-card>
        <div slot="header" class="clearfix task">
            <span>
                {{ this.Local ? this.Local.prop('Fleet.Tasks') : 'Tasks' }}
            </span>
            <el-select v-model="value" :placeholder="this.Local ? this.Local.prop('Fleet.LicenseRenew') : 'LicenseRenew'" @change="selectTrigger(value)">
                <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
        </div>
        <div id="taskChart" :style="{width: '100%', height: '500px'}"></div>
    </el-card>
</template>

<script type="text/ecmascript-6">
import { getRemind } from '@/api/Dashboard'
import { promptMessage } from '@/common/js/common'
export default {
    data () {
        return {
            options: [
                // {
                //     'label': this.Local ? this.Local.prop('Fleet.Maintenance') : 'Maintenance',
                //     'value': 'maintenance'
                // },
                {
                    'label': this.Local ? this.Local.prop('Fleet.LicenseRenew') : 'License Renew',
                    'value': 'licenseRenew'
                },
                {
                    'label': this.Local ? this.Local.prop('Fleet.InsuranceRenew') : 'Insurance Renew',
                    'value': 'insuranceRenew'
                }
            ],
            value: ''
        }
    },
    mounted () {
        this.getRemindData({type: ''})
    },
    methods: {
        // task 图表
        drawLine(xData){
            // 基于准备好的dom，初始化echarts实例
            let myChart = this.$echarts.init(document.getElementById('taskChart'))
            var xlist = []
            var ylist = []
            for (var key in xData) {
                var obj = {}
                obj.name = key
                obj.value = xData[key]
                xlist.push(obj)
            }
            xlist.forEach(item => {
                ylist.push(item.name)
            })
            // 绘制图表
            myChart.setOption({
                tooltip: {
                    trigger: 'item',
                    formatter: "{b}:{c} ({d}%)"
                },
                color: ['#BC3837','#4DC884','#FFA03D'],
                legend: {
                    orient: 'horizontal',
                    x: '15%',
                    y: '96%',
                    data: ylist
                },
                series: [
                    {
                        name:'',
                        type:'pie',
                        radius: ['30%', '40%'],
                        label: {
                            normal: {
                                formatter: '{b}: {d}%  ',
                            }
                        },
                        data: xlist
                    }
                ]
            })
        },
        // 获取数据
        getRemindData({type}) {
            getRemind(type).then((res)=>{
                if(res.code === 0) {
                    let remindList = res.data
                    this.loading = false
                    this.drawLine(remindList) // 渲染图表
                    return
                }
                // 根据 code 的值给出提示信息
                promptMessage.call(this,res.code)
            }).catch((e)=>{
                this.$message({
                    message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
                    center: true,
                    type: 'error'
                });
            })
        },
        // 下拉框选择
        selectTrigger(val) {
            this.getRemindData({type: val})
        }
    }
}
</script>
