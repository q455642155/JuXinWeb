<template>
  <section class="mile">
    <el-card>
      <div slot="header" class="clearfix task">
        <span>{{ this.Local ? this.Local.prop('Fleet.TopMileage') : 'Top Mileage Drived Units' }}</span>
        <div class="fuelTab">
          <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="7 days" name="first"></el-tab-pane>
            <el-tab-pane label="15 days" name="second"></el-tab-pane>
            <el-tab-pane label="30 days" name="third"></el-tab-pane>
          </el-tabs>
        </div>
        <div class="dateTime">
          <el-date-picker
            v-model.trim="dateTime"
            type="daterange"
            range-separator="-"
            value-format="yyyy-MM-dd"
            :start-placeholder="Local ? Local.prop('header.PositionStartTime') : 'Start Time'"
            :end-placeholder="Local ? Local.prop('header.PositionEndTime') : 'End Time'"
            @blur="getDateTime"
          ></el-date-picker>
        </div>
        <div class="iconAlert">
          <i class="el-icon-more more" @click="showAlert()"></i>
        </div>
      </div>
      <div id="driveMileChart" :style="{width: '100%', height: '500px'}"></div>
      <!--弹框-->
      <div class="alertBox">
        <el-dialog
          :title="this.Local ? this.Local.prop('Fleet.Configuration') : 'Configuration'"
          @close="clearHidden()"
          :visible.sync="isShow"
        >
          <el-form ref="selectForm" :model="form" label-width="120px">
            <el-form-item
              :label="this.Local ? this.Local.prop('Fleet.Sorted') : 'Sorted by:'"
              :prop="this.Local ? this.Local.prop('Fleet.orderBy') : 'orderBy'"
            >
              <el-select
                v-model="form.orderBy"
                :placeholder="this.Local ? this.Local.prop('Fleet.Hightest') : 'Hightest to Lowest'"
              >
                <el-option
                  v-for="item in orderByWay"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item
              :label="this.Local ? this.Local.prop('Fleet.ViewQuantity') : 'View quantity:'"
              :prop="this.Local ? this.Local.prop('Fleet.quantityNum') : 'quantityNum'"
            >
              <el-select v-model="form.quantityNum" placeholder="3">
                <el-option
                  v-for="item in quantity"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button
              @click="clearHidden()"
            >{{this.Local ? this.Local.prop('Fleet.Cancel') : 'Cancel'}}</el-button>
            <el-button
              type="primary"
              @click="confirmData()"
            >{{this.Local ? this.Local.prop('Fleet.Confirm') : 'Confirm'}}</el-button>
          </div>
        </el-dialog>
      </div>
    </el-card>
  </section>
</template>

<script type="text/ecmascript-6">
import { getDriveMile } from "@/api/Dashboard";
import {
  promptMessage,
  getCurrentDayAndBeforeDay,
  arrayHightToLow,
  arrayLowToHight
} from "@/common/js/common";
export default {
  data() {
    return {
      activeName: "first", // 切换卡
      dateTime: null, // 选择日期
      vehicleNameList: [],
      isShow: false,
      form: {
        orderBy: "",
        quantityNum: ""
      },
      // 排序方式
      orderByWay: [
        {
          label: "Hightest to Lowest",
          value: "desc"
        },
        {
          label: "Lowest to Hightest",
          value: "asc"
        }
      ],
      // 数量选项
      quantity: [
        {
          label: "1",
          value: 1
        },
        {
          label: "2",
          value: 2
        },
        {
          label: "3",
          value: 3
        },
        {
          label: "4",
          value: 4
        },
        {
          label: "5",
          value: 5
        },
        {
          label: "6",
          value: 6
        },
        {
          label: "7",
          value: 7
        },
        {
          label: "8",
          value: 8
        },
        {
          label: "9",
          value: 9
        },
        {
          label: "10",
          value: 10
        }
      ]
    }
  },
  mounted() {
    this.getDriveMileData({
      orderBy: "",
      viewQuantity: "",
      startTime: getCurrentDayAndBeforeDay(-6),
      endTime: getCurrentDayAndBeforeDay(0)
    }) // 加载页面获取图表数据
  },
  methods: {
    // Top Fuel Consumption Units 图表
    drawLine(xData) {
      // 基于准备好的dom，初始化echarts实例
      var that = this
      let myChart = this.$echarts.init(
        document.getElementById("driveMileChart")
      )
      var seriesList = [] // 每个车的所有数据
      var vhNameList = [] // 车辆名
      var dateList = [] // 对应的日期数据
      for (var i = 0; i < xData.length; i++) {
        dateList.push(xData[i].date) // 获取日期
      }
      // 获取车辆的所有名字
      var newArr = xData[0].dayList
      newArr.forEach(item => {
          vhNameList.push(item.vehicleName)
      })
      var dataList = []
      vhNameList.forEach(item => {
          dataList[item] = []
          xData.forEach(val => {
              let list = val.dayList
              for (let i of list) {
                  if (i.vehicleName === item) {
                      dataList[item].push(i.distance)
                  }
              }
          })
      })
      // 添加每个柱状图数据
      vhNameList.forEach(item => {
          var series = {
              name : item,
              type: 'line',
              data: dataList[item]
          }
          seriesList.push(series)
      })
      // 绘制图表
      myChart.setOption({
        title: {
          text: ""
        },
        tooltip: {
          trigger: "axis",
          formatter : function(params) { // 格式化数字取两位小数
              var res = params[0].axisValue
              for(var i=0;i<params.length;i++){
                  res+='<p>'+params[i].marker+'<span>'+params[i].seriesName+': </span><span>'+(Number(params[i].data)*100/100).toFixed(2)+'</span></p>'
              }
              return res
          }
        },
        color: ['#010C11', '#05212D', '#0A394F', '#104D6A', '#166082', '#297fa7', '#2F94C5', '#2EA6E3', '#3ABFFF', '#00C1FF'],
        legend: {
          x: "30%",
          y: "96%",
          data: vhNameList
        },
        grid: {
          left: "8%",
          right: "4%",
          top: "2%"
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: dateList,
          axisLabel: {
            formatter: function(val) {
              var newDate = new Date(val);
              var year = newDate.getFullYear();
              var month =
                newDate.getMonth() < 10
                  ? "0" + (newDate.getMonth() + 1)
                  : newDate.getMonth() + 1;
              var date =
                newDate.getDate() < 10
                  ? "0" + newDate.getDate()
                  : newDate.getDate();
              return date + "/" + month + "/" + year;
            }
          }
        },
        yAxis: {
          type: "value"
        },
        dataZoom: [
            {
                show: dateList.length > 14 ? true : false,
                start: 2,
                end: 98,
                height: 20
            }
        ],
        series: seriesList
      })
    },
    // 获得油感消耗排序统计
    getDriveMileData({ orderBy, viewQuantity, startTime, endTime }) {
      getDriveMile(orderBy, viewQuantity, startTime, endTime)
        .then(res => {
          if (res.code === 0) {
            let vehicle = res.data
            this.loading = false
            if (vehicle.length === 0) {
              return
            }
            this.drawLine(vehicle) // 渲染图表
            return
          }
          // 根据 code 的值给出提示信息
          promptMessage.call(this, res.code)
        })
        .catch(e => {
          this.$message({
            message: this.Local
              ? this.Local.prop("Commands.Unknown_error")
              : "Unknown error",
            center: true,
            type: "error"
          })
        })
    },
    // 点击切换卡
    handleClick(tab, event) {
      switch (tab.name) {
        case "first":
          var sTime = getCurrentDayAndBeforeDay(-6)
          var eTime = getCurrentDayAndBeforeDay(0)
          this.getDriveMileData({
            orderBy: "",
            viewQuantity: "",
            startTime: sTime,
            endTime: eTime
          })
          break
        case "second":
          var sTime = getCurrentDayAndBeforeDay(-14)
          var eTime = getCurrentDayAndBeforeDay(0)
          this.getDriveMileData({
            orderBy: "",
            viewQuantity: "",
            startTime: sTime,
            endTime: eTime
          })
          break
        case "third":
          var sTime = getCurrentDayAndBeforeDay(-29)
          var eTime = getCurrentDayAndBeforeDay(0)
          this.getDriveMileData({
            orderBy: "",
            viewQuantity: "",
            startTime: sTime,
            endTime: eTime
          })
          break
      }
    },
    // 选择日期改变数据
    getDateTime() {
      var sStartTime = this.dateTime[0]
      var sEndTime = this.dateTime[1]
      this.getDriveMileData({
        orderBy: "",
        viewQuantity: "",
        startTime: sStartTime,
        endTime: sEndTime
      })
    },
    // 点击显示弹框
    showAlert() {
      this.isShow = true
    },
    // 取消
    clearHidden() {
      this.isShow = false
      this.form.orderBy = "" // 点击取消按钮把输入的值清空
      this.form.quantityNum = "" // 点击取消按钮把输入的值清空
    },
    // 确认
    confirmData() {
      if (this.form.orderBy === "" && this.form.quantityNum === "") {
        this.$message({
          message: this.Local
            ? this.Local.prop("Commands.ItemNoEmPty")
            : "The orderBy and The quantity only one empty",
          center: true,
          type: "error"
        })
      } else {
        this.isShow = false;
        this.getDriveMileData({
          orderBy: this.form.orderBy,
          viewQuantity: this.form.quantityNum,
          startTime: getCurrentDayAndBeforeDay(-6),
          endTime: getCurrentDayAndBeforeDay(0)
        })
        this.form.orderBy = "" // 点击取消按钮把输入的值清空
        this.form.quantityNum = "" // 点击取消按钮把输入的值清空
      }
    }
  }
};
</script>

<style lang="less">
.task {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.mile {
  .fuelTab {
    .el-tabs__header {
      margin-bottom: 0;
      .el-tabs__nav-wrap {
          overflow: visible;
          .el-tabs__nav-scroll {
              overflow: visible;
              .el-tabs__active-bar {
                  bottom: -19px;
                  height: 4px;
              }
          }
      }
    }
    .el-tabs__nav-wrap::after {
      background: none;
    }
  }
  .iconAlert {
    .more {
      font-size: 24px;
      transform: rotate(90deg);
      cursor: pointer;
    }
  }
}
.alertBox {
  .el-dialog {
    width: 400px;
  }
  .el-dialog__header {
    border-bottom: 1px solid #e4e4e4;
  }
  .el-dialog__footer {
    border-top: 1px solid #e4e4e4;
  }
}
</style>
