<template>
    <el-card class="box-card">
        <div slot="header" class="clearfix">
            <span class="title">
                {{ this.Local ? this.Local.prop('Fleet.DataOverview') : 'Data Overview' }}
            </span>
        </div>
        <div class="text item">
            <el-row :gutter="10">
                <el-col :span="4">
                    <div class="grid-content">
                        <p class="count">{{totalVehicles}}</p>
                        <div class="description">
                            <span class="title">{{this.Local ? this.Local.prop('Fleet.TotalVehicles') : 'Total Vehicles'}}</span>
                            <i class="fa fa-car" aria-hidden="true"></i>
                        </div>
                    </div>
                </el-col>
                <el-col :span="4" :offset="1">
                    <div class="grid-content">
                        <p class="count">{{totalDrivers}}</p>
                        <div class="description">
                            <span class="title">{{this.Local ? this.Local.prop('Fleet.TotalDrivers') : 'Total Drivers'}}</span>
                            <i class="fa fa-id-card-o" aria-hidden="true"></i>
                        </div>
                    </div>
                </el-col>
                <el-col :span="4" :offset="1">
                    <div class="grid-content">
                        <p class="count">{{distanceTraveled}} <span>{{this.Local ? this.Local.prop('Fleet.KM') : 'KM'}}</span></p>
                        <div class="description">
                            <span class="title">{{this.Local ? this.Local.prop('Fleet.DistanceTraveled') : 'Distance Traveled'}}</span>
                            <i class="fa fa-exchange" aria-hidden="true"></i>
                        </div>
                    </div>
                </el-col>
                <el-col :span="4" :offset="1">
                    <div class="grid-content">
                        <p class="count">{{engineOnHours}} <span>{{this.Local ? this.Local.prop('Fleet.H') : 'H'}}</span></p>
                        <div class="description">
                            <span class="title">{{this.Local ? this.Local.prop('Fleet.EngineOnHours') : 'Engine on Hours'}}</span>
                            <i class="fa fa-tachometer" aria-hidden="true"></i>
                        </div>
                    </div>
                </el-col>
                <el-col :span="4" :offset="1">
                    <div class="grid-content">
                        <p class="count">{{fuelConsumption}} <span>{{this.Local ? this.Local.prop('Fleet.L') : 'L'}}</span></p>
                        <div class="description">
                            <span class="title">{{this.Local ? this.Local.prop('Fleet.FuelConsumption') : 'Fuel Consumption'}}</span>
                            <i class="fa fa-tint" aria-hidden="true"></i>
                        </div>
                    </div>
                </el-col>
            </el-row>
        </div>
    </el-card>
</template>

<script type="text/ecmascript-6">
import { getOverViewData } from '@/api/Dashboard'
import { promptMessage } from '@/common/js/common'
export default {
    data () {
        return {
            totalVehicles: 0,
            totalDrivers: 0,
            distanceTraveled: 0,
            engineOnHours: 0,
            fuelConsumption: 0
        }
    },
    mounted () {
        this.getViewData() // 调用方法
    },
    methods: {
        // 获取数据方法
        getViewData () {
            let userId = ''
            getOverViewData(userId).then((res)=>{
                if(res.code === 0) {
                    this.totalDrivers = res.data.totalDrivers ? res.data.totalDrivers : 0 // 驾驶员总数
                    this.totalVehicles = res.data.totalVehicles ? res.data.totalVehicles : 0 // 车辆总数
                    this.distanceTraveled = res.data.distanceTraveled ? (Number(res.data.distanceTraveled)).toFixed(2) : 0 // 行驶总距离
                    this.engineOnHours = res.data.engineOnHours ? (Number(res.data.engineOnHours)).toFixed(2) : 0 // 引擎运行总时长
                    this.fuelConsumption = res.data.fuelConsumption ? (Number(res.data.fuelConsumption)).toFixed(2) : 0 // 总燃油消耗
                    this.loading = false
                    return
                }
                // 根据 code 的值给出提示信息
                promptMessage.call(this,res.code)
            }).catch((e)=>{
                this.$message({
                    message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
                    center: true,
                    type: 'error'
                });
            })
        }
    }
}
</script>

<style lang="less">
.box-card {
    margin-top:30px;
    .clearfix {
        .title {
            font-weight: 600;
        }
    }
}
.grid-content {
    border: 1px solid #E4E4E4;
    box-shadow: 4px 4px 4px #e4e4e4; 
    border-radius: 4px;
    min-height: 120px;
    .count {
        padding-top: 35px;
        padding-left: 36px;
        padding-bottom: 10px;
        font-size: 24px;
        font-weight: bold;
        span{
            color: #ACACAC;
        }
    }
    .description {
        display: flex;
        justify-content: space-around;
        align-items: center;
        .title{
            color:#ACACAC;
        }
        i{
            margin-left: 4px;
            font-size: 30px;
            vertical-align: middle;
            color: #52C1F5;
        }
    }
}
</style>

