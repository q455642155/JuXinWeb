<template>
	<el-dialog
		:title="Local ? Local.prop('Fleet.Driver') + ' ' + Local.prop('cust.Detail') : 'Driver Detail'"
		width="40%"
		top="8vh"
		class="driverDialog"
		:visible.sync="visibleP"
		:before-close="beforeClose"
		:close-on-click-modal="false"
		:close-on-press-escape="false"
	>
		
		<el-form class="dialog-form" ref="DriverAddForm" :model="DriverAddForm" status-icon :rules="rules" label-width="120px">
			<el-row :gutter="20">
				<el-col :span="12">
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.DriverNo') : 'Driver No.'" prop="driverNo">
						<el-input :maxlength=30 v-model.trim="DriverAddForm.driverNo" :placeholder="Local ? Local.prop('Fleet.Driver.DriverNo') : 'Driver No.'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Asset.Drivername') : 'Driver Name'" prop="driverName">
						<el-input :maxlength=30 v-model.trim="DriverAddForm.driverName" :placeholder="Local ? Local.prop('Asset.Drivername') : 'Driver Name'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.LicenseNo') : 'License No.'" prop="licenseNo">
						<el-input :maxlength=50 v-model.trim="DriverAddForm.licenseNo" :placeholder="Local ? Local.prop('Fleet.Driver.LicenseNo') : 'License No.'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.City') : 'City'" prop="city">
						<el-input :maxlength=50 v-model.trim="DriverAddForm.city" :placeholder="Local ? Local.prop('Fleet.Driver.City') : 'City'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.RegisterPlace') : 'Register Place'" prop="registerPlace">
						<el-input :maxlength=50 v-model.trim="DriverAddForm.registerPlace" :placeholder="Local ? Local.prop('Fleet.Driver.RegisterPlace') : 'Register Place'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.RegisterDate') : 'Register Date'" prop="registerDate">
						<el-date-picker
							class="date-picker"
							v-model="DriverAddForm.registerDate"
							format="yyyy-MM-dd"
							value-format="timestamp"
							type="date"
							:placeholder="Local ? Local.prop('Fleet.Driver.RegisterDate') : 'Register Date'"
						>
						</el-date-picker>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.ExpiredDate') : 'Expired Date'" prop="expiredDate">
						<el-date-picker
							class="date-picker"
							v-model="DriverAddForm.expiredDate"
							type="date"
							format="yyyy-MM-dd"
							value-format="timestamp"
							:placeholder="Local ? Local.prop('Fleet.Driver.ExpiredDate') : 'Expired Date'"
						>
						</el-date-picker>
						<div v-if="type === 'edit'" @click="showAddReminderDialog">
							<el-tooltip class="item" effect="dark" :content="Local ? Local.prop('Fleet.Reminder.AddReminder') : 'Add Reminder'" placement="top-start">
								<el-button title="addReminder" class="addReminder" icon="el-icon-time" circle></el-button>
							</el-tooltip>
						</div>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.Ext1') : 'Ext.1'" prop="ext1">
						<el-input :maxlength=30 v-model.trim="DriverAddForm.ext1" :placeholder="Local ? Local.prop('Fleet.Driver.Ext1') : 'Ext.1'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.Ext3') : 'Ext.3'"  prop="ext3">
						<el-input :maxlength=30 v-model.trim="DriverAddForm.ext3" :placeholder="Local ? Local.prop('Fleet.Driver.Ext3') : 'Ext.3'"></el-input>
					</el-form-item>
				</el-col>
				<el-col class="right" :span="12">
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.Avatar') : 'Avatar'">
						<el-upload
							ref="avatarUpload"
							class="avatar-uploader"
							action="http://172.16.0.121:8683/driver/upload"
							:show-file-list="false"
							:drag="true"
							:http-request="upload"
							:before-upload="beforeAvatarUpload">
							<div v-show="uploadLoading" class="upload-loading">
								<div class="loading">
									<i class="el-icon-loading"></i>
									<p>{{ this.Local ? this.Local.prop('Asset.upload') : 'Upload' }} ...</p>
								</div>
							</div>
							<img v-if="DriverAddForm.imagePath" :src="DriverAddForm.imagePath" class="avatar">
							<i v-else class="el-icon-plus avatar-uploader-icon"></i>
							<input type="hidden" ref="uploader"  name="">
						</el-upload>
						<p class="upload-btn">
							<el-button @click="handleUploadAvatar()" icon="el-icon-upload2" size="mini">
								{{ this.Local ? this.Local.prop('Asset.upload') : 'Upload' }}
							</el-button>
							<el-button @click="handleDelectAvatar()" icon="el-icon-delete"  size="mini">
								{{ this.Local ? this.Local.prop('Asset.Delete') : 'Delete' }}
							</el-button>
						</p>
						<p class="tips">
							<i class="el-icon-warning"></i>
							{{ this.Local ? this.Local.prop('Fleet.Driver.UpdataLimit') : 'Only support jpg/png, file size should not large than 2048kb.' }}
						</p>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Alert.email') : 'Email'" prop="email">
						<el-input :maxlength=50 v-model.trim="DriverAddForm.email" :placeholder="Local ? Local.prop('Alert.email') : 'Email'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.Phone') : 'Phone'" prop="phone">
						<el-input :maxlength=30 v-model.trim="DriverAddForm.phone" :placeholder="Local ? Local.prop('Fleet.Driver.Phone') : 'Phone'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.Ext2') : 'Ext.2'" prop="ext2">
						<el-input :maxlength=30 v-model.trim="DriverAddForm.ext2" :placeholder="Local ? Local.prop('Fleet.Driver.Ext2') : 'Ext.2'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Fleet.Driver.Ext4') : 'Ext.4'" prop="ext4">
						<el-input :maxlength=30 v-model.trim="DriverAddForm.ext4" :placeholder="Local ? Local.prop('Fleet.Driver.Ext4') : 'Ext.4'"></el-input>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row >
				<el-col :span="24">
					<el-form-item :label="Local ? Local.prop('index.Address') : 'Address'" prop="address">
						<el-input :maxlength=100 v-model.trim="DriverAddForm.address" :placeholder="Local ? Local.prop('index.Address') : 'Address'"></el-input>
					</el-form-item>
					<el-form-item :label="Local ? Local.prop('Asset.reMark') : 'Remark'" prop="remark">
						<el-input
							type="textarea"
							:maxlength=200 
							resize="none"
							:placeholder="Local ? Local.prop('Asset.reMark') : 'Remark'"
							:rows="2"
							v-model.trim="DriverAddForm.remark"
						>
						</el-input>
					</el-form-item>
				</el-col>	
			</el-row>
		</el-form>

		<span slot="footer" class="dialog-footer">
			<el-button @click="hidden()">{{ this.Local ? this.Local.prop('index.Cancel') : 'Cancel' }}</el-button>
			<el-button type="primary" @click="save()">{{ this.Local ? this.Local.prop('comm.Save') : 'Save' }}</el-button>
		</span>

		<!-- AddReminderDialog -->
		<AddReminderDialog 
			v-if="type === 'edit'" 
			ref="AddReminderDialog" 
			:type="innerDialogType" 
			:reminderType="reminderType" 
			:relationId="DriverAddForm.id" 
		/>
	</el-dialog>
</template>

<script type="text/ecmascript-6">
	import AddReminderDialog from '@/components/AddReminderDialog'
	import { driverUpdate } from '@/api/Driver'
	import { delFile, upload } from '@/api/Upload'
	import { promptMessage } from '@/common/js/common'

	export default {
		name: 'DriverDialog',
		props: {
			// 表单内容 - 修改时候需要传入数据
			form: {
				type: Object,
				default: function() {
					return null
				}
			},
			// 展示状态 - 添加add/修改edit
			type: {
				type: String,
				default: 'add'
            },
            visibleP: {
                type: Boolean,
                default: false
            }
		},
		data() {
			// 自定义表单验证规则
			var checkExpiredDate = (rule, value, callback) => {
				if (!value) {
					return callback();
				} else {
					let registerDate = this.DriverAddForm.registerDate ? this.DriverAddForm.registerDate : ''
					if (value < registerDate) {
						callback(new Error(this.Local ? this.Local.prop('Fleet.Driver.RegisterDateValidate') : 'Expired Date should not earlier than Register Date.'))
					} else {
						return callback();
					}
				}
			};

			return {
				// AddReminderDialog是否为嵌套显示 - true嵌套/false非嵌套
				innerDialogType: true,
				// 关联类型 - 1司机/2车辆
				reminderType: 1,
				// Dialog显示状态 - true显示/false隐藏
				dialogVisible: false,
				// 表单内容 - 添加/修改司机信息
				DriverAddForm: {
					id: null,
					driverNo: null,
					driverName: null,
					licenseNo: null,
					city: null,
					registerPlace: null,
					registerDate: null,
					expiredDate: null,
					email: null,
					phone: null,
					ext1: null,
					ext2: null,
					ext3: null,
					ext4: null,
					address: null,
					remark: null,
					imagePath: '',
				},
				// 表单验证规则
				rules: {
					driverNo: [
						{ required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
					],
					driverName: [
						{ required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
					],
					licenseNo: [
						{ required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
					],
					registerPlace: [
						{ required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
					],
					registerDate: [
						{ required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
					],
					expiredDate: [
						{ required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'},
						{ validator: checkExpiredDate }
					],
					email: [
						{ required: false, type: 'email', message: this.Local ? this.Local.prop('Alert.emailFormatError') : 'Email format error'}
					],
					phone: [
						{ required: false, message: this.Local ? this.Local.prop('user.ContactPhoneFormat') : 'The contact phone is not formatted correctly.', pattern: /^\s*\+?\s*(\(\s*\d+\s*\)|\d+)(\s*-?\s*(\(\s*\d+\s*\)|\s*\d+\s*))*\s*$/}
					],
				},
				// 临时图片的 key
				fileName: null,
				// 图片上传的loading状态
				uploadLoading: false
			}
		},
		methods: {
			// Dialog - 显示
			show() {
				this.dialogVisible = true
			},
			// Dialog - 隐藏
			hidden() {
				this.$emit('update:visibleP', false)
				// 移除表单验证 重置表单
			},
			// Form - 重置表单
			reset() {
				// 移除表单验证 重置表单
				this.DriverAddForm = {
					id: null,
					driverNo: null,
					driverName: null,
					licenseNo: null,
					city: null,
					registerPlace: null,
					registerDate: null,
					expiredDate: null,
					email: null,
					phone: null,
					ext1: null,
					ext2: null,
					ext3: null,
					ext4: null,
					address: null,
					remark: null,
					imagePath: '',
				}
				this.$nextTick(() => {	
					this.$refs.DriverAddForm.clearValidate()
				})
			},
			// Dialog - 关闭之前
			beforeClose() {
				this.hidden()
			},
			// AddReminderDialog - 显示
			showAddReminderDialog() {
				this.$refs.AddReminderDialog.show()
			},
			// Form - 头像上传之前
			beforeAvatarUpload(file) {
				const isJPG = file.type == 'image/jpeg';
				const isPNG = file.type == 'image/png';
				const isLt2M = file.size / 1024 / 1024 < 2;
				let OK = true 
				let mseeage = this.Local ? this.Local.prop('Fleet.Driver.UpdataLimit') : 'Only support jpg/png, file size should not large than 2048kb.'
				if (!isJPG && !isPNG) {
					OK = false
					this.$message.info(mseeage);
				}
				if (!isLt2M) {
					OK = false
					this.$message.info(mseeage);
				}
				return OK
			},
			// Form - 删除上传图片
			handleDelectAvatar() {
				delFile(this.fileName).then((res)=>{
					if (res.code === 0) {
						this.DriverAddForm.imagePath = ''
						this.fileName = null
						return
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this,res.code)
				}).catch((e)=>{
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
				})
			},
			// Form - 上传更新图片
			upload(res){
				this.uploadLoading = true
				upload(res.file).then((res)=>{
					if (res.code === 0) {
						this.fileName = res.data.fileName
						this.DriverAddForm.imagePath = res.data.path;
						this.uploadLoading = false
						return
					}else {
						this.uploadLoading = false
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this,res.code)
				}).catch((e)=>{
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
					this.uploadLoading = false
				})
			},
			// Btn - 点击触发上传图片
			handleUploadAvatar() {
				this.$refs.uploader.click()
			},
			// Form - 提交数据
			save() {
				this.$refs.DriverAddForm.validate((valid) => {
					if (valid) {
						this.driverUpdate()
					} else {
						return false;
					}
				});
				return
			},
			// Form - 表单提交的axios请求
			driverUpdate() {
				let id=this.DriverAddForm.id,
					driverNo=this.DriverAddForm.driverNo,
					driverName=this.DriverAddForm.driverName,
					licenseNo=this.DriverAddForm.licenseNo,
					city=this.DriverAddForm.city,
					registerPlace=this.DriverAddForm.registerPlace,
					registerDate=this.DriverAddForm.registerDate,
					expiredDate=this.DriverAddForm.expiredDate,
					email=this.DriverAddForm.email,
					phone=this.DriverAddForm.phone,
					ext1=this.DriverAddForm.ext1,
					ext2=this.DriverAddForm.ext2,
					ext3=this.DriverAddForm.ext3,
					ext4=this.DriverAddForm.ext4,
					address=this.DriverAddForm.address,
					remark=this.DriverAddForm.remark,
					imagePath=this.DriverAddForm.imagePath;

				driverUpdate(id,driverNo,driverName,licenseNo,city,registerPlace,registerDate,expiredDate,email,phone,ext1,ext2,ext3,ext4,address,remark,imagePath).then((res)=>{
					if (res.code === 0) {
						// 保存成功派发监听事件 - 刷新表格
						this.$emit('refresh')
						this.hidden()
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this,res.code)
				}).catch((e)=>{
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
				})
			},
		},
		watch: {
			// 监听传入参数 form 的变化 
			form: function (newForm, oldForm) {
				if (!newForm.id) {
					this.reset()
					return 
				}
				this.DriverAddForm = newForm
			}
		},
		components: {
			AddReminderDialog
		}
	}
</script>

<style lang='less'> 
	.driverDialog {	
		.el-dialog {
			min-width: 800px;
			.el-dialog__header {
				background: #2d2f3e;
				padding: 20px;
				.el-dialog__title {
					color: #fff;
					font-weight: 300;
				}
			}
			.el-dialog__body {
				padding: 40px 40px 10px 40px;
				.dialog-form {
					.el-form-item__label {
						text-align: left;
						color: #3f4047;
					}
					.right {
						.el-form-item__label {
							padding-left: 40px;
						}
					}
					.avatar-uploader .el-upload {
						border: 1px solid #dcdfe6;
						border-radius: 6px;
						cursor: pointer;
						position: relative;
						overflow: hidden;
					}
					.el-form-item.is-required .el-form-item__label:before {
						display: none;
					}
					.tips {
						margin-top: 10px;
						margin-bottom: 20px;
						font-size: 12px;
						line-height: 20px;
						height: 40px;
						color: #c0c4cc;
					}
					.addReminder {
						position: absolute;
						right: -20px;
						top: 0px;
					}
					.avatar-uploader-icon {
						font-size: 24px;
						color: #dcdfe6;
						width: 160px;
						height: 160px;
						line-height: 160px;
						text-align: center;
					}
					.avatar {
						width: 160px;
						height: 160px;
						display: block;
					}
					.date-picker {
						width: 230px;
					}
					.el-upload-dragger {
						border: 0px;
						width: 160px;
						height: 160px;
					}
					.upload-btn {
						button {
							border: 0;
							padding: 6px;
						}
						.el-button+.el-button {
							margin-left: 2px;
						}
					}
					.upload-loading {
						position: absolute;
						display: table;
						top: 0;
						left: 0;
						width: 100%;
						height: 100%;
						background: #fff;
						.loading {
							display: table-cell;
							vertical-align: middle;
							color: #c0c4cc;
							font-size: 16px;
							p {
								line-height: 10px;
								font-size: 14px;
							}
						}
					}
					.el-form-item__error {
						width: 280px;
					}
				}
			}
		}
	}

</style> 