<template>
	<el-dialog
		:title="Local ? Local.prop('Geozones.linkdevice') : 'Assign Device'"
		width="40%"
		top="8vh"
		class="deviceDialog"
		:visible.sync="visibleP"
		:before-close="beforeClose"
		:close-on-click-modal="false"
		:close-on-press-escape="false"
	>
        <section>
            <el-row :gutter="20">
                <el-col :span="12">
                    <div class="areaTree">
                        <el-input placeholder="输入关键字进行过滤" v-model="filterText"></el-input>
                        <el-tree ref="trees" :data="data5" @node-click="handleNodeClick" default-expand-all :expand-on-click-node="false" :filter-node-method="filterNode">
                            <template class="custom-tree-node" slot-scope="{ node, data }">
                                <span>
                                    <i style="display:inline-block;width:10px;height:10px;background:#f00;" :style="{background: data.type === 1 ? '#f00' : data.type === 2 ? '#00f' : '#0f0'}"></i>
                                    {{ node.label }}
                                </span>
                            </template>
                        </el-tree>
                    </div>
                </el-col>
                <el-col :span="12">
                    <div class="areaTree">
                        <el-input placeholder="输入关键字进行过滤" v-model="filterText1"></el-input>
                        <el-tree :data="data2" show-checkbox default-expand-all node-key="id" ref="tree" :expand-on-click-node="false" highlight-current :filter-node-method="filterNode1">
                        </el-tree>
                    </div>
                </el-col>
            </el-row>
            <el-row>
                <div class="selectList">
                    <div>Selected list(<span id="devNumber">9</span>)&emsp;<a class="cp" onclick="removeAll()">Clear</a></div>
                </div>
                <div class="listBox">
                    <ul id="checkList" class="list-fl list-label"></ul>
                </div>
            </el-row>
        </section>
		<span slot="footer" class="dialog-footer">
			<el-button type="primary">{{ this.Local ? this.Local.prop('comm.Save') : 'Save' }}</el-button>
            <el-button @click="hidden()">{{ this.Local ? this.Local.prop('index.Cancel') : 'Cancel' }}</el-button>
		</span>
	</el-dialog>
</template>

<script type="text/ecmascript-6">
import '@/common/js/jquery-1.4.4.min.js'
import '@/common/js/jquery.ztree.core.min.js'
import '@/common/js/jquery.ztree.excheck.min.js'
import { promptMessage } from '@/common/js/common'
import {queryAlarmInfo, relationDeviceData, getInitDeviceNode} from '@/api/Drivehistory/index.js'
import { URL } from '@/config'
export default {
    props: {
        visibleP: {
            type: Boolean,
            default: false
        }
    },
    data () {
        return {
            node_cache: '',
            dataList: [],
            filterText: '',
            filterText1: '',
            data2: [{
          id: 1,
          label: '一级 1',
          children: [{
            id: 4,
            label: '二级 1-1',
            children: [{
              id: 9,
              label: '三级 1-1-1'
            }, {
              id: 10,
              label: '三级 1-1-2'
            }]
          }]
        }, {
          id: 2,
          label: '一级 2',
          children: [{
            id: 5,
            label: '二级 2-1'
          }, {
            id: 6,
            label: '二级 2-2'
          }]
        }, {
          id: 3,
          label: '一级 3',
          children: [{
            id: 7,
            label: '二级 3-1'
          }, {
            id: 8,
            label: '二级 3-2'
          }]
        }],
            data5: [
                {
                    id: 1,
                    label: '一级 1',
                    icon:'el-icon-success',
                    type: 1,
                    children: [{
                        id: 4,
                        label: '二级 1-1',
                        type: 2,
                        children: [{
                            id: 9,
                            label: '三级 1-1-1',
                            type: 3,
                            icon: 'el-icon-info'
                        }, {
                            id: 10,
                            label: '三级 1-1-2',
                            type:3
                        }]
                    }]
                }, 
                {
                    id: 2,
                    label: '一级 2',
                    type: 2,
                    children: [{
                        id: 5,
                        label: '二级 2-1',
                        type: 3
                    }, {
                        id: 6,
                        label: '二级 2-2',
                        type: 3
                    }]
                }, 
                {
                    id: 3,
                    label: '一级 3',
                    type: 1,
                    children: [{
                        id: 7,
                        label: '二级 3-1',
                        type: 2
                    }, {
                        id: 8,
                        label: '二级 3-2',
                        type: 2
                    }]
                },
                {
                    id: 10,
                    label: '一级 3',
                    type: 1,
                    children: [{
                        id: 11,
                        label: '二级 3-1',
                        type: 2
                    }, {
                        id: 12,
                        label: '二级 3-2',
                        type: 2,
                        children: [
                            {
                                id: 13,
                                label: '三级 3-1',
                                type: 3,
                                children: [
                                    {
                                        id: 15,
                                        label: '四级 3-1',
                                        type: 3,
                                    }
                                ] 
                            }
                        ]
                    }]
                }
            ]
        }
    },
    watch: {
      filterText(val) {
        this.$refs.trees.filter(val);
      },
      filterText1(val) {
        this.$refs.tree.filter(val);
      }
    },
    methods: {
        hidden() {
            this.$emit('update:visibleP', false)
        },
        // Dialog - 关闭之前
        beforeClose() {
            this.hidden()
        },
        // 弹框的时候查询告警信息
        openDeviceModal(userId) {
            this.getUserTreeNode(userId) // 调用方法
            // this.getDeviceTreeNode(userId, '')
        },
        filterNode(value, data) {
            if (!value) return true;
            return data.label.indexOf(value) !== -1;
        },
        filterNode1(value, data) {
            if (!value) return true;
            return data.label.indexOf(value) !== -1;
        },
        // 获取用户树初始化节点数据
        getUserTreeNode(userId){
            var result
            var that = this
            var userId = userId
            relationDeviceData(userId).then(ret => {
                if(ret && ret.code == 0){
                    this.dataList = ret.data
                    console.log(this.dataList)
                }
            }).catch(err => {
                console.log(err)
            })
            return result
        },
        handleNodeClick(data) {
            console.log(data);
        }
    }
}
</script>

<style lang="less">
.deviceDialog {
    .el-dialog__body {
        padding: 15px 20px;
    }
}
.areaTree {
    border: 1px solid #ccc;
    padding: 15px;
    background: #fdfdfd;
    height: 250px;
    overflow: auto;
    .tree-search{
        position: relative;
        z-index: 3;
        height: 24px;
        background-color: #fff;
        margin-bottom: 3px;
        border: 1px solid #ccc;
        box-sizing: content-box;
        .tree-search-icon {
            position: absolute;
            right: 0;
            width: 24px;
            height: 24px;
            border-left: 1px solid #ccc;
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .empty{
            width: 292px;
            line-height: 24px;
            font-size: 14px;
        }
    }
    .tree-box {
        height: 250px;
        overflow: auto;
    }
}
.selectList{
    margin-top: 20px;
}

</style>
