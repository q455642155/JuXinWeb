<template>
	<el-dialog
		:title="Local ? Local.prop('Geozones.linkdevice') : 'Assign Device'"
		width="40%"
		top="8vh"
		class="deviceDialog"
		:visible.sync="visibleP"
		:before-close="beforeClose"
		:close-on-click-modal="false"
		:close-on-press-escape="false"
	>
        <section>
            <el-row :gutter="20">
                <el-col :span="12">
                    <div class="areaTree">
                        <div class="tree-search">
                            <span class="tree-search-icon"><i title="Search" id="cusTreeSearchBtn" class="el-icon-search"></i></span>
                            <input type="text" id="key" class="empty fs-12" name="imei" value="" :placeholder="this.Local ? this.Local.prop('Geozones.enterusername') : 'Customer name or account'">
                        </div>
                        <div class="tree-box">
                            <ul id="ud_userTree" class="ztree"></ul>
                        </div>
                    </div>
                </el-col>
                <el-col :span="12">
                    <div class="areaTree">
                        <div class="tree-search">
                            <span class="tree-search-icon"><i title="Search" id="cusTreeSearchBtn" class="el-icon-search"></i></span>
                            <input type="text" id="key" class="empty fs-12" name="imei" value="" :placeholder="this.Local ? this.Local.prop('Geozones.enterimei') : 'Please enter the device name or IMEI'">
                        </div>
                        <div class="tree-box">
                            <ul id="ud_deviceTree" class="ztree"></ul>
                        </div>
                    </div>
                </el-col>
            </el-row>
            <el-row>
                <div class="selectList">
                    <div>Selected list(<span id="devNumber">9</span>)&emsp;<a class="cp" onclick="removeAll()">Clear</a></div>
                </div>
                <div class="listBox">
                    <ul id="checkList" class="list-fl list-label"></ul>
                </div>
            </el-row>
        </section>
		<span slot="footer" class="dialog-footer">
			<el-button type="primary">{{ this.Local ? this.Local.prop('comm.Save') : 'Save' }}</el-button>
            <el-button @click="hidden()">{{ this.Local ? this.Local.prop('index.Cancel') : 'Cancel' }}</el-button>
		</span>
	</el-dialog>
</template>

<script type="text/ecmascript-6">
import '@/common/js/jquery-1.4.4.min.js'
import '@/common/js/jquery.ztree.core.min.js'
import '@/common/js/jquery.ztree.excheck.min.js'
import { promptMessage } from '@/common/js/common'
import {queryAlarmInfo, relationDeviceData, getInitDeviceNode} from '@/api/Drivehistory/index.js'
import { URL } from '@/config'
export default {
    props: {
        visibleP: {
            type: Boolean,
            default: false
        }
    },
    data () {
        return {

        }
    },
    methods: {
        hidden() {
            this.$emit('update:visibleP', false)
        },
        // Dialog - 关闭之前
        beforeClose() {
            this.hidden()
        },
        // 弹框的时候查询告警信息
        openDeviceModal(userId) {
            this.getUserTreeNode(userId) // 调用方法
            this.getDeviceTreeNode(userId, '')
        },
        getUserTreeNode: getUserTreeNode, // 获取用户树初始化节点数据
        userTree_ajaxDataFilter: userTree_ajaxDataFilter, // 用户树节点数据处理
        buildTypeName: buildTypeName, // 用户类型名称处理
        checkHistory: checkHistory, /*** 回选设备*/
        deviceTree_dataFilter: deviceTree_dataFilter, //设备树节点处理
        getDeviceTreeNode: getDeviceTreeNode,/*** 获取初始化设备树的节点数据*/
        userTree_zTreeBeforeClick: userTree_zTreeBeforeClick, /*** 用户树节点点击之前的事件*/
        userTree_zTreeOnClick: userTree_zTreeOnClick,/*** 用户树点击事件*/
        deviceTree_zTreeOnCheck: deviceTree_zTreeOnCheck,/*** 设备树勾选事件*/
        removeDevice: removeDevice, /*** 单个移除选中设备的方法*/
        removeAll: removeAll,/*** 清空所有选择的设备*/
        deviceTree_nodeFilter: deviceTree_nodeFilter, //设备树搜索过滤方法 返回符合关键字的节点
        getAllCheckValue: getAllCheckValue, /*** 获取所有已选中的设备*/
        deviceTree_zTreeBeforeClick: deviceTree_zTreeBeforeClick, /*** 设备树点击前事件，为防止设备名称选中效果，以点击前事件替代点击事件*/
        deviceTree_zTreeBeforeCheck: deviceTree_zTreeBeforeCheck, /*** 设备树勾选前的事件，如果勾选分组节点并且分组节点下没有设备节点时，则本次勾选不做操作*/
        deviceTree_zTreeBeforeAsync: deviceTree_zTreeBeforeAsync,/** * 异步加载前的回调方法，处理请求需要的参数*/
        deviceTree_zTreeBeforeExpand: deviceTree_zTreeBeforeExpand,//节点展开之前的回调
        deviceTree_zTreeOnAsyncSuccess: deviceTree_zTreeOnAsyncSuccess,/*** 设备树异步加载成功回调*/
        deviceTree_search: deviceTree_search /*** 设备树搜索*/
    }
}
/**
 * 用户树配置
 */
var userTree_setting = {
		async: {
			enable: true,
			type: "post",
			contentType: "application/x-www-form-urlencoded",
			url: URL +"/customer/getLowerUser",
			autoParam: ["id=parentId","fullParentId=fullParentId"],
			dataFilter: this.userTree_ajaxDataFilter
		},	
		view: {
			showLine: false,
			showTitle:true
		},
		data: {
			simpleData: {
				enable: true
			},
			keep: {
				parent: true
			},
			key: {
				name:"name",
				title:"typeName"
			}
		},
		callback:{
			onClick : userTree_zTreeOnClick,
 			// onAsyncSuccess: userTree_zTreeOnAsyncSuccess,
			beforeClick: userTree_zTreeBeforeClick
		}
    };	
/**
 * 设备树配置
 */
var deviceTree_setting = {
		async: {
			enable: true,
			type: "post",
			contentType: "application/x-www-form-urlencoded",
			url: URL +"/device/getDeviceByOrgId",
			autoParam: ["id=orgId","imeisOrdevName=devName","userId=userId"],
			dataFilter: this.deviceTree_dataFilter
		},
		view: {
			dblClickExpand: false,
			showLine: false
		},
		data: {
			simpleData: {
				enable: true
			}
		},
		check: {
			enable: true
		},
		callback: {
			beforeClick: deviceTree_zTreeBeforeClick,
			onCheck: deviceTree_zTreeOnCheck,
			beforeCheck:  deviceTree_zTreeBeforeCheck,
			onAsyncSuccess: deviceTree_zTreeOnAsyncSuccess,
			beforeAsync: deviceTree_zTreeBeforeAsync,
			beforeExpand: deviceTree_zTreeBeforeExpand
		}	
};
var node_cache = new Map()
// 获取用户树初始化节点数据
        function getUserTreeNode(userId){
            var result
            var that = this
            var userId = userId
            relationDeviceData(userId).then(ret => {
                if(ret && ret.code == 0){
                    result = userTree_ajaxDataFilter("",null,ret.data); //节点数据处理
                    // console.log(ret)
                    $.fn.zTree.init($("#ud_userTree"),userTree_setting,ret.data)
                    var total = 0;  //选中总数
                    if(ret.data){
                        total = ret.data.length;
                    }
                    //获取用户树初始化数据
                    var userNodes = ret.data;
                    //初始化用户树
                    var userTreeObj = $.fn.zTree.init($("#ud_userTree"),userTree_setting,userNodes);
                    console.log(userTreeObj)
                    //选中根节点
                    var firstNode = userTreeObj.getNodes()[0];
                    console.log(firstNode)
                    if(firstNode){
                        userTreeObj.selectNode(firstNode);
                        var userId = firstNode.id;
                        //获取设备树初始化数据
                        var deviceNodes = getDeviceTreeNode(userId,'');
                        if(deviceNodes && deviceNodes.length > 0){
                            //初始化设备树
                            // var deviceTreeObj = $.fn.zTree.init($("#ud_deviceTree"),deviceTree_setting,deviceNodes);
                            $.fn.zTree.init($("#ud_deviceTree"),deviceTree_setting,deviceNodes)
                            $("#ud_deviceTree_loadingData").hide();
                            //回选设备
                            if(total > 0){
                                checkHistory(deviceTreeObj);
                            }
                        }else{
                            $("#ud_deviceTree_loadingData").hide();
                            $("#ud_deviceTree_nodata").show();
                        }
                    }
                }
            }).catch(err => {
                console.log(err)
            })
            return result
        }
        // 用户树节点数据处理
        function userTree_ajaxDataFilter(treeId, parentNode, responseData){
            if(responseData && responseData.data){
                $.each(responseData.data,function(i,v){
                    v.typeName = buildTypeName(v);
                });
            }
            return responseData.data;
        }
        // 用户类型名称处理
        function buildTypeName(data){
            var that = this
            var typeName = "";
            if(data.type == 0){
                typeName = that.Local ? that.Local.prop('cust.Manager') : 'Manager'
            }else if(data.type == 8 || data.type == 10){
                typeName = that.Local ? that.Local.prop('cust.Distributor') : 'Distributor'
            }else if(data.type == 11){
                typeName = that.Local ? that.Local.prop('cust.Sale') : 'Sales'
            }else{
                typeName = that.Local ? that.Local.prop('cust.User') : 'End User'
            }
            return typeName;
        }
        /**
         * 回选设备
         */
        function checkHistory(treeObj){
            if(!treeObj){
                treeObj = $.fn.zTree.getZTreeObj('ud_deviceTree');
            }
            treeObj.checkAllNodes(false);
            var imeis = getAllCheckValue();
            if(imeis){
                var array = imeis.split(',');
                $.each(array,function(i,v){
                    var node = treeObj.getNodeByParam("id", v, null);
                    if(node){
                        treeObj.checkNode(node,true,true,false);
                    }
                });
            }
        }
        //设备树节点处理
        function deviceTree_dataFilter(treeId, parentNode, responseData){
            var that = this
            var result = null;
            if(responseData && responseData.data){
                result = responseData.data;
                $.each(result,function(i,v){
                    if(v.iconSkin == "group"){
                        if(v.name.indexOf("默认组") >= 0){
                            v.name = v.name.replace("默认组", that.Local ? that.Local.prop('Asset.Defaultgroup') : 'Default Group');
                        }
                        result[i] = {"id":v.id,"name":v.name, "isParent":v.isParent,"open":v.open,"iconSkin":v.iconSkin,"imeisOrdevName":""};
                    }else{
                        if(!v.chkExpire){
                            v.name = v.vehicleId+"["+v.id+"]";
                        }
                    }
                });
            }
            return result;
        }
        /**
         * 获取初始化设备树的节点数据
         */
        function getDeviceTreeNode(userId,imeisOrdevName){
            var that = this
            var result = null
            var userId = userId
            var imeisOrdevName = imeisOrdevName
            getInitDeviceNode(userId,imeisOrdevName).then((ret)=>{
                if(ret && ret.code == 0){
                    result = deviceTree_dataFilter('',null,ret.data); //节点数据处理
                    $.fn.zTree.init($("#ud_deviceTree"),deviceTree_setting,ret.data)
                }
            }).catch((e)=>{
                console.log(e)
            })
            return result;
        }
        /**
         * 用户树节点点击之前的事件
         */
        function userTree_zTreeBeforeClick(treeId, treeNode, clickFlag){
            var treeObj = $.fn.zTree.getZTreeObj(treeId); 
            var selectNode = treeObj.getSelectedNodes();
            //如果重复点击已选中的节点， 则不调用onclick事件，防止重复加载设备树。
            if(selectNode && selectNode.length > 0 && selectNode[0].id == treeNode.id){ 
                return false;
            }
            treeObj = $.fn.zTree.getZTreeObj('#ud_deviceTree');
            if(treeObj != null){
                var nodes = treeObj.getNodes();
                if(nodes && nodes.length > 0){
                    node_cache.set(selectNode[0].id,treeObj.getNodes());
                }
            }
        }
        /**
         * 用户树点击事件
         */
        function userTree_zTreeOnClick(event, treeId, treeNode){
            var that = this
            //显示加载提示
            $("#ud_deviceTree_loadingData").show();
            $("#ud_deviceTree_nodata").hide();
            $("#ud_deviceTree").hide();
            var userId = treeNode.id;
            console.log(userId)
            $("#key2").val("");
            
            //销毁上个用户的设备树
            var treeObj = $.fn.zTree.getZTreeObj("ud_deviceTree");
            if(treeObj != null){
                treeObj.destroy();
            }
            var deviceNodes = node_cache.get(userId);
            if(!deviceNodes || deviceNodes.length <= 0){
                deviceNodes = getDeviceTreeNode(userId,'');
            }
            if(deviceNodes && deviceNodes.length > 0){
                //初始化设备树
                var deviceTreeObj = $.fn.zTree.init($("#ud_deviceTree"),deviceTree_setting,deviceNodes);
                // $.fn.zTree.init($("#ud_deviceTree"),deviceTree_setting,deviceNodes);
                console.log($.fn.zTree.init($("#ud_deviceTree"),deviceTree_setting,deviceNodes))
                checkHistory(deviceTreeObj);
                //隐藏加载提示
                $("#ud_deviceTree_loadingData").hide();
                $("#ud_deviceTree").show();
            }else{
                $("#ud_deviceTree_loadingData").hide();
                $("#ud_deviceTree_nodata").show();
            }
        }
        /**
         * 设备树勾选事件
         */
        function deviceTree_zTreeOnCheck(event, treeId, treeNode){
            var data = new Array();
            if(treeNode.iconSkin == 'group'){//勾选分组节点时,获取分组下的所有节点
                var childNode = treeNode.children;
                if(childNode && childNode.length > 0){
                    $.each(childNode,function(i,v){
                        data.push({'name':v.name,'imei':v.id});
                    });
                }
            }else{ //勾选设备节点
                data.push({'name':treeNode.name,'imei':treeNode.id});
            }
            if(treeNode.checked){ //选中时
                $("#checkList").append(template('checkDevice_li_tmp',{'data':data}));
                var total = $("#devNumber").text();
                $("#devNumber").html(Number(total)+data.length);
            }else{
                //取消选中时
                $.each(data,function(i,v){
                    var element = $("#checkList li[data='"+v.imei+"']");
                    if(element && element.length > 0){
                        $(element).remove();
                        var total = $("#devNumber").text();
                        $("#devNumber").html(Number(total)-1);
                    }
                });
            }
        }

        /**
         * 单个移除选中设备的方法
         */
        function removeDevice(imei,obj){
            $(obj).parent().remove();  //删除元素
            var total = $("#devNumber").text();
            $("#devNumber").html(Number(total)-1);  //总数-1
            //取消设备树节点选中
            var treeObj = $.fn.zTree.getZTreeObj('ud_deviceTree');
            var node = treeObj.getNodesByFilter(deviceTree_nodeFilter,true,null,imei);
            if(node){
                treeObj.checkNode(node,false,true,false);
            }
        }

        /**
         * 清空所有选择的设备
         */
        function removeAll(){
            $("#checkList").empty();  //清空所有元素
            $("#devNumber").html('0');  //总数归0
            //设备树所有节点取消选中
            var treeObj = $.fn.zTree.getZTreeObj('ud_deviceTree');
            treeObj.checkAllNodes(false);
        }

        //设备树搜索过滤方法 返回符合关键字的节点
        function deviceTree_nodeFilter(node,keyword){
            return (node.id == keyword);
        }

        /**
         * 获取所有已选中的设备
         */
        function getAllCheckValue(){
            var result = "";
            var element = $("#checkList li");
            if(element && element.length > 0){
                $.each(element,function(i,v){
                    result += $(v).attr("data")+",";
                });
                result = result.substring(0, result.length -1);
            }
            return result;
        }

        /**
         * 设备树点击前事件，为防止设备名称选中效果，以点击前事件替代点击事件
         */
        function deviceTree_zTreeBeforeClick(treeId, treeNode, clickFlag){
            var that = this
            if(deviceTree_zTreeBeforeCheck(treeId, treeNode)){
                //点击前已选中， 则本次操作为取消选中
                if(treeNode.checked){
                    treeNode.checked = false;
                }else{
                    treeNode.checked = true;
                }
                //节点勾选处理
                var data = new Array();
                if(treeNode.iconSkin == 'group'){
                    var childNode = treeNode.children;
                    if(childNode && childNode.length > 0){
                        data = childNode;
                    }
                }else{
                    data.push(treeNode);
                }
                var treeObj = $.fn.zTree.getZTreeObj(treeId); 
                $.each(data,function(i,v){
                    treeObj.checkNode(v,treeNode.checked,true,false);
                });
                //已选设备及总数处理
                deviceTree_zTreeOnCheck(null,treeId,treeNode);
            }
            return false;
        }

        /**
         * 设备树勾选前的事件，如果勾选分组节点并且分组节点下没有设备节点时，则本次勾选不做操作
         */
        function deviceTree_zTreeBeforeCheck(treeId, treeNode){
            if(treeNode.iconSkin == 'group' && (!treeNode.children || treeNode.children.length <= 0)){
                if(!treeNode.zAsync){
                    var treeObj = $.fn.zTree.getZTreeObj(treeId);
                    if(!treeNode.checked){
                        treeObj.checkNode(treeNode,true,true,false);
                    }
                    deviceTree_zTreeBeforeAsync(treeId, treeNode);//强行异步加载前，构建参数
                    treeObj.reAsyncChildNodes(treeNode, "refresh",false);
                }
                return false;
            }else{
                return true;
            }
        }

        /**
         * 异步加载前的回调方法，处理请求需要的参数
         */
        function deviceTree_zTreeBeforeAsync(treeId, treeNode){
            if(treeNode){
                treeNode.imeisOrdevName = $("#key2").val();
                var treeObj = $.fn.zTree.getZTreeObj('ud_userTree');
                var selectNode = treeObj.getSelectedNodes();
                if(selectNode && selectNode.length > 0){
                    treeNode.userId = selectNode[0].id;
                }
            }
            return true;
        }

        //节点展开之前的回调
        function deviceTree_zTreeBeforeExpand(treeId, treeNode){
            //若节点已经异步加载过， 但是搜索条件有变化，再次展开时，更新下级节点
            if(treeNode.zAsync && treeNode.imeisOrdevName != $("#key2").val()){
                var treeObj = $.fn.zTree.getZTreeObj(treeId);
                deviceTree_zTreeBeforeAsync(treeId, treeNode);//强行异步加载前，构建参数
                treeObj.reAsyncChildNodes(treeNode, "refresh",false);
            }
        }

        /**
         * 设备树异步加载成功回调
         */
        function deviceTree_zTreeOnAsyncSuccess(event, treeId, treeNode, msg){
            var treeObj = $.fn.zTree.getZTreeObj(treeId);
            //因为异步加载时， 搜索条件变化后， 强制异步加载后的数据跟之前的不一样的，重新设置分组的总数
            treeNode.name = treeNode.name.substring(0,treeNode.name.indexOf('(')+1)+treeNode.children.length+")";
            treeObj.updateNode(treeNode);
            var childrenNode = treeNode.children;
            if(treeNode.checked && childrenNode && childrenNode.length > 0){
                $.each(childrenNode,function(i,v){
                    var element = $("#checkList li[data='"+v.id+"']");
                    if(element && element.length > 0){
                        element.remove();
                        var total = $("#devNumber").text();
                        $("#devNumber").html(Number(total)-1);
                    }
                    treeObj.checkNode(v,true,false,false);
                });
                deviceTree_zTreeOnCheck(null,treeId,treeNode);
            }else{
                //取消勾选状态
                treeObj.checkNode(treeNode,false,true,false);
                //重新勾选
                checkHistory(treeObj);
            }
        }

        /**
         * 设备树搜索
         */
        function deviceTree_search(){
            $("#ud_deviceTree_loadingData").show();
            $("#ud_deviceTree").hide();
            $("#ud_deviceTree_nodata").hide();
            
            var imeisOrdevName = $("#key2").val();
            //获取选中用户ID
            var userTreeObj = $.fn.zTree.getZTreeObj('ud_userTree');
            var selectNode = userTreeObj.getSelectedNodes();
            if(selectNode && selectNode.length > 0){
                userId = selectNode[0].id;
                var deviceNodes = getDeviceTreeNode(userId,imeisOrdevName);
                if(deviceNodes && deviceNodes.length > 0){
                    //初始化设备树
                    var deviceTreeObj = $.fn.zTree.init($("#ud_deviceTree"),deviceTree_setting,deviceNodes);
                    $("#ud_deviceTree_loadingData").hide();
                    $("#ud_deviceTree").show();
                    
                    //回选设备
                    checkHistory(deviceTreeObj);
                }else{
                    $("#ud_deviceTree_loadingData").hide();
                    $("#ud_deviceTree_nodata").show();
                }
            }
        }
</script>

<style lang="less">
.deviceDialog {
    .el-dialog__body {
        padding: 15px 20px;
    }
}
.areaTree {
    border: 1px solid #ccc;
    padding: 15px;
    background: #fdfdfd;
    .tree-search{
        position: relative;
        z-index: 3;
        height: 24px;
        background-color: #fff;
        margin-bottom: 3px;
        border: 1px solid #ccc;
        box-sizing: content-box;
        .tree-search-icon {
            position: absolute;
            right: 0;
            width: 24px;
            height: 24px;
            border-left: 1px solid #ccc;
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .empty{
            width: 292px;
            line-height: 24px;
            font-size: 14px;
        }
    }
    .tree-box {
        height: 250px;
        overflow: auto;
    }
}
.selectList{
    margin-top: 20px;
}

</style>
