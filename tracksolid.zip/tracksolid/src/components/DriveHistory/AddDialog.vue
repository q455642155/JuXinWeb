<template>
	<el-dialog
		:title="Local ? Local.prop('history.add') : 'Add Driver History'"
		width="40%"
		top="8vh"
		class="driverDialog"
		:visible.sync="visibleP"
		:before-close="beforeClose"
		:close-on-click-modal="false"
		:close-on-press-escape="false"
	>
        <section>
            <el-form class="dialog-form" ref="DriverHistoryForm" :model="DriverHistoryForm" status-icon :rules="rules" label-width="120px">
                <el-row >
                    <el-col :span="24">
                        <el-form-item :label="Local ? Local.prop('history.Name') : 'Name'" prop="pathName">
                            <el-input :maxlength="100" v-model.trim="DriverHistoryForm.pathName" :placeholder="Local ? Local.prop('history.Name') : 'Name'"></el-input>
                        </el-form-item>
                        <el-form-item :label="Local ? Local.prop('history.Description') : 'Description'" prop="description">
                            <el-input
                                type="textarea"
                                :maxlength="200" 
                                resize="none"
                                :placeholder="Local ? Local.prop('history.Description') : 'Description'"
                                :rows="2"
                                v-model.trim="DriverHistoryForm.description"
                            >
                            </el-input>
                        </el-form-item>
                    </el-col>	
                </el-row>
            </el-form>
        </section>
		<span slot="footer" class="dialog-footer">
			<el-button type="primary" @click="saveLat">{{ this.Local ? this.Local.prop('comm.Save') : 'Save' }}</el-button>
            <el-button>{{ this.Local ? this.Local.prop('Geozones.saveandlink') : 'Save & Assign Device' }}</el-button>
            <el-button @click="hidden()">{{ this.Local ? this.Local.prop('index.Cancel') : 'Cancel' }}</el-button>
		</span>
	</el-dialog>
</template>

<script type="text/ecmascript-6">
import { promptMessage } from '@/common/js/common'
import {addOrEditInfo} from '@/api/Drivehistory/index.js'
export default {
    props: {
        visibleP: {
            type: Boolean,
            default: false
        },
        latDetail: {
            type: Array,
            default: ''
        }
    },
    data () {
        return {
            rules: {
                pathName: [
                    { required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
                ]
            },
            DriverHistoryForm: {
                pathName: '',
                description: ''
            }
        }
    },
    methods: {
        hidden() {
            this.$emit('update:visibleP', false)
            this.$emit('clearMap')
            // 移除表单验证 重置表单
            this.DriverHistoryForm.pathName = ''
            if(this.$refs.DriverHistoryForm) {
                this.$refs.DriverHistoryForm.clearValidate()
            }
        },
        // Dialog - 关闭之前
        beforeClose() {
            this.hidden()
        },
        // 清除表单的验证
        clearInputValidate(){
           if(this.$refs.DriverHistoryForm) {
                this.$refs.DriverHistoryForm.clearValidate()
            } 
        },
        // 保存
        saveLat(){
            let id = ''
            let imeis = ''
            let pathName = this.DriverHistoryForm.pathName
            let description = this.DriverHistoryForm.description
            let pathJson = this.latDetail
            this.$refs.DriverHistoryForm.validate((valid) => {
                if (valid) {
                    addOrEditInfo(id,imeis,pathName,description,pathJson).then(res => {
                        if (res.code === 0) {
                            this.$emit('refresh')
                            this.hidden()
                        }
                        // 根据 code 的值给出提示信息
                        promptMessage.call(this,res.code)
                    }).catch((e)=>{
                        this.$message({
                            message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
                            center: true,
                            type: 'error'
                        });
                    })
                } else {
                    return false;
                }
            });
        }
    }
}
</script>

<style lang="less">
</style>
