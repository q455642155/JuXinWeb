<template>
    <div class="editDriveDialog">
        <el-card class="box-card" v-show="visibleP">
            <div slot="header" class="clearfix">
                <span>{{Local ? Local.prop('history.edit') : 'Edit Driver History'}}</span>
                <span class="close" @click="beforeClose"><i class="el-icon-close"></i></span>
            </div>
            <div class="text item">
                <el-form class="dialog-form" ref="routeHistoryForm" :model="routeHistoryForm" status-icon :rules="rules" label-width="120px">
                    <el-row >
                        <el-col :span="24">
                            <el-form-item :label="Local ? Local.prop('history.Name') : 'Name'" prop="pathName">
                                <el-input :maxlength="100" v-model.trim="routeHistoryForm.pathName" :placeholder="Local ? Local.prop('history.Name') : 'Name'"></el-input>
                            </el-form-item>
                            <el-form-item :label="Local ? Local.prop('history.Description') : 'Description'" prop="description">
                                <el-input
                                    type="textarea"
                                    :maxlength="200"
                                    resize="none"
                                    :placeholder="Local ? Local.prop('history.Description') : 'Description'"
                                    :rows="2"
                                    v-model.trim="routeHistoryForm.description"
                                >
                                </el-input>
                            </el-form-item>
                        </el-col>	
                    </el-row>
                </el-form>
            </div>
            <div class="bottom">
                <el-button type="primary" @click="saveLat">{{ this.Local ? this.Local.prop('comm.Save') : 'Save' }}</el-button>
                <el-button @click="hidden()">{{ this.Local ? this.Local.prop('index.Cancel') : 'Cancel' }}</el-button>
            </div>
        </el-card>
    </div>
</template>

<script type="text/ecmascript-6">
import { promptMessage } from '@/common/js/common'
import {addOrEditInfo} from '@/api/Drivehistory/index.js'
export default {
    props: {
        visibleP: {
            type: Boolean,
            default: false
        },
        form: {
            type: Object,
            default: ''
        },
        latDetail: {
            type: Array,
            default: ''
        }
    },
    data () {
        return {
            rules: {
                pathName: [
                    { required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
                ]
            },
            routeHistoryForm: {
                id: '',
                imeis: '',
                pathName: '',
                description: '',
                pathJson: ''
            }
        }
    },
    methods: {
        hidden() {
            this.$emit('update:visibleP', false)
            this.$emit('clearMap')
            // 移除表单验证 重置表单
            this.routeHistoryForm.pathName = ''
            if(this.$refs.routeHistoryForm) {
                this.$refs.routeHistoryForm.clearValidate()
            }
        },
        // Dialog - 关闭之前
        beforeClose() {
            this.hidden()
        },
        // 清除表单的验证
        clearInputValidate(){
           if(this.$refs.routeHistoryForm) {
                this.$refs.routeHistoryForm.clearValidate()
            } 
        },
        // 保存
        saveLat(){
            let id = this.DriverHistoryForm.id
            let imeis = this.DriverHistoryForm.imeis
            let pathName = this.DriverHistoryForm.pathName
            let description = this.DriverHistoryForm.description
            let pathJson = this.latDetail
            this.$refs.DriverHistoryForm.validate((valid) => {
                if (valid) {
                    addOrEditInfo(id,imeis,pathName,description,pathJson).then(res => {
                        if (res.code === 0) {
                            this.$emit('refresh')
                            this.hidden()
                        }
                        // 根据 code 的值给出提示信息
                        promptMessage.call(this,res.code)
                    }).catch((e)=>{
                        this.$message({
                            message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
                            center: true,
                            type: 'error'
                        })
                    })
                } else {
                    return false
                }
            })
        }
    },
    watch: {
        // 监听传入参数 form 的变化 
        form: function (newForm, oldForm) {
            if(this.$refs.routeHistoryForm) {
                this.$refs.routeHistoryForm.clearValidate()
            }
            this.routeHistoryForm = newForm
        }
    }
}
</script>

<style lang="less">
.editDriveDialog {
    position:absolute;
    z-index: 9999;
    width: 30%;
    top: 20px;
    left: 30px;
    .close {
        float: right; 
        padding: 3px 0;
        cursor: pointer;
    }
    .bottom {
        text-align: right;
    }
}
</style>
