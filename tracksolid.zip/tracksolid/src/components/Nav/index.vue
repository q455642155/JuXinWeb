<template>
	<nav class="Nav animated" :class="{ 'nav-small': navStatus }">
		<div class="nav-control" @click="toggeleNav()">
			<i class="el-icon-menu"></i>
		</div>
		<ul class="nav-ul">
			<li :class="{ active: active === 0 }">
				<router-link tag="a" to="/dashboard">
					<i v-show="active === 0" class="icon-active-left"></i>
					<i class="fa fa-line-chart"></i>
					<span v-show="!navStatus">
						{{ this.Local ? this.Local.prop('header.AccountCenter') : 'Dashboard' }}
					</span>
				</router-link>
			</li>
			<li :class="{ active: active === 1 }">
				<router-link tag="a" to="/driver">
					<i v-show=" active === 1 " class="icon-active-left"></i>
					<i class="fa fa-id-card-o"></i>
					<span v-show="!navStatus">
						{{ this.Local ? this.Local.prop('Fleet.Driver') : 'Driver' }}
					</span>
				</router-link>
			</li>
			<li :class="{ active: active === 2 }">
				<router-link tag="a" to="/vehicle">
					<i v-show=" active === 2 " class="icon-active-left"></i>
					<i class="fa fa-car"></i>
					<span v-show="!navStatus">
						{{ this.Local ? this.Local.prop('Fleet.Vehicle.Vehicle') : 'Vehicle' }}
					</span>
				</router-link>
			</li> 
			<li :class="{ active: active === 3 }">
				<router-link tag="a" to="/rfid">
					<i v-show=" active === 3 " class="icon-active-left"></i>
					<i class="fa fa-shield"></i>
					<span v-show="!navStatus">
						{{ this.Local ? this.Local.prop('Fleet.rfid') : 'RFID History' }}
					</span>
				</router-link>
			</li>
			<!-- <li :class="{ active: active === 3 }">
				<router-link tag="a" to="/drivingHistory">
					<i v-show=" active === 3 " class="icon-active-left"></i>
					<i class="icon-history"></i>
					<span v-show="!navStatus">
						Driving History
					</span>
				</router-link>
			</li> -->
		</ul>
	</nav>
</template>

<script type="text/ecmascript-6">
	import { mapGetters, mapActions} from 'vuex'

	export default {
		name: 'Nav',
		props: {
			// 导航条选中状态 默认-1无选中的
			active: {
				type: Number,
				default: -1,
			}
		},
		data() {
			return {
				tabPosition: 'left'
			}
		},
		computed: {
			...mapGetters([
				'navStatus'
			])
		},
		methods: {
			toggeleNav() {
				this.toggleNavStatus(!this.navStatus)
			},
			...mapActions([
				'toggleNavStatus'
			])
		}
	}
</script>

<style lang='less'>
	.Nav {
		display: inline-block;
		float: left;
		width: 150px;
		height: 100%;
		color: #868aa8;
		background: #2d2f3e;
		box-sizing: border-box;
		.nav-control {
			padding: 20px 0px;
			text-align: center;
			cursor: pointer;
			color: #00aaff
		}
		ul.nav-ul {
			li {
				position: relative;
				text-align: center;
				cursor: pointer;
				a {
					display: block;
					padding: 14px;
					color: #525672;
					i {
						display: block;
						color: #525672;
						text-align: center;
					}
					span {
						display: block;
						margin-top: 10px;
						color: #868aa8;
						text-align: center;
						font-size: 14px;
					}
				}
			}
			li:hover {
				background: #282a3a;
				a i,a span{
					color: #8c8ea4;
				}
			}
			li.active {
				background: #282a3a;
				a i, a span{
					color: #FF8F1B;
				}
				.icon-active-left {
					position: absolute;
					right: -23px;
					font-size: 50px;
					color: #f2f3f8;
					top: 10px;
				}
			}
		}
	}
	.nav-small {
		width: auto;
		.icon-active-left {
			position: absolute;
			right: -23px;
			font-size: 50px;
			color: #f2f3f8;
			top: 0px!important;
		}
	}
</style> 