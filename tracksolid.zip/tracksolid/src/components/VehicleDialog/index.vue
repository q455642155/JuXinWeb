<template>
	<el-dialog
		:title="Local ? Local.prop('Fleet.Vehicle.Vehicle') + ' ' + Local.prop('cust.Detail') : 'Vehicle Detail'"
		width="40%"
		top="5vh"
		class="vehicleDialog"
		:visible.sync="dialogVisible"
		:before-close="beforeClose"
		:close-on-click-modal="false"
		:close-on-press-escape="false"
	>
		<el-tabs v-model="activeName" type="card" @tab-click="handleClick">
			<el-tab-pane :label="this.Local ? this.Local.prop('Fleet.Basic') : 'Basic'" name="first">
				<el-form class="dialog-form" ref="VehicleAddForm" status-icon :rules="rules" :model="VehicleAddForm" label-width="180px">
					<el-row :gutter="20">
						<el-col :span="12">
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.VehicleNo') : 'Vehicle No.'" 
								prop="plateNo"
							>
								<el-input
									:maxlength=30
									v-model.trim="VehicleAddForm.plateNo" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.VehicleNo') : 'Vehicle No.'"
								>
								</el-input>
							</el-form-item>

							<el-form-item
								:label="Local ? Local.prop('Fleet.Vehicle.VehicleType') : 'Vehicle Type'" 
								prop="plateType"
							>
								<el-input 
									:maxlength=20
									v-model.trim="VehicleAddForm.plateType" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.VehicleType') : 'Vehicle Type'"
								>
								</el-input>
							</el-form-item>

							<el-popover
								class="deviceDataPopover"
								placement="bottom-end"
								width="206"
								trigger="hover"
							>
								<el-table 
									width="100%" 
									height="200" 
									:data="deviceData"
									v-loading="imeiLoading"
									:empty-text="Local ? Local.prop('comm.noData') : 'No data found'"
									@row-click="handleCurrentImeiChange"
								>
									<el-table-column
										:label="Local ? Local.prop('Asset.DeviceName') + '/' + Local.prop('Asset.DeviceIMEI') : 'Device Name/IMEI'" 
									>
										<template slot-scope="scope">
											<p :title="scope.row.imei">{{ scope.row.deviceName ? scope.row.deviceName : scope.row.imei}}</p>
										</template>
									</el-table-column>
								</el-table>
								<el-form-item 
									slot="reference" 
									:label="Local ? Local.prop('Fleet.Vehicle.TrackingDevice') : 'Tracking Device'" 
									prop="imei"
								>
									<el-input 
										:maxlength=20
										v-model.trim="VehicleAddForm.imei" 
										:placeholder="Local ? Local.prop('Fleet.Vehicle.TrackingDevice') : 'Tracking Device'">
									</el-input>
								</el-form-item>
							</el-popover>

							<el-form-item 
								:label="Local ? Local.prop('index.engineNumber') : 'Engine Number'" 
								prop="engineNo"
							>
								<el-input 
									:maxlength=30
									v-model.trim="VehicleAddForm.engineNo" 
									:placeholder="Local ? Local.prop('index.engineNumber') : 'Engine Number'">
								</el-input>
							</el-form-item>
							<el-popover
								class="deviceDataPopover"
								placement="bottom-end"
								width="206"
								trigger="hover"
							>
								<el-table 
									width="100%" 
									height="200" 
									:data="driveNumberData"
									v-loading="driveNoLoading"
									:empty-text="Local ? Local.prop('comm.noData') : 'No data found'"
									@row-click="handleCurrentDriveChange"
								>
									<el-table-column
										:label="Local ? Local.prop('Fleet.Driver') : 'Driver'" 
									>
										<template slot-scope="scope">
											<p :title="scope.row.driverNo">{{ scope.row.driverNo }}</p>
										</template>
									</el-table-column>
								</el-table>
								<el-form-item
									slot="reference"
									:label="Local ? Local.prop('Fleet.Driver') : 'Driver'" 
									prop="driverNo"
								>
									<el-input 
										:maxlength=30
										v-model.trim="VehicleAddForm.driverNo" 
										:placeholder="Local ? Local.prop('Fleet.Driver') : 'Driver'">
									</el-input>
								</el-form-item>
							</el-popover>
							
							<el-form-item 
								:label="Local ? Local.prop('Alert.status') : 'Status'" 
								prop="status"
							>
								<el-radio-group v-model="VehicleAddForm.status">
									<el-radio :label="1">{{ this.Local ? this.Local.prop('Fleet.Vehicle.Using') : 'Using' }}</el-radio>
									<el-radio :label="2">{{ this.Local ? this.Local.prop('Fleet.Vehicle.Sold') : 'Sold' }}</el-radio>
								</el-radio-group>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.MaxSpeed') : 'Max Speed'" 
								prop="maxSpeed"
							>
								<el-input 
									:maxlength=6
									v-model.trim="VehicleAddForm.maxSpeed" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.MaxSpeed') : 'Max Speed'" 
								>
								</el-input>
								<span class="speed-unit">{{ this.Local ? this.Local.prop('comm.SpeedUnit') : 'km/h' }}</span>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.Brand') : 'Brand'" 
								prop="brand"
							>
								<el-input 
									:maxlength=50
									v-model.trim="VehicleAddForm.brand" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.Brand') : 'Brand'"
								>
								</el-input>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.Model') : 'Model'" 
								prop="model"
							>
								<el-input 
									:maxlength=30
									v-model.trim="VehicleAddForm.model" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.Model') : 'Model'" 
								>
								</el-input>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Driver.Ext1') : 'Ext.1'"  
								prop="ext1"
							>
								<el-input 
									:maxlength=30
									v-model.trim="VehicleAddForm.ext1" 
									:placeholder="Local ? Local.prop('Fleet.Driver.Ext1') : 'Ext.1'"  
								>
								</el-input>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Driver.Ext3') : 'Ext.3'" 
								prop="ext3"
							>
								<el-input 
									:maxlength=30
									v-model.trim="VehicleAddForm.ext3" 
									:placeholder="Local ? Local.prop('Fleet.Driver.Ext3') : 'Ext.3'" 
								>		
								</el-input>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.EffectDate') : 'Insurance Effect Date'" 
								prop="effectDate"
							>
								<el-date-picker
									v-model="VehicleAddForm.effectDate"
									type="date"
									:placeholder="Local ? Local.prop('header.chooseTime') : 'Choose Time'">
								</el-date-picker>
							</el-form-item>

						</el-col>
						<el-col class="right" :span="12">
							<el-form-item :label="Local ? Local.prop('Fleet.Vehicle.Vehicle') : 'Vehicle'">
								<el-upload
									class="avatar-uploader"
									action="http://172.16.0.121:8683/driver/upload"
									:show-file-list="false"
									:before-upload="beforeAvatarUpload"
									:http-request="upload"
								>
									<div v-show="uploadLoading" class="upload-loading">
										<div class="loading">
											<i class="el-icon-loading"></i>
											<p>{{ this.Local ? this.Local.prop('Asset.upload') : 'Upload' }} ...</p>
										</div>
									</div>
									<img v-if="VehicleAddForm.imagePath" :src="VehicleAddForm.imagePath" class="avatar">
									<i v-else class="el-icon-plus avatar-uploader-icon"></i>
									<input type="hidden" ref="uploader"  name="">
								</el-upload>
								<p class="upload-btn">
									<el-button @click="handleUploadAvatar" icon="el-icon-upload2" size="mini">
										{{ this.Local ? this.Local.prop('Asset.upload') : 'Upload' }}
									</el-button>
									<el-button @click="handleDelectVehicle()" icon="el-icon-delete"  size="mini">
										{{ this.Local ? this.Local.prop('Asset.Delete') : 'Delete' }}
									</el-button>
								</p>
								<p class="tips">
									<i class="el-icon-warning"></i>
									{{ this.Local ? this.Local.prop('Fleet.Driver.UpdataLimit') : 'Only support jpg/png, file size should not large than 2048kb.' }}
								</p>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.VIN') : 'VIN'" 
								prop="vin"
							>
								<el-input 
									:maxlength=30
									v-model.trim="VehicleAddForm.vin" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.VIN') : 'VIN'" 
								>
								</el-input>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.Fuel') : 'Fuel/100km'" 
								prop="fuel"
							>
								<el-input 
									:maxlength=2
									v-model.trim="VehicleAddForm.fuel" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.Fuel') : 'Fuel/100km'" 
								>
								</el-input>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.Color') : 'Color'" 
								prop="color"
							>
								<el-input 
									:maxlength=20
									v-model.trim="VehicleAddForm.color" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.Color') : 'Color'"
								>
								</el-input>
							</el-form-item>
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.ProductionYear') : 'Production Year'"
								prop="productionYear"
							>
								<el-input 
									:maxlength=10
									v-model.trim="VehicleAddForm.productionYear" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.ProductionYear') : 'Production Year'"
								>
								</el-input>
							</el-form-item>
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Driver.Ext2') : 'Ext.2'" 
								prop="ext2"
							>
								<el-input 
									:maxlength=30
									v-model.trim="VehicleAddForm.ext2" 
									:placeholder="Local ? Local.prop('Fleet.Driver.Ext2') : 'Ext.2'"
								>
								</el-input>
							</el-form-item>

							<el-form-item 
								:label="Local ? Local.prop('Fleet.Driver.Ext4') : 'Ext.4'" 
								prop="ext4"
							>
								<el-input 
									:maxlength=30
									v-model.trim="VehicleAddForm.ext4" 
									:placeholder="Local ? Local.prop('Fleet.Driver.Ext4') : 'Ext.4'"
								>
								</el-input>
							</el-form-item>
							
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.ExpireDate') : 'Insurance Expire Date'" 
								prop="expireDate"
							>
								<el-date-picker
									v-model="VehicleAddForm.expireDate"
									type="date"
									:placeholder="Local ? Local.prop('header.chooseTime') : 'Choose Time'">
								</el-date-picker>
							</el-form-item>
						</el-col>
					</el-row>
					<el-row >
						<el-col :span="24">
							<el-form-item 
								:label="Local ? Local.prop('Asset.reMark') : 'Remark'"
								prop="remark"
							>
								<el-input
									:maxlength="200"
									type="textarea"
									:placeholder="Local ? Local.prop('Asset.reMark') : 'Remark'"
									:rows="2"
									v-model.trim="VehicleAddForm.remark"
									resize="none"
								>
								</el-input>
							</el-form-item>
						</el-col>
					</el-row>
				</el-form>
			</el-tab-pane>
			<el-tab-pane :label="this.Local ? this.Local.prop('Fleet.Advanced') : 'Advanced'" name="second">
				<el-form class="dialog-form" label-width="160px" :model="secondAddForm">
					<!--OverspeedAlert-->
					<div class="secondTitle">{{this.Local ? this.Local.prop('Fleet.OverspeedAlert') : 'Overspeed Alert'}}</div>
					<el-row :gutter="20">
						<el-col :span="12">
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.MaxSpeed') : 'Max Speed.'" 
								prop="overSpeed"
							>
								<el-input
									:maxlength=30
									v-model.trim="secondAddForm.overSpeed" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.MaxSpeed') : 'Max Speed.'"
								>
								</el-input>
							</el-form-item>
						</el-col>
						<el-col class="right" :span="12">
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.Duration') : 'Duration'" 
								prop="overSecond"
							>
								<el-input 
									:maxlength=30
									v-model.trim="secondAddForm.overSecond" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.Duration') : 'Duration'" ref="secondOverSpeed"
								>
								</el-input>
							</el-form-item>
						</el-col>
					</el-row>
					<el-row>
						<el-col :span="2" :offset="22">
							<el-button type="primary" size="small" @click="saveOverSpeed">{{ this.Local ? this.Local.prop('comm.Save') : 'Save' }}</el-button>
						</el-col>
					</el-row>
					<!--Maintenance-->
					<div class="secondTitle">{{this.Local ? this.Local.prop('Fleet.Maintenance') : 'Maintenance'}}</div>
					<el-row :gutter="20">
						<div class="radioList">
							<el-radio-group v-model="radioValue">
								<el-radio :label="1">{{this.Local ? this.Local.prop('Fleet.Mileage') : 'Mileage'}}</el-radio>
								<el-radio :label="2">{{this.Local ? this.Local.prop('Fleet.AccOnDuration') : 'ACC-ON Duration'}}</el-radio>
							</el-radio-group>
						</div>
						<el-col :span="12" v-show="radioValue === 1">
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.Mileagethreshold') : 'Mileage threshold'" 
								prop="mileageThreshold"
							>
								<el-input
									:maxlength=30
									v-model.trim="secondAddForm.mileageThreshold" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.Mileagethreshold') : 'Mileage threshold'"
								>
								</el-input>
							</el-form-item>
						</el-col>
						<el-col class="right" :span="12" v-show="radioValue === 1">
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.CurrentMileage') : 'Current mileage'" 
								prop="odometer"
							>
								<el-input 
									:maxlength=30
									v-model.trim="secondAddForm.odometer" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.CurrentMileage') : 'Current mileage'" 
								>
								</el-input>
							</el-form-item>
						</el-col>
						<el-col :span="12" v-show="radioValue === 2">
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.AccOnThreshold') : 'ACC-ON threshold'" 
								prop="aCCOnDurtionThreshold"
							>
								<el-input
									:maxlength=30
									v-model.trim="secondAddForm.aCCOnDurtionThreshold" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.AccOnThreshold') : 'ACC-ON threshold'"
								>
								</el-input>
							</el-form-item>
						</el-col>
						<el-col class="right" :span="12" v-show="radioValue === 2">
							<el-form-item 
								:label="Local ? Local.prop('Fleet.Vehicle.CurrentDuration') : 'Current Duration'" 
								prop="currentAccOnDuration"
							>
								<el-input 
									:maxlength=30
									v-model.trim="secondAddForm.currentAccOnDuration" 
									:placeholder="Local ? Local.prop('Fleet.Vehicle.CurrentDuration') : 'Current Duration'" 
								>
								</el-input>
							</el-form-item>
						</el-col>
					</el-row>
					<el-row class="mb10">
						<el-col :span="2" :offset="22">
							<el-button type="primary" size="small" @click="saveMile">{{ this.Local ? this.Local.prop('comm.Save') : 'Save' }}</el-button>
						</el-col>
					</el-row>
				</el-form>
			</el-tab-pane>
		</el-tabs>
		<span slot="footer" class="dialog-footer" v-show="activeName === 'first'">
			<el-button @click="hidden()">{{ this.Local ? this.Local.prop('index.Cancel') : 'Cancel' }}</el-button>
			<el-button type="primary" @click="save()">{{ this.Local ? this.Local.prop('comm.Save') : 'Save' }}</el-button>
		</span>
		<span slot="footer" class="dialog-footer" v-show="activeName === 'second'">
			<el-button @click="hidden()">{{ this.Local ? this.Local.prop('index.Cancel') : 'Cancel' }}</el-button>
		</span>
	</el-dialog>
</template>

<script type="text/ecmascript-6">
	import {vehicleUpdate, deviceQuery, getImeiDriveMile, getImeiMileThreshold, saveOverSpeed, saveAccOnDuration, saveMileThreshold, vehicleQuery} from '@/api/Vehicle'
	import { delFile, upload } from '@/api/Upload'
	import { promptMessage } from '@/common/js/common'

	export default {
		name: 'VehicleDialog',
		props: {
			// 表单内容 - 修改时候需要传入数据
			form: {
				type: Object,
				default: function() {
					return null
				}
			},
			// 如果是添加按钮弹出的，点击切换卡的时候不需要去调用接口
			btnType: {
				type: String,
				default: ''
			}
		},
		data() {
			var checkMaxSpeed = (rule, value, callback) => {
				if (!value) {
					return callback();
				} else {
					if (value > 200) {
						callback(new Error(this.Local ? this.Local.prop('Fleet.Driver.MaxSpeedValidate') : 'Max Speed should not large than 200.'))
					} else {
						return callback();
					}
				}
			};

			var checkIMEI = (rule, value, callback) => {
				if (!value || value == '') {
					return callback();
				} else {
					let message = this.Local ? this.Local.prop('Asset.imeiIsNotExist') : "IMEI doesn't exist."
					if (value.length == 15) {
						deviceQuery(value).then((res)=>{
							if (res.code == 0) {
								let imei = res.data.list[0] ? res.data.list[0].imei : null
								if (value == imei) {
									return callback();
								} else {
									callback(new Error(message))
								}
							} else {
								return callback();
							}
						}).catch((e)=>{
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							});
						})
					} else {
						callback(new Error(message))
					}
				}
			};

			var checkDriveNo = (rule, value, callback) => {
				if (!value || value == '') {
					return callback();
				} else {
					let message = this.Local ? this.Local.prop('Asset.driveNoIsNotExist') : "driveNo doesn't exist."
					if (value.length == 15) {
						vehicleQuery(value).then((res)=>{
							if (res.code == 0) {
								let driverNo = res.data.list[0] ? res.data.list[0].driverNo : null
								if (value == driverNo) {
									return callback();
								} else {
									callback(new Error(message))
								}
							} else {
								return callback();
							}
						}).catch((e)=>{
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							});
						})
					} else {
						callback(new Error(message))
					}
				}
			};
			return {
				// Dialog显示状态 - true显示/false隐藏
				dialogVisible: false,
				// 表单内容 - 添加/修改司机信息
				VehicleAddForm: {
					id: null,
					plateNo: null,
					plateType: null,
					imei: null,
					engineNo: null,
					driverNo: null,
					status: 1,
					maxSpeed: null,
					brand: null,
					model: null,
					productionYear: null,
					vin: null,
					fuel: null,
					color: null,
					ext1: null,
					ext2: null,
					ext3: null,
					ext4: null,
					remark: null,
					imagePath: '',
					effectDate: null,
					expireDate: null,
					reminderStatus: null
				},
				activeName: 'first',
				radioValue: 1,
				secondAddForm: {
					overSpeed: '',
					overSecond: '',
					mileageThreshold: '',
					odometer: '',
					aCCOnDurtionThreshold: '',
					currentAccOnDuration: ''
				},
				// 表单验证规则
				rules: {
					plateNo: [
						{ required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
					],
					plateType: [
						{ required: true, message: this.Local ? this.Local.prop('Commands.ItemNoEmPty') : 'The item cannot be empty'}
					],
					maxSpeed: [
						{ required: false, message: this.Local ? this.Local.prop('Commands.FilledPositiveInteger') : 'This item can only be filled with a positive integer.', pattern: /^[0-9]+$/ },
						{ validator: checkMaxSpeed }
					],
					fuel: [
						{ required: false, message: this.Local ? this.Local.prop('Commands.FilledPositiveInteger') : 'This item can only be filled with a positive integer.', pattern: /^[0-9]+$/ }
					],
					imei: [
						{ validator: checkIMEI }
					],
					driverNo: [
						{ validator: checkDriveNo}
					]
				},
				// 临时图片的 key
				fileName: null,
				// 图片上传状态
				uploadLoading: false,
				// 设备组
				deviceData: [],
				// 车辆号
				driveNumberData: [],
				// 请求设备
				imeiLoading: false,
				// 请求车辆号
				driveNoLoading: false
			}
		},
		created() {
			// 请求设备定时器
			this.timer = false
			this.timers = false
		},
		methods: {
			// 标签页切换
			handleClick(tab, event) {
				let imei = this.VehicleAddForm.imei
				if (tab.name === 'second') {
					if (this.btnType === 'edit') {
						// 获取设备对应的里程阈值
						getImeiMileThreshold(imei).then(res => {
							if (res.code === 0) {
								if(res.data.mileageThreshold){
										var currentMileageThreshold = res.data.mileageThreshold
										if(window.showUnit == 'mi' && currentMileageThreshold){
											currentMileageThreshold = (parseFloat(currentMileageThreshold) / 1.609344).toFixed(2)
										}
										if(window.showUnit == 'knot' && currentMileageThreshold){
											currentMileageThreshold = (parseFloat(currentMileageThreshold) / 1.852).toFixed(2)
										}
										currentMileageThreshold = parseFloat(currentMileageThreshold).toFixed(2)
										this.secondAddForm.threshold = currentMileageThreshold
								}
								this.secondAddForm.accThreshold = res.data.aCCOnDurtionThreshold
							}
							// 根据 code 的值给出提示信息
							promptMessage.call(this,res.code)
						}).catch(err => {
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							})
						})
						// 设备对应的行驶里程获取
						getImeiDriveMile(imei).then(ret => {
							this.radioValue = ret.data.maintenanceAlertFlag
							if(this.radioValue == '1'){
								if(ret.data.mileage){
										if(window.showUnit == 'mi'){
											this.secondAddForm.currentMileage = (parseFloat(ret.data.mileage) / 1.609344).toFixed(2)
										}else if(window.showUnit == 'knot'){
											this.secondAddForm.currentMileage = (parseFloat(ret.data.mileage) / 1.852).toFixed(2)
										}else{
											this.secondAddForm.currentMileage = parseFloat(ret.data.mileage).toFixed(2)
										}
								}
							}
							if(this.radioValue == '2'){
								if(ret.data.runTime){
									this.secondAddForm.currentDuration = ret.data.runTime
								}
							}
						}).catch(err => {
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							})
						})
					}
				}
      },
			// Dialog - 显示
			show() {
				this.dialogVisible = true
			},
			// Dialog - 隐藏
			hidden() {
				this.dialogVisible = false
				this.activeName = 'first' // 点击关闭后标签页恢复到第一个
				// 移除表单验证 重置表单
				this.reset()
			},
			// Form - 重置表单
			reset() {
				// 移除表单验证 重置表单
				this.VehicleAddForm = {
					id: null,
					plateNo: null,
					plateType: null,
					imei: null,
					engineNo: null,
					driverNo: null,
					status: 1,
					maxSpeed: null,
					brand: null,
					model: null,
					productionYear: null,
					vin: null,
					fuel: null,
					color: null,
					ext1: null,
					ext2: null,
					ext3: null,
					ext4: null,
					remark: null,
					imagePath: '',
					effectDate: null,
					expireDate: null
				}
				this.secondAddForm = {
					overSpeed: '',
					overSecond: '',
					mileageThreshold: '',
					odometer: '',
					aCCOnDurtionThreshold: '',
					currentAccOnDuration: ''
				}
				this.$nextTick(() => {	
					this.$refs.VehicleAddForm.clearValidate()
				})
			},
			// Dialog - 关闭之前
			beforeClose() {
				this.hidden()
			},
			// Form - 头像上传成功
			handleAvatarSuccess(res, file) {
				if (res.code === 0) {
					this.fileName = res.data.fileName
					this.VehicleAddForm.imagePath = res.data.path;
				}
			},
			// Form - 头像上传之前
			beforeAvatarUpload(file) {
				const isJPG = file.type == 'image/jpeg';
				const isPNG = file.type == 'image/png';
				const isLt2M = file.size / 1024 / 1024 < 2;
				let OK = true 
				let mseeage = this.Local ? this.Local.prop('Fleet.Driver.UpdataLimit') : 'Only support jpg/png, file size should not large than 2048kb.'
				if (!isJPG && !isPNG) {
					OK = false
					this.$message.info(mseeage);
				}
				if (!isLt2M) {
					OK = false
					this.$message.info(mseeage);
				}
				return OK
			},
			// Form - 删除上传图片
			handleDelectVehicle() {
				delFile(this.fileName).then((res)=>{
					if (res.code === 0) {
						this.VehicleAddForm.imagePath = ''
						this.fileName = null
						return
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this,res.code)
				}).catch((e)=>{
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
				})
			},
			// Form - 上传更新图片
			upload(res){
				this.uploadLoading = true
				upload(res.file).then((res)=>{
					if (res.code === 0) {
						this.fileName = res.data.fileName
						this.VehicleAddForm.imagePath = res.data.path;
						this.uploadLoading = false
						return
					}else {
						this.uploadLoading = false
					}
					// 根据 code 的值给出提示信息
					promptMessage.call(this,res.code)
				}).catch((e)=>{
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
					this.uploadLoading = false
				})
			},
			// Form - 提交数据
			save() {
				this.$refs.VehicleAddForm.validate((valid) => {
					if (valid) {
						this.vehicleUpdate()
					} else {
						return false;
					}
				});
				return
			},
			// Btn - 点击触发上传图片
			handleUploadAvatar() {
				this.$refs.uploader.click()
			},
			// Form - 表单提交的axios请求
			vehicleUpdate() {
				let	id=this.VehicleAddForm.id,
					plateNo=this.VehicleAddForm.plateNo,
					plateType=this.VehicleAddForm.plateType,
					imei=this.VehicleAddForm.imei,
					engineNo=this.VehicleAddForm.engineNo,
					driverNo=this.VehicleAddForm.driverNo,
					status=this.VehicleAddForm.status,
					maxSpeed=this.VehicleAddForm.maxSpeed,
					brand=this.VehicleAddForm.brand,
					model=this.VehicleAddForm.model,
					vin=this.VehicleAddForm.vin,
					fuel=this.VehicleAddForm.fuel,
					color=this.VehicleAddForm.color,
					ext1=this.VehicleAddForm.ext1,
					ext2=this.VehicleAddForm.ext2,
					ext3=this.VehicleAddForm.ext3,
					ext4=this.VehicleAddForm.ext4,
					imagePath=this.VehicleAddForm.imagePath,
					productionYear=this.VehicleAddForm.productionYear,
					remark=this.VehicleAddForm.remark,
					effectDate=this.VehicleAddForm.effectDate,
					expireDate=this.VehicleAddForm.expireDate,
					reminderStatus=this.VehicleAddForm.reminderStatus

				vehicleUpdate(id,plateNo,plateType,imei,engineNo,driverNo,status,maxSpeed,brand,model,vin,fuel,color,ext1,ext2,ext3,ext4,imagePath,productionYear,remark,effectDate,expireDate,reminderStatus).then((res)=>{
					if (res.code === 0) {
						// 根据 code 的值给出提示信息
						promptMessage.call(this,res.code)
						this.$emit('refresh')
						this.hidden()
					}
					if (res.code === 413) {
						this.$message({
							message: this.Local ? this.Local.prop('Alert.Message413') : 'Device has been bound',
							center: true,
							type: 'error'
						});
					}
				}).catch((e)=>{
					this.$message({
						message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
						center: true,
						type: 'error'
					});
				})
			},
			// From - 搜索
			deviceQuery() {
				clearTimeout(this.timer);

			    this.timer = setTimeout(() => {
					let imei = this.VehicleAddForm.imei
					this.imeiLoading = true
					if (imei) {
						deviceQuery(this.VehicleAddForm.imei).then((res)=>{
							this.imeiLoading = false
							if (res.code == 0) {
								this.deviceData = res.data.list
							}
						}).catch((e)=>{
							this.imeiLoading = false
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							});
						})
					} else {
						this.deviceData = []
						this.imeiLoading = false
					}
			    }, 500);
			},
			// 车辆号搜索
			driveNumberQuery() {
				clearTimeout(this.timers);

			    this.timers = setTimeout(() => {
					let driverNo = this.VehicleAddForm.driverNo
					this.driveNoLoading = true
					if (driverNo) {
						vehicleQuery(this.VehicleAddForm.driverNo).then((res)=>{
							this.driveNoLoading = false
							if (res.code == 0) {
								this.driveNumberData = res.data.list
							}
						}).catch((e)=>{
							this.driveNoLoading = false
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							});
						})
					} else {
						this.driveNumberData = []
						this.driveNoLoading = false
					}
			    }, 500);
			},
			// Table Imei - 选中的行发生改变
			handleCurrentImeiChange(val) {
				if (val) {
 					// 复制对象 避免造成影响
					this.VehicleAddForm.imei = val.imei
					this.VehicleAddForm.engineNo = val.engineNo
					this.VehicleAddForm.maxSpeed = val.maxSpeed
					this.VehicleAddForm.vin = val.vin
				} else {
					this.VehicleAddForm.imei = null
					this.VehicleAddForm.engineNo = null
					this.VehicleAddForm.maxSpeed = null
					this.VehicleAddForm.vin = null
				}
			},
			// Table DriveNo - 选中的行发生改变
			handleCurrentDriveChange(val) {
				if (val) {
 					// 复制对象 避免造成影响
					this.VehicleAddForm.driverNo = val.driverNo
				} else {
					this.VehicleAddForm.driverNo = null
				}
			},
			// 保存超速的 
			saveOverSpeed() {
				var imei = this.VehicleAddForm.imei
				var overSpeed = this.secondAddForm.overSpeed
				var overSecond = this.secondAddForm.overSecond
				if ((overSpeed && !overSecond) || (!overSpeed && overSecond)) {
					this.$message({
						message: this.Local ? this.Local.prop('header.Vehicle.SpeedDuration') : 'Max Speed or Duration not empty',
						center: true,
						type: 'error'
					})
					return
				}
				if (overSpeed) {
					if(window.showUnit == 'mi'){
						overSpeed = (parseFloat(overSpeed) * 1.609344).toFixed(4);
					}else if(window.showUnit == 'knot'){
						overSpeed = (parseFloat(overSpeed) * 1.852).toFixed(4);
					}
				}
				//判断时间是否是10的倍数
				if (overSecond && (overSecond == 0 || overSecond % 10 != 0)) {
					this.$message({
						message: this.Local ? this.Local.prop('header.Vehicle.SpeedDuration') : 'overSecond is not multiple of ten',
						center: true,
						type: 'error'
					})
					this.$refs.secondOverSpeed.focus()
					return
				}else if(overSecond < 0){//判断时间是否是大于0的整数
					this.$message({
						message: this.Local ? this.Local.prop('header.Vehicle.digits') : 'overSecond can not less than zero',
						center: true,
						type: 'error'
					})
					this.$refs.secondOverSpeed.focus()
					return
				}
				if (imei === '' || imei === null) {
					this.$message({
						message: this.Local ? this.Local.prop('Fleet.Vehicle.imei') : 'imei can not empty',
						center: true,
						type: 'error'
					})
					return
				} else {
					// 请求接口
					saveOverSpeed(imei, overSpeed, overSecond).then(res => {
						if (res.code === 0) {
							this.$emit('refresh')
							this.secondAddForm.maxSpeed = ''
							this.secondAddForm.duration = ''
						}
						// 根据 code 的值给出提示信息
						promptMessage.call(this,res.code)
					}).catch(err => {
						this.$message({
							message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
							center: true,
							type: 'error'
						});
					})
				}
			},
			// 保存里程
			saveMile() {
				var imei = this.VehicleAddForm.imei
				var mileageThreshold = this.secondAddForm.mileageThreshold
				var odometer = this.secondAddForm.odometer
				var aCCOnDurtionThreshold = this.secondAddForm.aCCOnDurtionThreshold
				var currentAccOnDuration = this.secondAddForm.currentAccOnDuration
				if (this.radioValue === 1) {
					if(window.showUnit == 'mi'){
						mileageThreshold = (parseFloat(mileageThreshold) * 1.609344).toFixed(4)
						odometer = (parseFloat($('#odometer').val()) * 1.609344).toFixed(4)
					}else if(window.showUnit == 'knot'){
						mileageThreshold = (parseFloat(mileageThreshold) * 1.852).toFixed(4)
						odometer =	(parseFloat($('#odometer').val()) * 1.852).toFixed(4)
					}
					if((mileageThreshold&&!odometer)||(!mileageThreshold&&odometer)){
						this.$message({
							message: this.Local ? this.Local.prop('header.Mileage') : 'Mileage threshold or Current mileage not empty',
							center: true,
							type: 'error'
						})
						return
					}
					//里程阀值不能低于1000km
					if(parseInt(mileageThreshold)<1000){
							this.$message({
								message: this.Local ? this.Local.prop('Alert.MilageAlarmIntervalMsg') : 'Mileage threshold can not less than thsound',
								center: true,
								type: 'error'
							})
							return
					}
					if (imei === '' || imei === null) {
						this.$message({
							message: this.Local ? this.Local.prop('Fleet.Vehicle.imei') : 'imei can not empty',
							center: true,
							type: 'error'
						})
						return
					} else {
						// 请求接口
						saveMileThreshold(imei, mileageThreshold, odometer).then(res => {
							if (res.code === 0) {
								this.$emit('refresh')
								this.secondAddForm.threshold = ''
								this.secondAddForm.currentMileage = ''
							}
							// 根据 code 的值给出提示信息
							promptMessage.call(this,res.code)
						}).catch(err => {
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							})
						})
					}
				} else {
					if((aCCOnDurtionThreshold&&!currentAccOnDuration)||(!aCCOnDurtionThreshold&&currentAccOnDuration)){
						this.$message({
							message: this.Local ? this.Local.prop('header.ACCOnDuration') : 'ACC-ON threshold or Current Duration not empty',
							center: true,
							type: 'error'
						})
						return
					}
					// 持续时间阈值不能小于50小时
					if(parseInt(aCCOnDurtionThreshold)<49){
							this.$message({
								message: this.Local ? this.Local.prop('header.ACCONDurationThreshold') : 'ACC-ON threshold can not less than fifty',
								center: true,
								type: 'error'
							})
							return
					}
					if (imei === '' || imei === null) {
						this.$message({
							message: this.Local ? this.Local.prop('Fleet.Vehicle.imei') : 'imei can not empty',
							center: true,
							type: 'error'
						})
						return
					} else {
						saveAccOnDuration(imei, aCCOnDurtionThreshold, currentAccOnDuration).then(res => {
							if (res.code === 0) {
								this.$emit('refresh')
								this.secondAddForm.accThreshold = ''
								this.secondAddForm.currentDuration = ''
							}
							// 根据 code 的值给出提示信息
							promptMessage.call(this,res.code)
						}).catch(err => {
							this.$message({
								message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
								center: true,
								type: 'error'
							})
						})
					}
				}
			}
		},
		watch: {
			// 监听传入参数 form 的变化 
			form: function (newForm, oldForm) {
				if (!newForm.id) {
					this.reset()
					return 
				}
				this.VehicleAddForm = newForm
				console.log(this.VehicleAddForm)
				this.secondAddForm.overSpeed = newForm.overSpeed
				this.secondAddForm.overSecond = newForm.overSecond
			},
			'VehicleAddForm.imei': {
        handler: function (val,oldVal) {
					if (val == null || val == '') {
							this.deviceData = []
						} else {
							this.$nextTick(() => {	
								this.deviceQuery()
							})
						}
					},
				deep:true
			},
			'VehicleAddForm.driverNo': {
        handler: function (val,oldVal) {
					if (val == null || val == '') {
							this.driveNumberData = []
						} else {
							this.$nextTick(() => {	
								this.driveNumberQuery()
							})
						}
					},
				deep:true
      }
		},
	}
</script>

<style lang='less'>
	.vehicleDialog {
		.el-dialog {
			min-width: 900px;
			.el-dialog__header {
				background: #2d2f3e;
				padding: 20px;
			}
			.el-dialog__title {
				color: #fff;
				font-weight: 300;
			}
			.el-dialog__body {
				padding: 6px 10px;
				.el-tabs__header {
					padding: 0 30px;
				}
				.el-tabs__content {
					padding: 10px 20px 10px 20px;
				}
			}
			.el-form-item__label {
				text-align: left;
				color: #3f4047;
				white-space: nowrap;
			}
			.dialog-form .right .el-form-item__label {
				padding-left: 30px;
			}
			.dialog-form .el-date-editor.el-input, .dialog-form .el-date-editor.el-input__inner {
				width: auto;
			}
			.avatar-uploader .el-upload {
				border: 1px solid #dcdfe6;
				border-radius: 6px;
				cursor: pointer;
				position: relative;
				overflow: hidden;
			}
			.el-form-item {
				word-break: keep-all;
			}
			.el-form-item.is-required .el-form-item__label:before {
				display: none;
			}
			.tips {
				margin-top: 10px;
				margin-bottom: 20px;
				font-size: 12px;
				line-height: 20px;
				color: #c0c4cc;
				height: 40px;
			}
			.speed-unit {
				position: absolute;
				top: 0;
				right: -34px;
				font-size: 12px;
				color: #c0c4cc;
			}
			.avatar-uploader-icon {
				font-size: 24px;
				color: #dcdfe6;
				width: 160px;
				height: 160px;
				line-height: 160px;
				text-align: center;
			}
			.avatar {
				width: 160px;
				height: 160px;
				display: block;
			}
			.upload-btn {
				button {
					border: 0;
					padding: 6px;
				}
				.el-button+.el-button {
					margin-left: 2px;
				}
			}
			.upload-loading {
				position: absolute;
				display: table;
				top: 0;
				left: 0;
				width: 100%;
				height: 100%;
				height: 160px;
				background: #fff;
				.loading {
					display: table-cell;
					vertical-align: middle;
					color: #c0c4cc;
					font-size: 16px;
					p {
						line-height: 10px;
						font-size: 14px;
					}
				}
			}
			.deviceDataPopover {
				.el-table td, .el-table th {
					padding: 8px 0
				}
			}
			.el-form-item__error {
				width: 280px;
			}
			.secondTitle {
				line-height: 30px;
				border-bottom: 1px solid #f3f3f3;
				margin-bottom: 20px;
			}
			.radioList {
				margin-bottom: 10px;
				.el-radio-group {
					margin-left: 20px;
				}
			}
			.mb10 {
				margin-bottom:10px;
			}
		}
	}
</style> 