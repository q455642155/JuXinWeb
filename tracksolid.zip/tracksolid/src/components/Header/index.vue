<template>
  <div class="Header">
    <div class="header-wrapper">
      <div class="logo-wrapper">
        <router-link class="logo" tag="a" to="/">
          <img :src="logo">
          <span class="logo-txt">
            <i class="logo-split">|</i>Fleet
          </span>
        </router-link>
      </div>
      <div class="info-wrapper">
        <div class="info">
          <!-- <router-link class="notification" tag="a" to="/notification">
            <span v-show=" count > 0 " class="animated flash">{{ count }}</span>
            <i
              class="icon-notification animated"
              :class="{ swing: count > 0 }"
              @click="isNotification()"
            ></i>
          </router-link> -->
          <div class="notification">
            <span v-show=" count > 0 " class="animated flash">{{ count }}</span>
            <i
              class="icon-notification animated"
              :class="{ swing: count > 0 }" v-popover:notice
            ></i>
          </div>
          <el-popover ref="notice" placement="bottom-end" trigger="hover" popper-class="notice-popover" @show="getPopoverInfo">
            <h4 class="noticeTitle">{{this.Local ? this.Local.prop('System.Notifications') : 'Notifications'}}</h4>
            <div class="noticeList">
              <ul>
                <li v-for="(item, index) in filteredItems" :key="index" @click="isNotification()">
                  <div class="icon">
                    <span><i class="fa fa-id-card-o"></i></span>
                  </div>
                  <div class="information">
                    <p class="title">{{item.reminderName}}</p>
                    <p class="con">{{item.content}}</p>
                    <p class="date">{{item.notificationTime}}</p>
                  </div>
                </li>
              </ul>
            </div>
          </el-popover>
          <el-popover placement="bottom-end" trigger="hover" popper-class="user-info-popover">
            <div class="main">
              <div class="user-info-link">
                <i class="icon-user"></i>
                <span>{{ userName }}</span>
              </div>
              <div class="user-info-link logout" @click="logout()">
                <i class="icon-logout"></i>
                <span>{{ this.Local ? this.Local.prop('System.ExitSystem') : 'Logout' }}</span>
              </div>
            </div>
            <a class="user" slot="reference">
              <!-- <img src="@/common/images/user.png" /> -->
              <div class="user-box">
                <i class="icon-user"/>
              </div>
            </a>
          </el-popover>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { mapActions, mapGetters, mapMutations } from "vuex"
import { getNotificationCount, getNotificationList } from "@/api/Notification"
import { promptMessage } from "@/common/js/common"

export default {
  data() {
    return {
      logo: window.parent.logo,
      userName: window.localStorage.getItem('username'),
      noticeList: []
    }
  },
  name: "Header",
  created() {
    // 获取告警通知数量
    this.getNotificationCount()
    // 每3秒一次实时请求-获取告警通知数量
    setInterval(() => {
      this.getNotificationCount()
    }, 60000)
  },
  computed: {
    ...mapGetters(["count"]),
    filteredItems: function () {
      return this.noticeList.slice(0, 5)
    }
  },
  methods: {
    // 获取告警通知数量
    getNotificationCount() {
      let getCount = getNotificationCount().then(res => {
        if (res.code === 0) {
          this.SET_COUNT(res.data.count);
        }
      });
    },
    // 是否是在通知页面
    isNotification() {
      this.$router.push({
        path: '/notification'
      })
      this.$nextTick(() => {
        this.$emit("isNotification");
      });
    },
    ...mapMutations(["SET_COUNT"]),
    ...mapActions(["logout"]),
    // 获取通知列表
    getNoticeList(){
      let startDate = null
      let endDate = null
      let source = null
      let pageSize = 10
      let pageNum = 1
      getNotificationList(startDate,endDate,source,pageSize,pageNum).then((res)=>{
          if(res.code === 0) {
              console.log(res.data.list)
              this.noticeList = res.data.list
              this.loading = false
              return
          }
          // 根据 code 的值给出提示信息
          promptMessage.call(this,res.code)
      }).catch((e)=>{
          this.$message({
              message: this.Local ? this.Local.prop('Commands.Unknown_error') : 'Unknown error',
              center: true,
              type: 'error'
          });
      })
    },
    // 鼠标放在铃铛上获取通知的内容
    getPopoverInfo(){
      this.getNoticeList()
    }
    // 点击通知列表路由跳转
    // goToPath() {
    //   this.$router.push({
    //     path: '/notification'
    //   })
    // }
  }
};
</script>

<style lang='less'>
.Header {
  position: fixed;
  width: 100%;
  height: 80px;
  background: #fff;
  box-shadow: 0 1px 15px 1px rgba(69, 65, 78, 0.1);
  z-index: 1000;
  .header-wrapper {
    display: table;
    width: 100%;
    height: 80px;
    .logo-wrapper {
      display: table-cell;
      width: 90px;
      height: 80px;
      padding: 0 30px;
      vertical-align: middle;
      text-align: center;
      box-sizing: border-box;
      .logo {
        display: flex;
        img {
          height: 30px;
        }
        .logo-txt {
          display: inline-block;
          font-size: 24px;
          line-height: 34px;
          color: #4dabf5;
          .logo-split {
            font-size: 30px;
            font-weight: 100;
            line-height: 30px;
            color: #a0a0a0;
            font-style: normal;
            padding: 0 6px 0 4px;
          }
        }
      }
    }
    .info-wrapper {
      display: table-cell;
      width: 100%;
      height: 80px;
      .info {
        display: table;
        float: right;
        height: 80px;
        padding: 0 30px;
        .notification {
          position: relative;
          display: table-cell;
          height: 80px;
          padding: 0 12px;
          vertical-align: middle;
          text-align: center;
          span {
            position: absolute;
            left: 50%;
            top: 10px;
            color: #fff;
            font-size: 10px;
            display: inline-block;
            vertical-align: middle;
            min-width: 10px;
            height: 10px;
            text-align: center;
            padding: 4px;
            border-radius: 50px;
            background-color: #00adff;
            z-index: 100;
          }
          i {
            display: block;
            color: #98a4c4;
          }
        }
        .user {
          position: relative;
          display: table-cell;
          height: 80px;
          vertical-align: middle;
          text-align: center;
          padding: 0 12px;
          cursor: pointer;
          img {
            width: 40px;
            height: 40px;
            border-radius: 20px;
          }
          div {
            background: #eee;
            width: 40px;
            height: 40px;
            border-radius: 20px;
            .icon-user {
              color: #00adff;
              margin-top: 8px;
              display: inline-block;
            }
          }
        }
        
      }
    }
  }
}
.el-popover {
  min-width: 100px !important;
}
.user-info-popover {
  /*.user-name {
			padding: 10px 0;
			span {
				font-weight: 600;
			}
		}*/
  .user-info-link {
    padding: 10px 0;
    border-bottom: 1px solid #f4f4f4;
    i {
      margin-right: 8px;
      font-size: 18px;
      color: #98a4c4;
      vertical-align: middle;
    }
    span {
      color: #606266;
    }
  }
  .logout {
    cursor: pointer;
    border-bottom: 0;
  }
  .user-info-link:hover {
    i,
    span {
      color: #409eff;
    }
  }
}
.notice-popover {
  width: 260px;
  min-height: 300px;
  padding: 0;
  .noticeTitle {
    line-height: 30px;
    text-align: center;
    font-weight: bold;
    border-bottom: 1px solid #f3f3f3;
  }
  .noticeList {
    padding: 4px;
    ul li {
      display: flex;
      background: #EBF5FF;
      border: 1px solid #D6EBFF;
      border-radius: 2px;
      justify-content: center;
      align-items: center;
      margin-bottom: 6px;
      cursor: pointer;
      &:last-child{
        margin-bottom: 0;
      }
      .icon {
        width: 60px;
        span {
          display: flex;
          margin: 0 auto;
          width: 40px;
          height: 40px;
          background: #fff;
          border-radius: 50%;
          justify-content: center;
          align-items: center;
          i {
            color: #52C1F5;
          }
        }
      }
      .information {
        flex: 1;
        padding: 0 4px;
        overflow: hidden;
        .title {
          font-weight: 600;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .con {
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
        .date {
          color:#CCCCD6;
        }
      }
    }
  }
}
</style> 