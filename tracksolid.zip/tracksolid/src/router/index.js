/*!
 * vue-router 相关配置 路由懒加载 + token 拦截机制
 */

import Vue from 'vue'
import Router from 'vue-router'

import store from '@/store/index.js'
import Rfid from '@/pages/Driver/Rfid'
// eslint-disable-next-line no-unused-vars
import * as types from '@/store/mutation-types'

// 使用 Router
Vue.use(Router)

// 按需加载 （异步加载）
// const Dashboard = resolve => require(['@/pages/Dashboard'], resolve)
const Driver = resolve => require(['@/pages/Driver'], resolve)
const Vehicle = resolve => require(['@/pages/Vehicle'], resolve)
const Notification = resolve => require(['@/pages/Notification'], resolve)
const DrivingHistory = resolve => require(['@/pages/DrivingHistory'], resolve)
const NotFound = resolve => require(['@/pages/NotFound'], resolve)
const Dashboard = resolve => require(['@/pages/Dashboard'], resolve)

// 生成路由
const router = new Router({
  // mode: 'history',
  routes: [
    {
      path: '/',
      name: 'home',
      redirect: './dashboard'
    },
    {
      path: '/dashboard',
      name: 'dashboard',
      component: Dashboard,
      meta: {
        requireToken: true
      }
    },
    {
      path: '/driver',
      name: 'driver',
      component: Driver,
      meta: {
        requireToken: true
      }
    },
    {
      path: '/rfid',
      name: 'rfid',
      component: Rfid,
      meta: {
        requireToken: true
      }
    },
    {
      path: '/vehicle',
      name: 'vehicle',
      component: Vehicle,
      meta: {
        requireToken: true
      }
    },
    {
      path: '/console',
      name: 'console'
    },
    {
      path: '/drivingHistory',
      name: 'drivingHistory',
      component: DrivingHistory,
        meta: {
        requireToken: true
      }
    },
    {
      path: '/notification',
      name: 'notification',
      component: Notification,
      meta: {
        requireToken: true
      }
    },
    {
      path: '*',
      name: 'notfound',
      component: NotFound
    }
  ]
})

// 路由跳转之前验证跳转页面是否需要token
router.beforeEach((to, from, next) => {
  next()
  // 进入此页面需要 token
  if (to.matched.some(r => r.meta.requireToken)) {
    // store中存在 token 则允许进入此页面
    if (store.state.token && store.state.token !== '') {
      next()
    // eslint-disable-next-line brace-style
    }
    // store 不存在 token 则不允许进入改页面，并进行相关操作
    else {
      store.dispatch('logout')
    }
  // eslint-disable-next-line brace-style
  }
  // 进入此页面需要不需要 token 则直接进入此页面
  else {
    next()
  }
})

export default router
