<template>
  <div id="App">
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: "App"
};
</script>

<style lang='less'>
#App {
  position: relative;
  width: 100%;
  height: 100%;
}
</style>