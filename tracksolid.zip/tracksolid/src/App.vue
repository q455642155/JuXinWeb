<template>
  <div id="App">
    <!-- <keep-alive>
      <router-view></router-view>
    </keep-alive> -->
    <router-view></router-view>
  </div>
</template>

<script type="text/ecmascript-6">
import { getAccount } from '@/common/js/common'
export default {
  name: "App",
  created () {
    getAccount()
  }
};
</script>

<style lang='less'>
#App {
  position: relative;
  width: 100%;
  height: 100%;
}
</style>