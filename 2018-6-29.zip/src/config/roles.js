const roles = {
  0: {
    name: '管理员',
    layout: '/admin' // 对应的模板
  },
  2: {
    name: '供应商',
    layout: '/main'
  },
  3: {
    name: '保理商',
    layout: '/fund'
  },
  4: {
    name: '获客方',
    layout: '/main'
  }
}
export default roles
