export default {
  data () {
    return {
      // 宽度控制
      widthArr: {
        masterChainId: '150',
        billId: '150',
        companyName: '150',
        custFromName: '150',
        billBookAmt: '',
        currencyDesc: '',
        repaymentType: '',
        fineGraceDays: '',
        payPrincipalAmt: '',
        payServiceAmt: '',
        payFineAmt: '',
        payFineDays: '',
        prepayServiceAmt: '',
        payAmt: '',
        billPayDate: '120',
        loanDate: '120',
        defaultRepayDate: '120',
        billPayStatus: '',
        operate: '200'
      }
    }
  }
}
