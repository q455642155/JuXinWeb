<template>
<article>
    <section>
        <header>myar数据</header>
        <el-card>
            {{tableData5}}
        </el-card>
    </section>
    <section>
        <header>nav数据</header>
        <el-card>
            {{navItems}}
        </el-card>
    </section>
</article>
</template>
<script>
// 数据展示页面
export default {
  mixins: []
}
</script>
