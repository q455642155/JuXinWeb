/* eslint-disable */
const subData=
{"data":{"result":true,"message":"操作成功"},"msg":"返回结果正常","recordsTotal":null,"status":1}
export default subData