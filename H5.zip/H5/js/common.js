// var base = "https://jurongtest.foxconn.com/JuXin";
// var bssetest = "http://10.134.155.141/JuXin";
// var baseip = "https://jurongtest.foxconn.com/JuXinDev";
// var baseimg = "https://jurongtest.foxconn.com";
// var basedev = "https://jurongtest.foxconn.com/JuXinDev";
var globalConfig = {
  iDisplayStart: "1",
  iDisplayLength: "20"
}

var exitPhone // 判断手机号存在不存在而去控制发布发送验证码
//开户省市
var province = {
  options:
    [{
      "text": "北京",
      "value": "北京",
      "children": [{
        "text": "东城区",
        "value": "东城区"
      }, {
        "text": "西城区",
        "value": "西城区"
      }, {
        "text": "崇文区",
        "value": "崇文区"
      }, {
        "text": "宣武区",
        "value": "宣武区"
      }, {
        "text": "朝阳区",
        "value": "朝阳区"
      }, {
        "text": "丰台区",
        "value": "丰台区"
      }, {
        "text": "石景山区",
        "value": "石景山区"
      }, {
        "text": "海淀区",
        "value": "海淀区"
      }, {
        "text": "门头沟区",
        "value": "门头沟区"
      }, {
        "text": "房山区",
        "value": "房山区"
      }, {
        "text": "通州区",
        "value": "通州区"
      }, {
        "text": "顺义区",
        "value": "顺义区"
      }, {
        "text": "昌平区",
        "value": "昌平区"
      }, {
        "text": "大兴区",
        "value": "大兴区"
      }, {
        "text": "平谷区",
        "value": "平谷区"
      }, {
        "text": "怀柔区",
        "value": "怀柔区"
      }, {
        "text": "密云县",
        "value": "密云县"
      }, {
        "text": "延庆县",
        "value": "延庆县"
      }]
    }, {
      "text": "天津",
      "value": "天津",
      "children": [{
        "text": "和平区",
        "value": "和平区"
      }, {
        "text": "河东区",
        "value": "河东区"
      }, {
        "text": "河西区",
        "value": "河西区"
      }, {
        "text": "南开区",
        "value": "南开区"
      }, {
        "text": "河北区",
        "value": "河北区"
      }, {
        "text": "红桥区",
        "value": "红桥区"
      }, {
        "text": "塘沽区",
        "value": "塘沽区"
      }, {
        "text": "汉沽区",
        "value": "汉沽区"
      }, {
        "text": "大港区",
        "value": "大港区"
      }, {
        "text": "东丽区",
        "value": "东丽区"
      }, {
        "text": "西青区",
        "value": "西青区"
      }, {
        "text": "津南区",
        "value": "津南区"
      }, {
        "text": "北辰区",
        "value": "北辰区"
      }, {
        "text": "武清区",
        "value": "武清区"
      }, {
        "text": "宝坻区",
        "value": "宝坻区"
      }, {
        "text": "宁河县",
        "value": "宁河县"
      }, {
        "text": "静海县",
        "value": "静海县"
      }, {
        "text": "蓟 县",
        "value": "蓟 县"
      }]
    }, {
      "text": "河北",
      "value": "河北",
      "children": [{
        "text": "石家庄",
        "value": "石家庄"
      }, {
        "text": "唐山",
        "value": "唐山"
      }, {
        "text": "秦皇岛",
        "value": "秦皇岛"
      }, {
        "text": "邯郸",
        "value": "邯郸"
      }, {
        "text": "邢台",
        "value": "邢台"
      }, {
        "text": "保定",
        "value": "保定"
      }, {
        "text": "张家口",
        "value": "张家口"
      }, {
        "text": "承德",
        "value": "承德"
      }, {
        "text": "沧州",
        "value": "沧州"
      }, {
        "text": "廊坊",
        "value": "廊坊"
      }, {
        "text": "衡水",
        "value": "衡水"
      }]
    }, {
      "text": "山西",
      "value": "山西",
      "children": [{
        "text": "太原",
        "value": "太原"
      }, {
        "text": "大同",
        "value": "大同"
      }, {
        "text": "阳泉",
        "value": "阳泉"
      }, {
        "text": "长治",
        "value": "长治"
      }, {
        "text": "晋城",
        "value": "晋城"
      }, {
        "text": "朔州",
        "value": "朔州"
      }, {
        "text": "忻州",
        "value": "忻州"
      }, {
        "text": "吕梁",
        "value": "吕梁"
      }, {
        "text": "晋中",
        "value": "晋中"
      }, {
        "text": "临汾",
        "value": "临汾"
      }, {
        "text": "运城",
        "value": "运城"
      }]
    }, {
      "text": "内蒙古",
      "value": "内蒙古",
      "children": [{
        "text": "呼和浩特",
        "value": "呼和浩特"
      }, {
        "text": "包头",
        "value": "包头"
      }, {
        "text": "乌海",
        "value": "乌海"
      }, {
        "text": "赤峰",
        "value": "赤峰"
      }, {
        "text": "呼伦贝尔",
        "value": "呼伦贝尔"
      }, {
        "text": "兴安盟",
        "value": "兴安盟"
      }, {
        "text": "通辽",
        "value": "通辽"
      }, {
        "text": "锡林郭勒盟",
        "value": "锡林郭勒盟"
      }, {
        "text": "乌兰察布盟",
        "value": "乌兰察布盟"
      }, {
        "text": "伊克昭盟",
        "value": "伊克昭盟"
      }, {
        "text": "巴彦淖尔盟",
        "value": "巴彦淖尔盟"
      }, {
        "text": "阿拉善盟",
        "value": "阿拉善盟"
      }]
    }, {
      "text": "辽宁",
      "value": "辽宁",
      "children": [{
        "text": "沈阳",
        "value": "沈阳"
      }, {
        "text": "大连",
        "value": "大连"
      }, {
        "text": "鞍山",
        "value": "鞍山"
      }, {
        "text": "抚顺",
        "value": "抚顺"
      }, {
        "text": "本溪",
        "value": "本溪"
      }, {
        "text": "丹东",
        "value": "丹东"
      }, {
        "text": "锦州",
        "value": "锦州"
      }, {
        "text": "营口",
        "value": "营口"
      }, {
        "text": "阜新",
        "value": "阜新"
      }, {
        "text": "辽阳",
        "value": "辽阳"
      }, {
        "text": "盘锦",
        "value": "盘锦"
      }, {
        "text": "铁岭",
        "value": "铁岭"
      }, {
        "text": "朝阳",
        "value": "朝阳"
      }, {
        "text": "葫芦岛",
        "value": "葫芦岛"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "吉林",
      "value": "吉林",
      "children": [{
        "text": "长春",
        "value": "长春"
      }, {
        "text": "吉林",
        "value": "吉林"
      }, {
        "text": "四平",
        "value": "四平"
      }, {
        "text": "辽源",
        "value": "辽源"
      }, {
        "text": "通化",
        "value": "通化"
      }, {
        "text": "白山",
        "value": "白山"
      }, {
        "text": "松原",
        "value": "松原"
      }, {
        "text": "白城",
        "value": "白城"
      }, {
        "text": "延边朝鲜族自治州",
        "value": "延边朝鲜族自治州"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "黑龙江",
      "value": "黑龙江",
      "children": [{
        "text": "哈尔滨",
        "value": "哈尔滨"
      }, {
        "text": "齐齐哈尔",
        "value": "齐齐哈尔"
      }, {
        "text": "鹤岗",
        "value": "鹤岗"
      }, {
        "text": "双鸭山",
        "value": "双鸭山"
      }, {
        "text": "鸡西",
        "value": "鸡西"
      }, {
        "text": "大庆",
        "value": "大庆"
      }, {
        "text": "伊春",
        "value": "伊春"
      }, {
        "text": "牡丹江",
        "value": "牡丹江"
      }, {
        "text": "佳木斯",
        "value": "佳木斯"
      }, {
        "text": "七台河",
        "value": "七台河"
      }, {
        "text": "黑河",
        "value": "黑河"
      }, {
        "text": "绥化",
        "value": "绥化"
      }, {
        "text": "大兴安岭地区",
        "value": "大兴安岭地区"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "上海",
      "value": "上海",
      "children": [{
        "text": "黄浦区",
        "value": "黄浦区"
      }, {
        "text": "卢湾区",
        "value": "卢湾区"
      }, {
        "text": "徐汇区",
        "value": "徐汇区"
      }, {
        "text": "长宁区",
        "value": "长宁区"
      }, {
        "text": "静安区",
        "value": "静安区"
      }, {
        "text": "普陀区",
        "value": "普陀区"
      }, {
        "text": "闸北区",
        "value": "闸北区"
      }, {
        "text": "虹口区",
        "value": "虹口区"
      }, {
        "text": "杨浦区",
        "value": "杨浦区"
      }, {
        "text": "宝山区",
        "value": "宝山区"
      }, {
        "text": "闵行区",
        "value": "闵行区"
      }, {
        "text": "嘉定区",
        "value": "嘉定区"
      }, {
        "text": "松江区",
        "value": "松江区"
      }, {
        "text": "金山区",
        "value": "金山区"
      }, {
        "text": "青浦区",
        "value": "青浦区"
      }, {
        "text": "南汇区",
        "value": "南汇区"
      }, {
        "text": "奉贤区",
        "value": "奉贤区"
      }, {
        "text": "浦东新区",
        "value": "浦东新区"
      }, {
        "text": "崇明县",
        "value": "崇明县"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "江苏",
      "value": "江苏",
      "children": [{
        "text": "南京",
        "value": "南京"
      }, {
        "text": "苏州",
        "value": "苏州"
      }, {
        "text": "无锡",
        "value": "无锡"
      }, {
        "text": "常州",
        "value": "常州"
      }, {
        "text": "镇江",
        "value": "镇江"
      }, {
        "text": "南通",
        "value": "南通"
      }, {
        "text": "泰州",
        "value": "泰州"
      }, {
        "text": "扬州",
        "value": "扬州"
      }, {
        "text": "盐城",
        "value": "盐城"
      }, {
        "text": "连云港",
        "value": "连云港"
      }, {
        "text": "徐州",
        "value": "徐州"
      }, {
        "text": "淮安",
        "value": "淮安"
      }, {
        "text": "宿迁",
        "value": "宿迁"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "浙江",
      "value": "浙江",
      "children": [{
        "text": "杭州",
        "value": "杭州"
      }, {
        "text": "宁波",
        "value": "宁波"
      }, {
        "text": "温州",
        "value": "温州"
      }, {
        "text": "嘉兴",
        "value": "嘉兴"
      }, {
        "text": "湖州",
        "value": "湖州"
      }, {
        "text": "绍兴",
        "value": "绍兴"
      }, {
        "text": "金华",
        "value": "金华"
      }, {
        "text": "衢州",
        "value": "衢州"
      }, {
        "text": "舟山",
        "value": "舟山"
      }, {
        "text": "台州",
        "value": "台州"
      }, {
        "text": "丽水",
        "value": "丽水"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "安徽",
      "value": "安徽",
      "children": [{
        "text": "合肥",
        "value": "合肥"
      }, {
        "text": "芜湖",
        "value": "芜湖"
      }, {
        "text": "蚌埠",
        "value": "蚌埠"
      }, {
        "text": "淮南",
        "value": "淮南"
      }, {
        "text": "马鞍山",
        "value": "马鞍山"
      }, {
        "text": "淮北",
        "value": "淮北"
      }, {
        "text": "铜陵",
        "value": "铜陵"
      }, {
        "text": "安庆",
        "value": "安庆"
      }, {
        "text": "黄山",
        "value": "黄山"
      }, {
        "text": "滁州",
        "value": "滁州"
      }, {
        "text": "阜阳",
        "value": "阜阳"
      }, {
        "text": "宿州",
        "value": "宿州"
      }, {
        "text": "巢湖",
        "value": "巢湖"
      }, {
        "text": "六安",
        "value": "六安"
      }, {
        "text": "亳州",
        "value": "亳州"
      }, {
        "text": "池州",
        "value": "池州"
      }, {
        "text": "宣城",
        "value": "宣城"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "福建",
      "value": "福建",
      "children": [{
        "text": "福州",
        "value": "福州"
      }, {
        "text": "厦门",
        "value": "厦门"
      }, {
        "text": "莆田",
        "value": "莆田"
      }, {
        "text": "三明",
        "value": "三明"
      }, {
        "text": "泉州",
        "value": "泉州"
      }, {
        "text": "漳州",
        "value": "漳州"
      }, {
        "text": "南平",
        "value": "南平"
      }, {
        "text": "龙岩",
        "value": "龙岩"
      }, {
        "text": "宁德",
        "value": "宁德"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "江西",
      "value": "江西",
      "children": [{
        "text": "南昌",
        "value": "南昌"
      }, {
        "text": "景德镇",
        "value": "景德镇"
      }, {
        "text": "萍乡",
        "value": "萍乡"
      }, {
        "text": "九江",
        "value": "九江"
      }, {
        "text": "新余",
        "value": "新余"
      }, {
        "text": "鹰潭",
        "value": "鹰潭"
      }, {
        "text": "赣州",
        "value": "赣州"
      }, {
        "text": "吉安",
        "value": "吉安"
      }, {
        "text": "宜春",
        "value": "宜春"
      }, {
        "text": "抚州",
        "value": "抚州"
      }, {
        "text": "上饶",
        "value": "上饶"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "山东",
      "value": "山东",
      "children": [{
        "text": "济南",
        "value": "济南"
      }, {
        "text": "青岛",
        "value": "青岛"
      }, {
        "text": "淄博",
        "value": "淄博"
      }, {
        "text": "枣庄",
        "value": "枣庄"
      }, {
        "text": "东营",
        "value": "东营"
      }, {
        "text": "烟台",
        "value": "烟台"
      }, {
        "text": "潍坊",
        "value": "潍坊"
      }, {
        "text": "济宁",
        "value": "济宁"
      }, {
        "text": "泰安",
        "value": "泰安"
      }, {
        "text": "威海",
        "value": "威海"
      }, {
        "text": "日照",
        "value": "日照"
      }, {
        "text": "莱芜",
        "value": "莱芜"
      }, {
        "text": "临沂",
        "value": "临沂"
      }, {
        "text": "德州",
        "value": "德州"
      }, {
        "text": "聊城",
        "value": "聊城"
      }, {
        "text": "滨州",
        "value": "滨州"
      }, {
        "text": "菏泽",
        "value": "菏泽"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "河南",
      "value": "河南",
      "children": [{
        "text": "郑州",
        "value": "郑州"
      }, {
        "text": "开封",
        "value": "开封"
      }, {
        "text": "洛阳",
        "value": "洛阳"
      }, {
        "text": "平顶山",
        "value": "平顶山"
      }, {
        "text": "安阳",
        "value": "安阳"
      }, {
        "text": "鹤壁",
        "value": "鹤壁"
      }, {
        "text": "新乡",
        "value": "新乡"
      }, {
        "text": "焦作",
        "value": "焦作"
      }, {
        "text": "濮阳",
        "value": "濮阳"
      }, {
        "text": "许昌",
        "value": "许昌"
      }, {
        "text": "漯河",
        "value": "漯河"
      }, {
        "text": "三门峡",
        "value": "三门峡"
      }, {
        "text": "南阳",
        "value": "南阳"
      }, {
        "text": "商丘",
        "value": "商丘"
      }, {
        "text": "信阳",
        "value": "信阳"
      }, {
        "text": "周口",
        "value": "周口"
      }, {
        "text": "驻马店",
        "value": "驻马店"
      }, {
        "text": "焦作",
        "value": "焦作"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "湖北",
      "value": "湖北",
      "children": [{
        "text": "武汉",
        "value": "武汉"
      }, {
        "text": "黄石",
        "value": "黄石"
      }, {
        "text": "十堰",
        "value": "十堰"
      }, {
        "text": "荆州",
        "value": "荆州"
      }, {
        "text": "宜昌",
        "value": "宜昌"
      }, {
        "text": "襄樊",
        "value": "襄樊"
      }, {
        "text": "鄂州",
        "value": "鄂州"
      }, {
        "text": "荆门",
        "value": "荆门"
      }, {
        "text": "孝感",
        "value": "孝感"
      }, {
        "text": "黄冈",
        "value": "黄冈"
      }, {
        "text": "咸宁",
        "value": "咸宁"
      }, {
        "text": "随州",
        "value": "随州"
      }, {
        "text": "恩施土家族苗族自治州",
        "value": "恩施土家族苗族自治州"
      }, {
        "text": "仙桃",
        "value": "仙桃"
      }, {
        "text": "天门",
        "value": "天门"
      }, {
        "text": "潜江",
        "value": "潜江"
      }, {
        "text": "神农架林区",
        "value": "神农架林区"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "湖南",
      "value": "湖南",
      "children": [{
        "text": "长沙",
        "value": "长沙"
      }, {
        "text": "株洲",
        "value": "株洲"
      }, {
        "text": "湘潭",
        "value": "湘潭"
      }, {
        "text": "衡阳",
        "value": "衡阳"
      }, {
        "text": "邵阳",
        "value": "邵阳"
      }, {
        "text": "岳阳",
        "value": "岳阳"
      }, {
        "text": "常德",
        "value": "常德"
      }, {
        "text": "张家界",
        "value": "张家界"
      }, {
        "text": "益阳",
        "value": "益阳"
      }, {
        "text": "郴州",
        "value": "郴州"
      }, {
        "text": "永州",
        "value": "永州"
      }, {
        "text": "怀化",
        "value": "怀化"
      }, {
        "text": "娄底",
        "value": "娄底"
      }, {
        "text": "湘西土家族苗族自治州",
        "value": "湘西土家族苗族自治州"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "广东",
      "value": "广东",
      "children": [{
        "text": "广州",
        "value": "广州"
      }, {
        "text": "深圳",
        "value": "深圳"
      }, {
        "text": "东莞",
        "value": "东莞"
      }, {
        "text": "中山",
        "value": "中山",
        "children": [{
          "value": "中山"
        }]
      }, {
        "text": "潮州",
        "value": "潮州"
      }, {
        "text": "揭阳",
        "value": "揭阳"
      }, {
        "text": "云浮",
        "value": "云浮"
      }, {
        "text": "珠海",
        "value": "珠海"
      }, {
        "text": "汕头",
        "value": "汕头"
      }, {
        "text": "韶关",
        "value": "韶关"
      }, {
        "text": "佛山",
        "value": "佛山"
      }, {
        "text": "江门",
        "value": "江门"
      }, {
        "text": "湛江",
        "value": "湛江"
      }, {
        "text": "茂名",
        "value": "茂名"
      }, {
        "text": "肇庆",
        "value": "肇庆"
      }, {
        "text": "惠州",
        "value": "惠州"
      }, {
        "text": "梅州",
        "value": "梅州"
      }, {
        "text": "汕尾",
        "value": "汕尾"
      }, {
        "text": "河源",
        "value": "河源"
      }, {
        "text": "阳江",
        "value": "阳江"
      }, {
        "text": "清远",
        "value": "清远"
      }]
    }, {
      "text": "广西",
      "value": "广西",
      "children": [{
        "text": "南宁",
        "value": "南宁"
      }, {
        "text": "柳州",
        "value": "柳州"
      }, {
        "text": "桂林",
        "value": "桂林"
      }, {
        "text": "梧州",
        "value": "梧州"
      }, {
        "text": "北海",
        "value": "北海"
      }, {
        "text": "防城港",
        "value": "防城港"
      }, {
        "text": "钦州",
        "value": "钦州"
      }, {
        "text": "贵港",
        "value": "贵港"
      }, {
        "text": "玉林",
        "value": "玉林"
      }, {
        "text": "百色",
        "value": "百色"
      }, {
        "text": "贺州",
        "value": "贺州"
      }, {
        "text": "河池",
        "value": "河池"
      }, {
        "text": "来宾",
        "value": "来宾"
      }, {
        "text": "崇左",
        "value": "崇左"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "海南",
      "value": "海南",
      "children": [{
        "text": "海口",
        "value": "海口"
      }, {
        "text": "三亚",
        "value": "三亚"
      }, {
        "text": "五指山",
        "value": "五指山"
      }, {
        "text": "琼海",
        "value": "琼海"
      }, {
        "text": "儋州",
        "value": "儋州"
      }, {
        "text": "文昌",
        "value": "文昌"
      }, {
        "text": "万宁",
        "value": "万宁"
      }, {
        "text": "东方",
        "value": "东方"
      }, {
        "text": "澄迈县",
        "value": "澄迈县"
      }, {
        "text": "定安县",
        "value": "定安县"
      }, {
        "text": "屯昌县",
        "value": "屯昌县"
      }, {
        "text": "临高县",
        "value": "临高县"
      }, {
        "text": "白沙黎族自治县",
        "value": "白沙黎族自治县"
      }, {
        "text": "昌江黎族自治县",
        "value": "昌江黎族自治县"
      }, {
        "text": "乐东黎族自治县",
        "value": "乐东黎族自治县"
      }, {
        "text": "陵水黎族自治县",
        "value": "陵水黎族自治县"
      }, {
        "text": "保亭黎族苗族自治县",
        "value": "保亭黎族苗族自治县"
      }, {
        "text": "琼中黎族苗族自治县",
        "value": "琼中黎族苗族自治县"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "重庆",
      "value": "重庆",
      "children": [{
        "text": "渝中区",
        "value": "渝中区"
      }, {
        "text": "大渡口区",
        "value": "大渡口区"
      }, {
        "text": "江北区",
        "value": "江北区"
      }, {
        "text": "南岸区",
        "value": "南岸区"
      }, {
        "text": "北碚区",
        "value": "北碚区"
      }, {
        "text": "渝北区",
        "value": "渝北区"
      }, {
        "text": "巴南区",
        "value": "巴南区"
      }, {
        "text": "长寿区",
        "value": "长寿区"
      }, {
        "text": "双桥区",
        "value": "双桥区"
      }, {
        "text": "沙坪坝区",
        "value": "沙坪坝区"
      }, {
        "text": "万盛区",
        "value": "万盛区"
      }, {
        "text": "万州区",
        "value": "万州区"
      }, {
        "text": "涪陵区",
        "value": "涪陵区"
      }, {
        "text": "黔江区",
        "value": "黔江区"
      }, {
        "text": "永川区",
        "value": "永川区"
      }, {
        "text": "合川区",
        "value": "合川区"
      }, {
        "text": "江津区",
        "value": "江津区"
      }, {
        "text": "九龙坡区",
        "value": "九龙坡区"
      }, {
        "text": "南川区",
        "value": "南川区"
      }, {
        "text": "綦江县",
        "value": "綦江县"
      }, {
        "text": "潼南县",
        "value": "潼南县"
      }, {
        "text": "荣昌县",
        "value": "荣昌县"
      }, {
        "text": "璧山县",
        "value": "璧山县"
      }, {
        "text": "大足县",
        "value": "大足县"
      }, {
        "text": "铜梁县",
        "value": "铜梁县"
      }, {
        "text": "梁平县",
        "value": "梁平县"
      }, {
        "text": "开县",
        "value": "开县"
      }, {
        "text": "忠县",
        "value": "忠县"
      }, {
        "text": "城口县",
        "value": "城口县"
      }, {
        "text": "垫江县",
        "value": "垫江县"
      }, {
        "text": "武隆县",
        "value": "武隆县"
      }, {
        "text": "丰都县",
        "value": "丰都县"
      }, {
        "text": "奉节县",
        "value": "奉节县"
      }, {
        "text": "云阳县",
        "value": "云阳县"
      }, {
        "text": "巫溪县",
        "value": "巫溪县"
      }, {
        "text": "巫山县",
        "value": "巫山县"
      }, {
        "text": "石柱土家族自治县",
        "value": "石柱土家族自治县"
      }, {
        "text": "秀山土家族苗族自治县",
        "value": "秀山土家族苗族自治县"
      }, {
        "text": "酉阳土家族苗族自治县",
        "value": "酉阳土家族苗族自治县"
      }, {
        "text": "彭水苗族土家族自治县",
        "value": "彭水苗族土家族自治县"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "四川",
      "value": "四川",
      "children": [{
        "text": "成都",
        "value": "成都"
      }, {
        "text": "自贡",
        "value": "自贡"
      }, {
        "text": "攀枝花",
        "value": "攀枝花"
      }, {
        "text": "泸州",
        "value": "泸州"
      }, {
        "text": "德阳",
        "value": "德阳"
      }, {
        "text": "绵阳",
        "value": "绵阳"
      }, {
        "text": "广元",
        "value": "广元"
      }, {
        "text": "遂宁",
        "value": "遂宁"
      }, {
        "text": "内江",
        "value": "内江"
      }, {
        "text": "乐山",
        "value": "乐山"
      }, {
        "text": "南充",
        "value": "南充"
      }, {
        "text": "眉山",
        "value": "眉山"
      }, {
        "text": "宜宾",
        "value": "宜宾"
      }, {
        "text": "广安",
        "value": "广安"
      }, {
        "text": "达州",
        "value": "达州"
      }, {
        "text": "雅安",
        "value": "雅安"
      }, {
        "text": "巴中",
        "value": "巴中"
      }, {
        "text": "资阳",
        "value": "资阳"
      }, {
        "text": "阿坝藏族羌族自治州",
        "value": "阿坝藏族羌族自治州"
      }, {
        "text": "甘孜藏族自治州",
        "value": "甘孜藏族自治州"
      }, {
        "text": "凉山彝族自治州",
        "value": "凉山彝族自治州"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "贵州",
      "value": "贵州",
      "children": [{
        "text": "贵阳",
        "value": "贵阳"
      }, {
        "text": "六盘水",
        "value": "六盘水"
      }, {
        "text": "遵义",
        "value": "遵义"
      }, {
        "text": "安顺",
        "value": "安顺"
      }, {
        "text": "铜仁地区",
        "value": "铜仁地区"
      }, {
        "text": "毕节地区",
        "value": "毕节地区"
      }, {
        "text": "黔西南布依族苗族自治州",
        "value": "黔西南布依族苗族自治州"
      }, {
        "text": "黔东南苗族侗族自治州",
        "value": "黔东南苗族侗族自治州"
      }, {
        "text": "黔南布依族苗族自治州",
        "value": "黔南布依族苗族自治州"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "云南",
      "value": "云南",
      "children": [{
        "text": "昆明",
        "value": "昆明"
      }, {
        "text": "曲靖",
        "value": "曲靖"
      }, {
        "text": "玉溪",
        "value": "玉溪"
      }, {
        "text": "保山",
        "value": "保山"
      }, {
        "text": "昭通",
        "value": "昭通"
      }, {
        "text": "丽江",
        "value": "丽江"
      }, {
        "text": "普洱",
        "value": "普洱"
      }, {
        "text": "临沧",
        "value": "临沧"
      }, {
        "text": "德宏傣族景颇族自治州",
        "value": "德宏傣族景颇族自治州"
      }, {
        "text": "怒江傈僳族自治州",
        "value": "怒江傈僳族自治州"
      }, {
        "text": "迪庆藏族自治州",
        "value": "迪庆藏族自治州"
      }, {
        "text": "大理白族自治州",
        "value": "大理白族自治州"
      }, {
        "text": "楚雄彝族自治州",
        "value": "楚雄彝族自治州"
      }, {
        "text": "红河哈尼族彝族自治州",
        "value": "红河哈尼族彝族自治州"
      }, {
        "text": "文山壮族苗族自治州",
        "value": "文山壮族苗族自治州"
      }, {
        "text": "西双版纳傣族自治州",
        "value": "西双版纳傣族自治州"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "西藏",
      "value": "西藏",
      "children": [{
        "text": "拉萨",
        "value": "拉萨"
      }, {
        "text": "那曲地区",
        "value": "那曲地区"
      }, {
        "text": "昌都地区",
        "value": "昌都地区"
      }, {
        "text": "林芝地区",
        "value": "林芝地区"
      }, {
        "text": "山南地区",
        "value": "山南地区"
      }, {
        "text": "日喀则地区",
        "value": "日喀则地区"
      }, {
        "text": "阿里地区",
        "value": "阿里地区"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "陕西",
      "value": "陕西",
      "children": [{
        "text": "西安",
        "value": "西安"
      }, {
        "text": "铜川",
        "value": "铜川"
      }, {
        "text": "宝鸡",
        "value": "宝鸡"
      }, {
        "text": "咸阳",
        "value": "咸阳"
      }, {
        "text": "渭南",
        "value": "渭南"
      }, {
        "text": "延安",
        "value": "延安"
      }, {
        "text": "汉中",
        "value": "汉中"
      }, {
        "text": "榆林",
        "value": "榆林"
      }, {
        "text": "安康",
        "value": "安康"
      }, {
        "text": "商洛",
        "value": "商洛"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "甘肃",
      "value": "甘肃",
      "children": [{
        "text": "兰州",
        "value": "兰州"
      }, {
        "text": "嘉峪关",
        "value": "嘉峪关"
      }, {
        "text": "金昌",
        "value": "金昌"
      }, {
        "text": "白银",
        "value": "白银"
      }, {
        "text": "天水",
        "value": "天水"
      }, {
        "text": "武威",
        "value": "武威"
      }, {
        "text": "酒泉",
        "value": "酒泉"
      }, {
        "text": "张掖",
        "value": "张掖"
      }, {
        "text": "庆阳",
        "value": "庆阳"
      }, {
        "text": "平凉",
        "value": "平凉"
      }, {
        "text": "定西",
        "value": "定西"
      }, {
        "text": "陇南",
        "value": "陇南"
      }, {
        "text": "临夏回族自治州",
        "value": "临夏回族自治州"
      }, {
        "text": "甘南藏族自治州",
        "value": "甘南藏族自治州"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "青海",
      "value": "青海",
      "children": [{
        "text": "西宁",
        "value": "西宁"
      }, {
        "text": "海东地区",
        "value": "海东地区"
      }, {
        "text": "海北藏族自治州",
        "value": "海北藏族自治州"
      }, {
        "text": "海南藏族自治州",
        "value": "海南藏族自治州"
      }, {
        "text": "黄南藏族自治州",
        "value": "黄南藏族自治州"
      }, {
        "text": "果洛藏族自治州",
        "value": "果洛藏族自治州"
      }, {
        "text": "玉树藏族自治州",
        "value": "玉树藏族自治州"
      }, {
        "text": "海西蒙古族藏族自治州",
        "value": "海西蒙古族藏族自治州"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "宁夏",
      "value": "宁夏",
      "children": [{
        "text": "银川",
        "value": "银川"
      }, {
        "text": "石嘴山",
        "value": "石嘴山"
      }, {
        "text": "吴忠",
        "value": "吴忠"
      }, {
        "text": "固原",
        "value": "固原"
      }, {
        "text": "中卫",
        "value": "中卫"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "新疆",
      "value": "新疆",
      "children": [{
        "text": "乌鲁木齐",
        "value": "乌鲁木齐"
      }, {
        "text": "克拉玛依",
        "value": "克拉玛依"
      }, {
        "text": "吐鲁番地区",
        "value": "吐鲁番地区"
      }, {
        "text": "哈密地区",
        "value": "哈密地区"
      }, {
        "text": "和田地区",
        "value": "和田地区"
      }, {
        "text": "阿克苏地区",
        "value": "阿克苏地区"
      }, {
        "text": "喀什地区",
        "value": "喀什地区"
      }, {
        "text": "克孜勒苏柯尔克孜自治州",
        "value": "克孜勒苏柯尔克孜自治州"
      }, {
        "text": "巴音郭楞蒙古自治州",
        "value": "巴音郭楞蒙古自治州"
      }, {
        "text": "昌吉回族自治州",
        "value": "昌吉回族自治州"
      }, {
        "text": "博尔塔拉蒙古自治州",
        "value": "博尔塔拉蒙古自治州"
      }, {
        "text": "石河子",
        "value": "石河子"
      }, {
        "text": "阿拉尔",
        "value": "阿拉尔"
      }, {
        "text": "图木舒克",
        "value": "图木舒克"
      }, {
        "text": "五家渠",
        "value": "五家渠"
      }, {
        "text": "伊犁哈萨克自治州",
        "value": "伊犁哈萨克自治州"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "台湾",
      "value": "台湾",
      "children": [{
        "text": "台北市",
        "value": "台北市"
      }, {
        "text": "高雄市",
        "value": "高雄市"
      }, {
        "text": "台北县",
        "value": "台北县"
      }, {
        "text": "桃园县",
        "value": "桃园县"
      }, {
        "text": "新竹县",
        "value": "新竹县"
      }, {
        "text": "苗栗县",
        "value": "苗栗县"
      }, {
        "text": "台中县",
        "value": "台中县"
      }, {
        "text": "彰化县",
        "value": "彰化县"
      }, {
        "text": "南投县",
        "value": "南投县"
      }, {
        "text": "云林县",
        "value": "云林县"
      }, {
        "text": "嘉义县",
        "value": "嘉义县"
      }, {
        "text": "台南县",
        "value": "台南县"
      }, {
        "text": "高雄县",
        "value": "高雄县"
      }, {
        "text": "屏东县",
        "value": "屏东县"
      }, {
        "text": "宜兰县",
        "value": "宜兰县"
      }, {
        "text": "花莲县",
        "value": "花莲县"
      }, {
        "text": "台东县",
        "value": "台东县"
      }, {
        "text": "澎湖县",
        "value": "澎湖县"
      }, {
        "text": "基隆市",
        "value": "基隆市"
      }, {
        "text": "新竹市",
        "value": "新竹市"
      }, {
        "text": "台中市",
        "value": "台中市"
      }, {
        "text": "嘉义市",
        "value": "嘉义市"
      }, {
        "text": "台南市",
        "value": "台南市"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "澳门",
      "value": "澳门",
      "children": [{
        "text": "花地玛堂区",
        "value": "花地玛堂区"
      }, {
        "text": "圣安多尼堂区",
        "value": "圣安多尼堂区"
      }, {
        "text": "大堂区",
        "value": "大堂区"
      }, {
        "text": "望德堂区",
        "value": "望德堂区"
      }, {
        "text": "风顺堂区",
        "value": "风顺堂区"
      }, {
        "text": "嘉模堂区",
        "value": "嘉模堂区"
      }, {
        "text": "圣方济各堂区",
        "value": "圣方济各堂区"
      }, {
        "text": "路凼",
        "value": "路凼"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }, {
      "text": "香港",
      "value": "香港",
      "children": [{
        "text": "中西区",
        "value": "中西区"
      }, {
        "text": "湾仔区",
        "value": "湾仔区"
      }, {
        "text": "东区",
        "value": "东区"
      }, {
        "text": "南区",
        "value": "南区"
      }, {
        "text": "深水埗区",
        "value": "深水埗区"
      }, {
        "text": "油尖旺区",
        "value": "油尖旺区"
      }, {
        "text": "九龙城区",
        "value": "九龙城区"
      }, {
        "text": "黄大仙区",
        "value": "黄大仙区"
      }, {
        "text": "观塘区",
        "value": "观塘区"
      }, {
        "text": "北区",
        "value": "北区"
      }, {
        "text": "大埔区",
        "value": "大埔区"
      }, {
        "text": "沙田区",
        "value": "沙田区"
      }, {
        "text": "西贡区",
        "value": "西贡区"
      }, {
        "text": "元朗区",
        "value": "元朗区"
      }, {
        "text": "屯门区",
        "value": "屯门区"
      }, {
        "text": "荃湾区",
        "value": "荃湾区"
      }, {
        "text": "葵青区",
        "value": "葵青区"
      }, {
        "text": "离岛区",
        "value": "离岛区"
      }, {
        "text": "其他",
        "value": "其他"
      }]
    }]
}

//获取cookie值
function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i].trim();
    if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
  }
  return "";
}



// 日期格式转化
function formateDateChange(value) {
  var date = new Date(value);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
  if (value === undefined || value === null || value === '') {
    return '- -'
  }
  var Y = date.getFullYear() + '-';
  var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
  var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
  return Y + M + D
}

// 金额加千分位
function thousandth(value) {
  var regex = /(\d)(?=(\d{3})+$)/g
  var result
  if (typeof value === 'string' && value !== '') {
    var str = value
    if (str.indexOf('.') === -1) {
      result = str.replace(regex, '$1,') + '.00'
    } else {
      var newStr = str.split('.')
      var str2 = newStr[0].replace(regex, '$1,')
      if (newStr[1].length <= 1) {
        // 小数点后只有一位时
        result = str2 + '.' + newStr[1] + '0'
      } else if (newStr[1].length > 1) {
        // 小数点后两位以上时
        var decimals = newStr[1].substr(0, 2)
        result = str2 + '.' + decimals
      }
    }
  } else if (typeof value === 'number') {
    return value.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,')
  } else if (value === undefined || value === null || value === '') {
    return '0.00'
  }
  return result
}

// 空值处理
function nullDealWith(value) {
  if (value === undefined || value === null || value === '' || value === 'null' || value === 'undefined') {
    return '- -'
  }
  return value
}


// 超时处理
function overTime(statusCode, flag) {
  switch (statusCode) {
    case statusCode:
      if (statusCode === 401) {
        mui.alert('登录超时，请重新登录', '提示', function () {
          localStorage.removeItem("custType");
          localStorage.removeItem("custNickname");
          localStorage.removeItem("token");
          localStorage.removeItem("custId");
          localStorage.removeItem("contactPhone");
          localStorage.removeItem("menuIds");
          localStorage.removeItem("successId");

          sessionStorage.removeItem("token") // 清除token
          sessionStorage.removeItem("contactPhone") // 清除登录联系人手机号
          sessionStorage.removeItem("custId") // 清除custId
          sessionStorage.removeItem("custNickname") // 清除用户昵称
          sessionStorage.removeItem("custType")  // 清除用户角色
          sessionStorage.removeItem("menuIds")
          document.cookie = "login_status=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/"; // 清除cookie
          if (flag) {
            window.location.href = '../login.html'
          } else {
            window.location.href = '../../login.html'
          }
        });
      } else if (statusCode === 403) {
        mui.alert('角色或权限已变更，请重新登录', '提示', function () {
          localStorage.removeItem("custType");
          localStorage.removeItem("custNickname");
          localStorage.removeItem("token");
          localStorage.removeItem("custId");
          localStorage.removeItem("contactPhone");
          localStorage.removeItem("menuIds");
          localStorage.removeItem("successId");

          sessionStorage.removeItem("token") // 清除token
          sessionStorage.removeItem("contactPhone") // 清除登录联系人手机号
          sessionStorage.removeItem("custId") // 清除custId
          sessionStorage.removeItem("custNickname") // 清除用户昵称
          sessionStorage.removeItem("custType")  // 清除用户角色
          sessionStorage.removeItem("menuIds")
          document.cookie = "login_status=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/"; // 清除cookie
          if (flag) {
            window.location.href = '../login.html'
          } else {
            window.location.href = '../../login.html'
          }
        });
      } else if (statusCode === 406) {
        mui.alert('您的账号还在管理员审核中，如需帮助，请联系管理员。', '提示', function () {
          localStorage.removeItem("custType");
          localStorage.removeItem("custNickname");
          localStorage.removeItem("token");
          localStorage.removeItem("custId");
          localStorage.removeItem("contactPhone");
          localStorage.removeItem("menuIds");
          localStorage.removeItem("successId");

          sessionStorage.removeItem("token") // 清除token
          sessionStorage.removeItem("contactPhone") // 清除登录联系人手机号
          sessionStorage.removeItem("custId") // 清除custId
          sessionStorage.removeItem("custNickname") // 清除用户昵称
          sessionStorage.removeItem("custType")  // 清除用户角色
          sessionStorage.removeItem("menuIds")
          document.cookie = "login_status=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/"; // 清除cookie
          if (flag) {
            window.location.href = '../login.html'
          } else {
            window.location.href = '../../login.html'
          }
        });
      }
      break;
  }
}

// 处理待办页面
function solveMySchedule(statusCode) {
  switch (statusCode) {
    case statusCode:
      if (statusCode === 401) {
        mui.alert('登录超时，请重新登录', '提示', function () {
          localStorage.removeItem("custType");
          localStorage.removeItem("custNickname");
          localStorage.removeItem("token");
          localStorage.removeItem("custId");
          localStorage.removeItem("contactPhone");
          localStorage.removeItem("menuIds");
          localStorage.removeItem("successId");

          sessionStorage.removeItem("token") // 清除token
          sessionStorage.removeItem("contactPhone") // 清除登录联系人手机号
          sessionStorage.removeItem("custId") // 清除custId
          sessionStorage.removeItem("custNickname") // 清除用户昵称
          sessionStorage.removeItem("custType")  // 清除用户角色
          sessionStorage.removeItem("menuIds")
          document.cookie = "login_status=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/"; // 清除cookie
          window.location.href = './login.html'
        });
      } else if (statusCode === 403) {
        mui.alert('角色或权限已变更，请重新登录', '提示', function () {
          localStorage.removeItem("custType");
          localStorage.removeItem("custNickname");
          localStorage.removeItem("token");
          localStorage.removeItem("custId");
          localStorage.removeItem("contactPhone");
          localStorage.removeItem("menuIds");
          localStorage.removeItem("successId");

          sessionStorage.removeItem("token") // 清除token
          sessionStorage.removeItem("contactPhone") // 清除登录联系人手机号
          sessionStorage.removeItem("custId") // 清除custId
          sessionStorage.removeItem("custNickname") // 清除用户昵称
          sessionStorage.removeItem("custType")  // 清除用户角色
          sessionStorage.removeItem("menuIds")
          document.cookie = "login_status=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/"; // 清除cookie
          window.location.href = './login.html'
        });
      } else if (statusCode === 406) {
        mui.alert('您的账号还在管理员审核中，如需帮助，请联系管理员。', '提示', function () {
          localStorage.removeItem("custType");
          localStorage.removeItem("custNickname");
          localStorage.removeItem("token");
          localStorage.removeItem("custId");
          localStorage.removeItem("contactPhone");
          localStorage.removeItem("menuIds");
          localStorage.removeItem("successId");

          sessionStorage.removeItem("token") // 清除token
          sessionStorage.removeItem("contactPhone") // 清除登录联系人手机号
          sessionStorage.removeItem("custId") // 清除custId
          sessionStorage.removeItem("custNickname") // 清除用户昵称
          sessionStorage.removeItem("custType")  // 清除用户角色
          sessionStorage.removeItem("menuIds")
          document.cookie = "login_status=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/"; // 清除cookie
          window.location.href = './login.html'
        });
      }
      break;
  }
}

// 注册信息调用后台接口判断
function check(key, value, e) {
  var len = document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML.length
  var labelText = (document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML).substr(0, len - 1)
  if (value == '') {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '不能为空'
  } else if (value.length != 0) {
    $.ajax({
      type: "POST",
      url: baseip + "/openapi/cust/check",
      data: JSON.stringify({
        key: key,
        value: value
      }),
      // 允许携带证书
      xhrFields: {
        withCredentials: true
      },
      dataType: "json",
      contentType: "application/json;charset=utf-8",
      success: function (res) {
        if (res.status) {
          document.getElementById(e.target.id).style.border = "1px solid #B7B6BC"
          document.getElementById(e.target.id).parentNode.children[1].style.display = 'none'
          document.getElementById(e.target.id).parentNode.children[1].innerHTML = ''
          if (e.target.id == 'custPassword') {
            document.getElementById("showPass").style.display = 'none'
          }
          if (e.target.id == 'contactPhone') {
            exitPhone = false // 手机号不存在
          }
        } else {
          document.getElementById(e.target.id).style.border = "1px solid #f53d61"
          document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
          document.getElementById(e.target.id).parentNode.children[1].innerHTML = res.msg
          if (e.target.id == 'custPassword') {
            document.getElementById("showPass").style.display = 'block'
          }
          if (e.target.id == 'contactPhone') {
            exitPhone = true // 手机号存在
          }
        }
      },
      complete: function (jqXHR) {
        console.log(jqXHR.status);
      },
      error: function (jqXHR, textStatus, errorThrown) {
        overTime(jqXHR.status)  // 处理超时
      }
    })
  } else {
    document.getElementById(e.target.id).style.border = "1px solid #B7B6BC"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'none'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = ''
  }
}

// 注册信息不调用接口校验且不用做正则校验的
function checkNormal(value, e) {
  var len = document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML.length
  var labelText = (document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML).substr(0, len - 1)
  if (value == '') {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '不能为空'
  } else {
    document.getElementById(e.target.id).style.border = "1px solid #B7B6BC"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'none'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = ''
  }
}

// 座机电话校验
function checkPhone(value, e) {
  var re = /^(0[0-9]{2,3}-)?([2-9][0-9]{6,7})+(-[0-9]{1,6})?$/
  var len = document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML.length
  var labelText = (document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML).substr(0, len - 1)
  if (value == '') {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '不能为空'
  } else if (!re.test(value)) {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '格式错误'
  } else {
    document.getElementById(e.target.id).style.border = "1px solid #B7B6BC"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'none'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = ''
  }
}

//法人手机号码校验
function checkPhone2(value, e) {
  var re = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/
  var len = document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML.length
  var labelText = (document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML).substr(0, len - 1)
  if (value == '') {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '不能为空'
  } else if (!re.test(value)) {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '格式错误'
  } else {
    document.getElementById(e.target.id).style.border = "1px solid #B7B6BC"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'none'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = ''
  }
}

// 邮箱校验
function checkEmail(value, e) {
  var re = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
  var len = document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML.length
  var labelText = (document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML).substr(0, len - 1)
  if (value == '') {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '不能为空'
  } else if (!re.test(value)) {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '格式错误'
  } else {
    document.getElementById(e.target.id).style.border = "1px solid #B7B6BC"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'none'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = ''
  }
}

// 银行账号校验
function checkBankAccount(value, e) {
  var re = /^[A-Za-z0-9]{6,18}/
  var len = document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML.length
  var labelText = (document.getElementById(e.target.id).parentNode.parentNode.children[0].innerHTML).substr(0, len - 1)
  if (value == '') {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '不能为空'
  } else if (!re.test(value)) {
    document.getElementById(e.target.id).style.border = "1px solid #f53d61"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'block'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = labelText + '格式错误'
  } else {
    document.getElementById(e.target.id).style.border = "1px solid #B7B6BC"
    document.getElementById(e.target.id).parentNode.children[1].style.display = 'none'
    document.getElementById(e.target.id).parentNode.children[1].innerHTML = ''
  }
}


// 调用发送消息的方法
function sendTradeMessage(transSerialNo, loanType, operateTypeIndex) {
  $.ajax({
    type: "POST",
    url: baseip + "/openapi/wechat/juxin/sendJuXinTransactionMessage",
    data: JSON.stringify({
      transSerialNo: transSerialNo,
      loanType: loanType,
      operateTypeIndex: operateTypeIndex
    }),
    headers: {
      Authorization: sessionStorage.getItem("token") ? sessionStorage.getItem("token") : localStorage.getItem("token")
    },
    // 允许携带证书
    xhrFields: {
      withCredentials: true
    },
    dataType: "json",
    contentType: "application/json;charset=utf-8",
    success: function (res) {
      if (res.status) {
      } else {
      }
    },
    complete: function (jqXHR) {
    },
    error: function (jqXHR, textStatus, errorThrown) {
    }
  })
}