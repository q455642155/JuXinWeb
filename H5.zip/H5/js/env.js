// 本地测试用
// var base = "http://10.134.33.49:8080/JuXinDev";
// var bssetest = "http://10.134.155.141/JuXin";
// var baseip = "http://10.134.33.49:8080/JuXinDev"; // 页面接口调用地址
// var baseip = "https://jurongtest.foxconn.com/JuXinDev"
// var baseimg = "https://jurongtest.foxconn.com"; // 合同地址
// var basedev = "http://10.134.33.49:8080/JuXinDev";
// var YZTUrl = "https://jurongtest.foxconn.com/YZT"; // 一账通推送消息地址

// var base = "https://jurongtest.foxconn.com/JuXin";
// var bssetest = "http://10.134.155.141/JuXin";
// var baseip = "https://jurongtest.foxconn.com/JuXinDev"; // 页面接口调用地址
// var baseimg = "https://jurongtest.foxconn.com";
// var basedev = "https://jurongtest.foxconn.com/JuXinDev";
// var YZTUrl = "https://jurongtest.foxconn.com/YZT"; // 一账通推送消息地址

// 测试环境用
var base = "https://jurongtest.foxconn.com/JuXinDemo";
var bssetest = "http://10.134.155.141/JuXin";
var baseip = "https://jurongtest.foxconn.com/JuXinDemo"; // 页面接口调用地址
var baseimg = "https://jurongtest.foxconn.com"; // 合同地址
var basedev = "https://jurongtest.foxconn.com/JuXinDemo";
var YZTUrl = "https://jurongtest.foxconn.com/YZT"; // 一账通推送消息地址