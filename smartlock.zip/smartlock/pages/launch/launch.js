
let app = getApp()

Page({
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  // onReady: function () {
  //   //延迟调用
  //   setTimeout(function () {
  //     console.log("延迟调用============")
  //     var value = wx.getStorageSync('token')
  //     // app.redirectToHome();、
  //      if (value) {
  //       app.redirectToHome();
  //     }else{
  //       app.redirectToLogin();
  //     }
  //   }, 2000)
     
     
  // }

  onLoad: function (options) {
      setTimeout(function () {
      console.log("延迟调用============")
      var value = wx.getStorageSync('token')
    
       if (value) {
        app.redirectToHome();
      }else{
        app.redirectToLogin();
       }
      }, 2000)

    // app.redirectToLogin();
  },
  onReady: function () {
    console.log("page ---onReady---");
  },
  onShow: function () {
    console.log("page ---onShow---");
  },
  onHide: function () {
    console.log("page ---onHide---");
  },
  onUnload: function () {
    console.log("page ---onUnload---");
  }

  
    
// })

//welcome.js
//获取应用实例
// const app = getApp();

// Page({

//   /**
//    * 页面的初始数据
//    */
//   data: {
//     countDownNumber: 3,
//     timerId: 0
//   },

//   /**
//    * 生命周期函数--监听页面加载
//    */
//   onLoad: function (options) {
//     var page = this;

//     //倒计时关闭当前页，重定向到首页
//     var timer = setInterval(function () {
//       page.setData({
//         countDownNumber: page.data.countDownNumber - 1
//       });
//       if (page.data.countDownNumber == 1) {
//         clearInterval(timer);
//         var value = wx.getStorageSync('token')
   
//       //     app.redirectToHome();
//       //    app.redirectToCicle();
//       //  if (value) {
//       //   app.redirectToHome();
//       // }else{
//         app.toLogin();
//       // }
//       }
//     }, 1000);
//     page.setData({
//       timerId: timer
//     })
//   },

  

 })