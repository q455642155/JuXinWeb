                                                                            // let md5 = require("../MD5.js");
//  let checkNetWork = require("../utils/CheckNetWork.js");
var util = require('../../utils/util.js');
let app = getApp();
let flag, effectDate1;
Page({
  data: {
    focus: false,
    btnDisabled: true,

    // username=admin & password=admin& mobileLogin=true
     
      userLogin: {
      username: '',
      password: '',
      mobileLogin: true,
    },

    domitoryLogin: {
      loginName: '',
      
    },


  },
  userInput: function(e) {
      //手机号输入
   
    let that = this;
    let inputValue = e.detail.value;
    that.setData({
      'userLogin.username': e.detail.value
     
    })
   
  },
  pswInput: function(e) {   //密码输入

    let that = this;
    let inputValue = e.detail.value;
    that.setData({
      'userLogin.password': e.detail.value

    })
       
   
  },
  // 登陆接口调用成功回调
  successFun: function (res, selfObj) {
    console.log(res); 
    let statu = res.data.success;
    let msg = res.data.msg;
    console.log(statu); 
    console.log(msg);
    if (statu ==0) {
      wx.showToast({
        title: msg,
        icon: 'loading',
        duration: 1500,
      })
      //  wx.setStorageSync('token', this.data.userLogin.phone);
      //   app.redirectToHome();
      
     }else{


      if (flag ==  0){
        flag =1;
        let username = res.data.body.username;
        console.log(username);
        wx.setStorageSync('token', username);

        this.setData({
          'domitoryLogin.loginName': username, 

        })
        let url = app.apiUrl+'admin/user/api/dormitory';
        let params1 = this.data.domitoryLogin;
        let params = app.request.json2Form(params1);
        console.log(params);
        app.request.requestPostApi(url, params, this, this.successFun)
      }else{
        var li = JSON.stringify(res.data.body);
        if (li.indexOf("dormitoryNo") != -1){
          
          let exit = res.data.body.flag;
          let id = res.data.body.list[0].user.id;
          let dormitoryNo = res.data.body.list[0].dormitoryNo;
          let equipmentSn = res.data.body.list[0].equipmentSn;
          let terminalSn = res.data.body.list[0].terminalSn;
          let expireDate1 = res.data.body.list[0].expireDate;
          
          let effectDate = res.data.body.list[0].effectDate;
          
          // let expireDate = res.data.body.list[0].expireDate.substring(0, 10).replace('-', '').replace('-', '');
          // let beginTime = res.data.body.list[0].beginTime;
          // let endTime = res.data.body.list[0].endTime;
          let card = res.data.body.list[0].card;
          let fingerprint = res.data.body.list[0].fingerprint;
          let battery = res.data.body.list[0].equipment.battery;
          let name = res.data.body.list[0].equipment.name;
          
          // let card = res.data.body.list[0].card;
          // let fingerprint = res.data.body.list[0].fingerprint;
          
          if (card==null){
            card=0;
          }
          if (fingerprint==null) {
            fingerprint=0;
          }
          // if (exit == 1){
          //   console.log('走了哈哈哈哈');
          // }
          
          console.log(id);
          console.log("exit失效没有:" + exit);
          console.log("宿舍号:" + dormitoryNo);
          console.log("地区大楼：" + name);
          console.log("设备编号：" + equipmentSn);
          console.log("总终端编号：" + terminalSn);
          console.log("生效日期：" + effectDate);
          console.log("到期日期1：" + expireDate1);
          // 到期日期大于当前日期  
         
          // console.log("开始时间：" + beginTime);
          // console.log("结束时间：" + endTime);
          console.log("刷卡：" + card);
          console.log("指纹：" + fingerprint);
          console.log("电量：" + battery);


          wx.setStorageSync('id', id);
          wx.setStorageSync('dormitoryNo', dormitoryNo);
          wx.setStorageSync('equipmentSn', equipmentSn);
          wx.setStorageSync('terminalSn', terminalSn);
          wx.setStorageSync('name',name);
          // wx.setStorageSync('beginTime', beginTime);
          // wx.setStorageSync('endTime', endTime);
          wx.setStorageSync('card', card);
          wx.setStorageSync('fingerprint', fingerprint);
          wx.setStorageSync('battery', battery);

          //   调用函数时，传入new Date()参数，返回值是日期和时间
          var time = util.formatTime(new Date());
          console.log("生效日期：" + time);
          
          if (effectDate==null){
            effectDate1 = time;
            effectDate = time.substring(0, 10).replace('-', '').replace('-', '') + time.substring(11, 16).replace(':', '');
            console.log("修改过的起始日期：" + effectDate);
          
            expireDate1 ='2068-01-01 11:00:00';
           let expireDate = '206801011100';
            wx.setStorageSync('effectDate1', effectDate1);
            wx.setStorageSync('expireDate1', expireDate1);
            wx.setStorageSync('expireDate', expireDate);
            wx.setStorageSync('effectDate', effectDate);
            wx.showToast({
              title: '登陆成功！',
              duration: 1500,
            })
            app.redirectToHome();
          }else{
            // if (time > expireDate1) {

            //   wx.showToast({
            //     title: '授权时间过期！',
            //     duration: 1500,
            //   })

            // } else {
              //处理起始日期和结束日期
              // 2018-10-26 20: 30: 51
              let expireDate = res.data.body.list[0].expireDate.substring(0, 10).replace('-', '').replace('-', '') + res.data.body.list[0].expireDate.substring(11, 16).replace(':', '');
              console.log("修改过的结束日期：" + expireDate);
              if (!(effectDate == null)) {
                effectDate1 = effectDate;
                effectDate = effectDate.substring(0, 10).replace('-', '').replace('-', '') + effectDate.substring(11, 16).replace(':', '');
                console.log("修改过的起始日期：" + effectDate);
              } else {
                effectDate1 = time;
                effectDate = time.substring(0, 10).replace('-', '').replace('-', '') + time.substring(11, 16).replace(':', '');
                console.log("修改过的起始日期：" + effectDate);
              }
              wx.setStorageSync('effectDate1', effectDate1);
              wx.setStorageSync('expireDate1', expireDate1);
              wx.setStorageSync('expireDate', expireDate);
              wx.setStorageSync('effectDate', effectDate);



              wx.showToast({
                title: '登陆成功！',
                duration: 1500,
              })
              app.redirectToHome();
             
 //            }
          }
          
 
        }else{
          wx.showToast({
            title: '未分配房间！',
            duration: 1500,
          })
        }
      
   

        
  
      }
     
     }
  },
  
  bindButtonTap: function() { //登陆按钮

   
    
  
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (this.data.userLogin.username == '') {
        wx.showToast({
        title: '手机号不能为空',
        icon: 'loading',
        duration: 1500
      })
      return false
    } else if (this.data.userLogin.password == ''){
          wx.showToast({
           title: '密码不能为空',
           icon: 'loading',
           duration: 1500
         })
      return false
       }
    
    // else if (!myreg.test(this.data.userLogin.username)) {
    //   wx.showToast({
    //     title: '手机号有误！',
    //      icon: 'loading',
    //     duration: 1500
    //   })
    //   return false
    // }
     else  {
      flag ='0';
      // let url = app.apiUrl + app.url_login;
      let url = app.apiUrl +'admin/login?__ajax';
      let params1 = this.data.userLogin;
      let params = app.request.json2Form(params1);
       console.log(params); 
      app.request.requestPostApi(url, params, this, this.successFun)
       
       }

  },
  onLoad: function () {
    this.setData({
      navH: app.globalData.navHeight
    })
  }
})
