
// var util = require('../../utils/test_code.js');
var app = getApp();  
var MQTT = require("../../utils/paho-mqtt.js");
var util = require('../../utils/util.js');
let flag,flag1,flag2;
let terminal;
let sn;
let id;
let dormitoryno;
let name;
let card;
let fingerprint;
let effectDate1;
let expireDate;
 let value;
var client;
var connectOptions;
Page({

  data: {
    
    // color: #000000;
    name: '',
    dormitoryno:'',
    id:0,
    hiddenName1:false,
    hiddenName: true,
    showModal: false,
    Length: 6,        //输入框个数
    isFocus: true,    //聚焦
    Value: "",        //输入的内容
    ispassword: true, //是否密文显示 true为密文， false为明文。
    count: 0, // 设置 计数器 初始为0
    countTimer: null,// 设置 定时器 初始为null
    card:'',
    fingerprint:'',
    
    titileColor:'',
    titileColor1: '',
    userLogin: {
      loginName: ''
    },
    w:300, // 显示电量的宽
    h:300, // 显示电量的高
    increase:{
     
      'terminal': '',	// string字符，表示主机序列号
      'sn': '',//设备序列号
      'action': 101,		//int32 型数字，表示具体动作
      'param': {	//参数，类型依据action不同而不同
       'userId':'',
       'password':'',
       'pwdType':1,
        
        "effectDate": "",
        "expireDate": "",

       },

    }	,
    activation:{
      'terminal': '',	// string字符，表示主机序列号
      'sn': '',//设备序列号
      // 'terminal': 'Q64672308370020000101',	// string字符，表示主机序列号
      // 'sn': 'C6F5641130C8018000101',//设备序列号
      'action': 104,		//int32 型数字，表示具体动作
      'param': {	//参数，类型依据action不同而不同
      'userId': '',
      // 'password': '',
      'pwdType': 1,
      'optType':''
      },
     }, 
     },

  // 密码的事件
  Focus(e) {
    var that = this;
    console.log(e.detail.value);
    var inputValue = e.detail.value;
    that.setData({
      Value: inputValue,
    })
    this.setData({
      'increase.param.password': parseInt(inputValue)

    });

    // this.setData({
    //   'activation.param.password':parseInt(inputValue)

    // });

  },

  //提交
  formSubmit(e) {
    console.log(parseInt(e.detail.value.password));
  },

  Tap() {
    var that = this;
    that.setData({
      isFocus: true,
    })
  },

  /**
   * 退回到上一个页面
   */
  navBack: function () {
    this.data.count = 0;
   
    clearInterval(this.countTimer);
    app.toMy();
    //结束掉连结
    //app.globalData.mqtt_client.
    // if (app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected()) {
    //   app.globalData.mqtt_client.disconnect();
    // }
  },

  // onShow: function () {
  //   console.log("app.js ---onShow---");
  // },

  
  onShow: function () {

   

     dormitoryno = wx.getStorageSync('dormitoryNo');
     name = wx.getStorageSync('name');
     let expireDate = wx.getStorageSync('expireDate');
     let effectDate = wx.getStorageSync('effectDate');
    console.log('effectDate的传的时间:' + effectDate);
    console.log('expireDate的传的时间:' + expireDate);
     this.setData({
      'increase.param.expireDate': expireDate
     }) 

     this.setData({
      'increase.param.effectDate': effectDate
     }) 
      
      this.setData({
        name: name
      })

     this.setData({
       dormitoryno: dormitoryno
     })
      
     wx.setNavigationBarTitle({
      title: name
    })

    this.setData({
      'userLogin.loginName': value

    });

    this.setData({
      'increase.terminal': terminal

    });


    this.setData({
      'increase.sn': sn
    });

    this.setData({
      'activation.terminal': terminal

    });
    this.setData({
      'activation.sn': sn
    });



    this.setData({
      'increase.param.userId': id

    });
    this.setData({
      'activation.param.userId': id
    });

    value = wx.getStorageSync('token');
    this.setData({
      'userLogin.loginName': value

    });

    let url = app.apiUrl + 'admin/user/api/dormitory';
    let params1 = this.data.userLogin;
    console.log(params1);
    let params = app.request.json2Form(params1);
    console.log(params);
    app.request.requestPostApi(url, params, this, this.successFun)

    // if (app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected()) {
    //    //不要在连接了
    //   wx.showToast({
    //     title: '不要重复连接'
    //   })
    //   return
    // }

    console.log('从后台进来了22222----');

    // client= new MQTT.Client("wss://www.shuxundz.com/mqtt",
    //   "clientId_" + value);

    client = new MQTT.Client("wss://www.timeslock.com/mqtt",
       "clientId_" + value);
    
    var that = this;
   
    connectOptions = {
      timeout: 5,
      useSSL: true,
      cleanSession: true,
      
       keepAliveInterval: 20,
      
      onSuccess: function () {

      console.log('connected');

        app.globalData.mqtt_client = client;

        client.onMessageArrived = function (msg) {
          console.log("收到消息:" + msg.payloadString);
         // client.disconnect();
          if (JSON.parse(msg.payloadString).code ==200){
            if (JSON.parse(msg.payloadString).action == 104 ){
                //订阅主题
             // application/lock/info/req/ 用户id
            
              //添加指纹和密码
              // if (app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected())                         {
               console.log("调用异步发送");
                app.globalData.mqtt_client.subscribe("application/lock/info/req/"+id);
                
              // }
            } else if (JSON.parse(msg.payloadString).action == 105){
              if (JSON.parse(msg.payloadString).param.status == 6){
                console.log("-------异步指纹成功")
                flag = 4;
                flag1=4;
                flag2=2;
                
              
              }
              if (JSON.parse(msg.payloadString).param.status == 7) {
                console.log("--------异步刷卡成功")
                flag = 4;
                flag1 = 4;
                flag2 = 3;
              }
            
              if (JSON.parse(msg.payloadString).param.status == 8) {
                console.log("--------异步指纹失败")
                flag = 5;
                flag1 = 0;
              }

              if (JSON.parse(msg.payloadString).param.status == 9) {
                console.log("--------异步刷卡失败")
                flag = 5;
                flag1 = 0;
              }
            
            }
        
            else{
              flag = 4;
              flag1 = 0;
            }
          } else if (JSON.parse(msg.payloadString).code == 500){
            let param = JSON.parse(msg.payloadString).param;
            if (param ==1){
              wx.showToast({
                title: '系统忙',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
             
            } else if (param == 2) {
              wx.showToast({
                title: '设备未响应',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
              
            } else if (param == 3) {
              wx.showToast({
                title: '设备不存在',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            } else if (param == 4) {
              wx.showToast({
                title: '未知错误',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            } else if (param == 5) {
              wx.showToast({
                title: '未知指令',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            } else if (param == 6) {
              wx.showToast({
                title: 'Lora主机故障',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            } else if (param == 7) {
              wx.showToast({
                title: '设备序列号无效',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            } else if (param == 8) {
              wx.showToast({
                title: '设备数量超过上限',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            } else if (param == 9) {
              wx.showToast({
                title: '用户数量超过上限',
                icon: 'loading',
                duration: 1500,
              })
            } else if (param == 10) {
              wx.showToast({
                title: '用户不存在',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
              //这个时候把用户退出
              app.redirectToLogin();
              // this.drawCircle(0)
              this.setData({
                hiddenName: true
              })

              this.data.count = 0;
              clearInterval(this.countTimer);

            } else if (param == 11) {
              wx.showToast({
                title: '该类用户不支持',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            } else if (param == 12) {
              wx.showToast({
                title: '用户密码错误',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            } else if (param == 13) {
              wx.showToast({
                title: '指令校检错误',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            }
            else if (param == 14) {
              wx.showToast({
                title: '不在有效期',
                icon: 'loading',
                duration: 1500,
              })
              flag == 5;
            }
            
            // 1	系统忙
            // 2	设备未响应
            // 3	设备不存在
            // 4	未知错误
            // 5 未知指令
            // 6  Lora主机故障
            // 7 设备序列号无效
            // 8 设备数量超过上限
            // 9 用户数量超过上限
            // 10 用户不存在
            // 11	该类用户不支持
            // 12 密码错误
            // 13 指令校检错误
            // 14 不在有效期
          }
        
        
        }
        client.onConnectionLost = function (responseObject) {
          if (typeof app.globalData.onConnectionLost === 'function') {

            // setTimeout(function () {
            //   client.connect(connectOptions);
            // }, 2000)

            if (!(app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected())) {
              console.log('走的断线重连')


              setTimeout(function () {
                if (null != client) {
                  client.connect(connectOptions);

                }

              }, 2000)

            }

            return app.globalData.onConnectionLost(responseObject);
          
          
          }
          if (responseObject.errorCode !== 0) {

            console.log("onConnectionLost:" + responseObject.errorMessage);
          
          }
        }

      },
      onFailure: function (e) {
        console.log(e);
      }
    };

    console.log('从后台进来了333333----');
    connectOptions.userName = 'client';
    connectOptions.password = '123456';
    if (!(app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected())) {
    client.connect(connectOptions);
    // value为获取的本地信息
    }
  },

  

  // 触摸开始时间
  touchStartTime: 0,
  // 触摸结束时间
  touchEndTime: 0,
  // 最后一次单击事件点击发生时间
  lastTapTime: 0,
  // 单击事件点击后要触发的函数
  lastTapTimeoutFunc: null,



  /// 按钮触摸开始触发的事件
  touchStart: function (e) {
    this.touchStartTime = e.timeStamp
  },

  /// 按钮触摸结束触发的事件
  touchEnd: function (e) {
    this.touchEndTime = e.timeStamp
  },



  
  onLoad: function () {

     flag2=0;
     flag1=0;
    // 页面渲染完成
   
      value = wx.getStorageSync('token');
     id = wx.getStorageSync('id');
     terminal = wx.getStorageSync('terminalSn');
     sn = wx.getStorageSync('equipmentSn');
    var expireDate = wx.getStorageSync('expireDate');
    console.log("用户的id:"+id);

    var beginTime = wx.getStorageSync('beginTime');
    var endTime = wx.getStorageSync('endTime');

    var card1 = wx.getStorageSync('card');
    var fingerprint1 = wx.getStorageSync('fingerprint');
   
    if (card1==1){
      console.log('刷卡了')
      this.setData({
        'card': true,
        'titileColor1': '#3bb6fb',
      });
    }else{
      console.log('没有刷卡')
      this.setData({
        'card': false,
        'titileColor1': '#000000',

      });
    }

    if (fingerprint1 == 1) {
      this.setData({
        'fingerprint': true,
        'titileColor': '#3bb6fb',
      });
    } else {
      this.setData({
        'titileColor': '#000000',
        'fingerprint': false

      });
    }
    
    this.setData({
      'userLogin.loginName': value

    });

    this.setData({
      'increase.terminal': terminal

    });

  
    this.setData({
      'increase.sn': sn
    });

    this.setData({
      'activation.terminal': terminal

    });
    this.setData({
      'activation.sn': sn
    });



    this.setData({
      'increase.param.userId': id

    });
    this.setData({
      'activation.param.userId': id
    });
    
    this.setData({
      'userLogin.loginName': value

    });
    
    // let url = app.apiUrl+'admin/user/api/dormitory';
    // let params1 = this.data.userLogin;
    // console.log(params1);
    // let params = app.request.json2Form(params1);
    // console.log(params); 
    // app.request.requestPostApi(url, params, this, this.successFun)

  },
  // onShow: function () {
  //   // 页面显示
  // },
  onHide: function () {
    // if (app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected()) {
      // this.data.count = 0;
      // clearInterval(this.countTimer);
     console.log('-----------------')
    //   app.globalData.mqtt_client.disconnect();
    // }
  
    this.drawCircle(0)
    this.setData({
      hiddenName: true
    })

    this.data.count = 0;
    clearInterval(this.countTimer);
  
  
  },
  // onUnload: function () {
  //   // 页面关闭
  // },

  // 网络调用成功的回调用成功回调
  successFun: function (res, selfObj) {
    console.log(res);
    console.log('电量访问成功');
    
  
    var li = JSON.stringify(res.data.body);
    if (li.indexOf("dormitoryNo") != -1) {
      let exit = res.data.body.flag;
      let id = res.data.body.list[0].user.id;
      let dormitoryNo = res.data.body.list[0].dormitoryNo;
      let equipmentSn = res.data.body.list[0].equipmentSn;
      let terminalSn = res.data.body.list[0].terminalSn;
      let expireDate1 = res.data.body.list[0].expireDate;
      let effectDate = res.data.body.list[0].effectDate;

      // let expireDate = res.data.body.list[0].expireDate.substring(0, 10).replace('-', '').replace('-', '');
      // let beginTime = res.data.body.list[0].beginTime;
      // let endTime = res.data.body.list[0].endTime;
       card = res.data.body.list[0].card;
       fingerprint = res.data.body.list[0].fingerprint;
      let battery = res.data.body.list[0].equipment.battery;

      let name = res.data.body.list[0].equipment.name;
      if (card == null) {
        card = 0;
      }
      if (fingerprint == null) {
        fingerprint = 0;
      }

      console.log(id);
      console.log("exit失效没有:" + exit);
      console.log("宿舍号:" + dormitoryNo);
      console.log("地区大楼：" + name);
      console.log("设备编号：" + equipmentSn);
      console.log("总终端编号：" + terminalSn);
      console.log("生效日期：" + effectDate);
      console.log("到期日期1：" + expireDate1);
      // 到期日期大于当前日期  

      // console.log("开始时间：" + beginTime);
      // console.log("结束时间：" + endTime);
      console.log("刷卡：" + card);
      console.log("指纹：" + fingerprint);
      console.log("电量：" + battery);


      wx.setStorageSync('id', id);
      wx.setStorageSync('dormitoryNo', dormitoryNo);
      wx.setStorageSync('equipmentSn', equipmentSn);
      wx.setStorageSync('terminalSn', terminalSn);
      wx.setStorageSync('name', name);
      // wx.setStorageSync('beginTime', beginTime);
      // wx.setStorageSync('endTime', endTime);
      wx.setStorageSync('card', card);
      wx.setStorageSync('fingerprint', fingerprint);
      wx.setStorageSync('battery', battery);

      //   调用函数时，传入new Date()参数，返回值是日期和时间
      var time = util.formatTime(new Date());
      console.log("生效日期：" + time);

      if (effectDate == null) {
        effectDate1 = time;
        effectDate = time.substring(0, 10).replace('-', '').replace('-', '') + time.substring(11, 16).replace(':', '');
        console.log("修改过的起始日期：" + effectDate);

        expireDate1 = '2068-01-01 11:00:00';
       let  expireDate = '206801011100';
        wx.setStorageSync('effectDate1', effectDate1);
        wx.setStorageSync('expireDate1', expireDate1);
        wx.setStorageSync('expireDate', expireDate);
        wx.setStorageSync('effectDate', effectDate);

      } else {
      
      // if (time > expireDate1) {

      //   wx.showToast({
      //     title: '授权时间过期！',
      //     duration: 1500,
      //   })

      //    //跳转到登录页面 
      //   app.redirectToLogin();


      // } else {
        //处理起始日期和结束日期
      
        expireDate = res.data.body.list[0].expireDate.substring(0, 10).replace('-', '').replace('-', '') + res.data.body.list[0].expireDate.substring(11, 16).replace(':', '');
        console.log("修改过的结束日期：" + expireDate);
        if (!(effectDate == null)) {
          effectDate1 = effectDate;
          effectDate = effectDate.substring(0, 10).replace('-', '').replace('-', '') + effectDate.substring(11, 16).replace(':', '');
          console.log("修改过的起始日期：" + effectDate);
        } else {
          effectDate1 = time;
          effectDate = time.substring(0, 10).replace('-', '').replace('-', '') + time.substring(11, 16).replace(':', '');
          console.log("修改过的起始日期：" + effectDate);
        
          wx.setStorageSync('effectDate1', effectDate1);
          wx.setStorageSync('expireDate1', expireDate1);
          wx.setStorageSync('expireDate', expireDate);
          wx.setStorageSync('effectDate', effectDate);
        
        }
       
      // }
        //在这里显示电量,录入指纹，文字颜色，日期定义等等
        var card1 = wx.getStorageSync('card');
        var fingerprint1 = wx.getStorageSync('fingerprint');
        if (exit == 1){
            console.log('已经失效了---');
            this.setData({
            hiddenName1: true
          })
          }
      
        if (card1 == 1) {
          console.log('刷卡了')
          this.setData({
            'card': true,
            'titileColor1': '#3bb6fb',
          });
        } else {
          console.log('没有刷卡')
          this.setData({
            'card': false,
            'titileColor1': '#000000',

          });
        }

        if (fingerprint1 == 1) {
          this.setData({
            'fingerprint': true,
            'titileColor': '#3bb6fb',
          });
        } else {
          this.setData({
            'titileColor': '#000000',
            'fingerprint': false

          });
        }

       

        dormitoryno = wx.getStorageSync('dormitoryNo');
        name = wx.getStorageSync('name');
      // expireDate = wx.getStorageSync('expireDate');
      // effectDate = wx.getStorageSync('effectDate');
        // wx.setStorageSync('expireDate1', expireDate1);
     this.setData({
      'increase.param.expireDate': expireDate
     }) 

     this.setData({
      'increase.param.effectDate': effectDate
     }) 


        console.log('effectDate的传的时间:' + effectDate);
        console.log('expireDate的传的时间:' + expireDate);
      this.setData({
        name: name
      })

     this.setData({
       dormitoryno: dormitoryno
     })
      
     wx.setNavigationBarTitle({
      title: name
    })


        this.setData({
          name: name
        })

        this.setData({
          dormitoryno: dormitoryno
        })

        wx.setNavigationBarTitle({
          title: name
        })
      }
      
      //battery
      if (battery == '0'){
        battery ='100'
      }

      //电量才是最主要显示的
      this.setData({
        text1: "正常",
        text2: '电量' + parseInt(battery) + '%',
        text3: parseInt(battery) + '%',
        w: 150 / (parseInt(battery) / 100) +'px', // 动态改变电量的显示高度
        h: 150 / (parseInt(battery) / 100) + 'px' // 动态改变电量的显示高度
      });


    } else {
      wx.showToast({
        title: '未分配房间！',
        duration: 1500,
      })
    
      app.redirectToLogin(); 
    
    }
  
  
   
  
  },

  longTap: function (e) {
    console.log("long tap")
    wx.showToast({
      title: '不允许长按按钮',
      icon: 'loading',
      duration: 1500,
    })
  },

  

  /**
   * 弹窗
   */
  multipleTap: function (e) {

   
    var that = this
    // 控制点击事件在350ms内触发，加这层判断是为了防止长按时会触发点击事件
    if (that.touchEndTime - that.touchStartTime < 350) {
      // 当前点击的时间
      var currentTime = e.timeStamp
      var lastTapTime = that.lastTapTime
      // 更新最后一次点击时间
      that.lastTapTime = currentTime

      // 如果两次点击时间在300毫秒内，则认为是双击事件
      if (currentTime - lastTapTime < 150) {
        console.log("double tap")
        // 成功触发双击事件时，取消单击事件的执行
        clearTimeout(that.lastTapTimeoutFunc);
        wx.showToast({
          title: '多次点击无效',
          icon: 'loading',
          duration: 1500,
        })
      } else {
        // 单击事件延时300毫秒执行，这和最初的浏览器的点击300ms延时有点像。
        that.lastTapTimeoutFunc = setTimeout(function () {
          console.log("tap")
        
          if (!(app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected()))           {
            wx.showToast({
              title: '网络繁忙',
              icon: 'loading',
              duration: 1500,
            })
                
            client.connect(connectOptions);
            return;
          }
          console.log('flag的值是：' + flag);
          console.log('计时器的读数：' + that.data.count);
          //每次点击之前清除时间进度
          if (that.data.count > 0) {

            wx.showToast({
              title: '操作中',
              icon: 'loading',
              duration: 1500,
            })

            return;
          }

          var kind = e.currentTarget.id
          console.log(kind);
          // var that = this


          console.log("单击事件-----")
          if (kind == 'mima') {
            flag = 1;
            that.setData({
              showModal: true
            })
          } else if (kind == 'zhiwen') {

             console.log('对话框出来啊啊');
            wx.showModal({
              title: '录入指纹',
              content: '您确定要录入指纹吗？',
              success: function (sm) {
                if (sm.confirm) {
              that.setData({
              hiddenName: false
            });

            that.data.count = 0;
            that.countInterval();

            flag = 2;
            that.setData({
              'activation.param.optType': 1
            });


            let params2 = JSON.stringify(that.data.activation);
            //指纹
            if (app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected()) {
              //  console.log('走了录指纹的方法')
              app.globalData.mqtt_client.subscribe("application/lock/interface");//订阅主题
              app.globalData.mqtt_client.publish("terminal/lock/interface/" + terminal, params2)

            }
            const innerAudioContext = wx.createInnerAudioContext()
            innerAudioContext.autoplay = true
            innerAudioContext.src = 'http://www.timeslock.com/zhiwen.mp3'

            innerAudioContext.onPlay(() => {
              console.log('开始播放')
              wx.showToast({
                title: '等待指纹灯亮起',
                icon: 'loading',
                duration: 1500,
              })

            })
            innerAudioContext.onError((res) => {
              console.log(res.errMsg)
              console.log(res.errCode)
            })

                } else if (sm.cancel) {
               
                }
              }
            })

           

          } else if (kind == 'shuka') {


            wx.showModal({
              title: '录入工牌',
              content: '您录入确定要录入工牌吗？',
              success: function (sm) {
                if (sm.confirm) {
                  that.setData({
                 hiddenName: false
                });

            that.data.count = 0;
            that.countInterval();
            flag = 3;
            that.setData({
              'activation.param.optType': 2
            });

            let params3 = JSON.stringify(that.data.activation);
            if (app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected()) {

              app.globalData.mqtt_client.subscribe("application/lock/interface");//订阅主题
              app.globalData.mqtt_client.publish("terminal/lock/interface/" + terminal, params3)
            }

            const innerAudioContext = wx.createInnerAudioContext()

            innerAudioContext.autoplay = true
            innerAudioContext.src = 'http://www.timeslock.com/mima.mp3'
            innerAudioContext.onPlay(() => {
              console.log('开始播放')
              wx.showToast({
                title: '等待锁屏幕亮起',
                icon: 'loading',
                duration: 1500,
              })

            })
            innerAudioContext.onError((res) => {
              console.log(res.errMsg)
              console.log(res.errCode)
            })

                } else if (sm.cancel) {
                  console.log('用户点击取消')
                }
              }
            })

          }
        }, 300);
      }
    }

 
  },
  /**
   * 弹出框蒙层截断touchmove事件
   */
  preventTouchMove: function () {
  },
  /**
   * 隐藏模态对话框
   */
  hideModal: function () {
    this.setData({
      showModal: false
    });
  },
  /**
   * 对话框取消按钮点击事件
   */
  onCancel: function () {
    this.hideModal();
  },

  
  /**
   * 对话框确认按钮点击事件
   */
  onConfirm: function () {
    this.hideModal();
    this.setData({
      hiddenName: false
    });

    this.setData({
      'Value': ''
     
    });

    
    this.data.count=0;
    this.countInterval();
     if (flag == 1) {
     //密码
       var params1 = JSON.stringify(this.data.increase);
        console.log(params1);
       if (app.globalData.mqtt_client && app.globalData.mqtt_client.isConnected()) {
         app.globalData.mqtt_client.subscribe("application/lock/user/info");//订阅主
     
         app.globalData.mqtt_client.publish("terminal/lock/user/info/" + terminal, params1)
       
       }
    } 
    
    
    
    
  },
  countInterval: function () {
    // 设置倒计时 定时器 每1000毫秒执行一次，计数器count+1 ,耗时60秒绘一圈
    this.countTimer = setInterval(() => {
      if (this.data.count <= 40) {
        /* 绘制彩色圆环进度条  
        注意此处 传参 step 取值范围是0到2，
        所以 计数器 最大值 60 对应 2 做处理，计数器count=60的时候step=2
        */
        this.drawCircle(this.data.count / (40 / 2))
        this.data.count++;
        if (flag ==4){
          this.drawCircle(0)
          this.setData({
            hiddenName: true
          })

          this.data.count = 0;
          clearInterval(this.countTimer);
         
          //提示添加成功
          wx.showToast({
            title: '操作成功',
            icon: 'success',
            duration: 1500,
          })
          if(flag1=4){
                if(flag2==3){
                  this.setData({
                    'card': true,
                    'titileColor1': '#3bb6fb',
                  });
                }
            if (flag2 == 2){
              this.setData({
                'fingerprint': true,
                'titileColor': '#3bb6fb',
              });
            }
             
            }else{
            wx.showToast({
              title: '操作失败',
              icon: 'success',
              duration: 1500,
            })
            }
        
        }
        if (flag == 5) {
          this.drawCircle(0)
          this.setData({
            hiddenName: true
          })

          //返回失败的提示
          wx.showToast({
            title: '操作失败',
            icon: 'loading',
            duration: 1500,
          })
          this.data.count = 0;
          
          clearInterval(this.countTimer);
           
        }

      } else {
        this.drawCircle(0)
        this.setData({
          hiddenName: true
        })
       
        //返回失败的提示
        wx.showToast({
          title: '操作失败',
          icon: 'loading',
          duration: 1500,
        })
        this.data.count = 0;
        //清除进度时间
        clearInterval(this.countTimer);
      }
    }, 1000)
  },

  drawProgressbg: function () {
    // 使用 wx.createContext 获取绘图上下文 context
    var ctx = wx.createCanvasContext('canvasProgressbg');
    ctx.setLineWidth(4);// 设置圆环的宽度
    ctx.setStrokeStyle('#F39F83'); // 设置圆环的颜色
    ctx.setLineCap('round') // 设置圆环端点的形状
    ctx.beginPath();//开始一个新的路径
    ctx.arc(85, 85, 80, 0, 2 * Math.PI, false);
    //设置一个原点(100,100)，半径为90的圆的路径到当前路径
    ctx.stroke();//对当前路径进行描边
    ctx.draw();
  },

  drawCircle: function (step) {
    var context = wx.createCanvasContext('canvasProgress');
    // 设置渐变
    var gradient = context.createLinearGradient(200, 100, 100, 200);
    gradient.addColorStop("0", "#F39F83");
    gradient.addColorStop("0.5", "#F39F83");
    gradient.addColorStop("1.0", "#F39F83");
    context.setLineWidth(10);
    context.setStrokeStyle(gradient);
    context.setLineCap('round')
    context.beginPath();
    // 参数step 为绘制的圆环周长，从0到2为一周 。 -Math.PI / 2 将起始角设在12点钟位置 ，结束角 通过改变 step 的值确定
    context.arc(85, 85, 80, -Math.PI / 2, step * Math.PI - Math.PI / 2, false);
    context.stroke();
    context.draw()
  },
  
  

})
