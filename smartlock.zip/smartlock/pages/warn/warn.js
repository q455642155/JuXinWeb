// pages/warn/index.js


let app = getApp();

var params;
var params1;
var loginName, type, remarks, dormitoryNo;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userRegister: {
       loginName: '',
       type: '',
       remarks:'',
       dormitoryNo: '',
    },
      inputValue:{
         num: 0,
         desc: ""
      },
      actionText: "拍摄/相册",
      picUrls: [],
      checkboxValues: [],
      itemsValue: [{
         value: "密码无效",
         checked: false,
        color: "#3381F8"
      }, {
         value: "指纹无效",
         checked: false,
          color: "#3381F8"
         }, {
            value: "刷卡无效",
            checked: false,
          color: "#3381F8"
      }, {
         value: "键盘失灵",
         checked: false,
          color: "#3381F8"
         },
        {
         value: "锁体坏了",
         checked: false,
          color: "#3381F88"
         }, 
        
      {
         value: "其他故障",
         checked: false,
        color: "#3381F8"
      }],
      btnColor: "#f2f2f2"
  },

  changeNum: function (e) {
  
    let that = this;
    let inputValue = e.detail.value;
    
    that.setData({
      'userRegister.remarks': e.detail.value

    })
    remarks = e.detail.value

  },

  checkboxChange: function(e) {
     var _value = e.detail.value;
     if(_value.length == 0) {
        this.setData({
           checkboxValues : [],
           btnColor : "#f2f2f2"
        })
     }else{
        this.setData({
           checkboxValues : _value,
          btnColor: "#3381F8"
        })
     }
   },

   clickPhoto: function() {
      wx.chooseImage({
         success: (res) => {
            console.log(res);
            var _picUrls = this.data.picUrls;
            var tfs = res.tempFilePaths;
           console.log(_picUrls);
           console.log(tfs);
            for(let temp of tfs) {
               _picUrls.push(temp);
            }
            this.setData({
               picUrls : _picUrls,
               actionText: "+"
            })
         },
      })
   },

   delPhoto: function(e) {
      console.log(e);
      let index = e.target.dataset.index;
      let _picUrls = this.data.picUrls;
      _picUrls.splice(index,1);
      this.setData({
         picUrls: _picUrls
      })
      if(_picUrls.length == 0) {
         this.setData({
            actionText: "拍摄/相册"
         })
      }
   },
  //  changeNum: function(e) {
  //     this.setData({
  //        inputValue:{
  //           num: e.detail.value,
  //           desc: this.data.inputValue.desc
  //        }
  //     })
  //  },

   changeDesc: function(e) {
      this.setData({
         inputValue:{
            num: this.data.inputValue.num,
            desc: e.detail.value
         }
      })
   },

   submit: function() {
      if(this.data.checkboxValues.length > 0 

      && this.data.picUrls.length > 0) {

        if (this.data.checkboxValues[0] == '密'){
          this.setData({
            'userRegister.type': '1'
          })
          console.log('密码无效');
          type ='1';
        } else if (this.data.checkboxValues[0] == '刷'){
          this.setData({
            'userRegister.type': '3'
          })
          type = '3';
          console.log('刷卡无效');
        } else if (this.data.checkboxValues[0] == '锁') {
          this.setData({
            'userRegister.type': '5'
          })
          type = '5';
          console.log('锁体坏了');
        } else if (this.data.checkboxValues[0] == '指') {

          this.setData({
            'userRegister.type': '2'
          })
          type = '2';

          console.log('指纹无效');
        } else if (this.data.checkboxValues[0] == '键') {
          this.setData({
            'userRegister.type': '4'
          })
          type = '4';
          console.log('键盘失灵');
        } else if (this.data.checkboxValues[0] == '其') {
          this.setData({
            'userRegister.type': '6'
          })
          type = '6';
          console.log('其他故障');
        }
        console.log(this.data.checkboxValues[0]);
        params1  = this.data.userRegister;
        params = app.request.json2Form(params1);
        console.log(params);

        var pics = this.data.picUrls
          //调用上传图片的具体实现
          this.uploadimg({
            url: app.apiUrl + 'admin/user/api/failureReporting',
            path: pics,//这里是选取的图片的地址数组
          });

        // let url = app.apiUrl + 'admin/user/api/failureReporting';
        // let params1 = this.data.userRegister;
        // let params = app.request.json2Form(params1);
        // console.log(params);
        // app.request.requestPostApi(url, params, this, this.successFun)
        

        
        // const tempFilePaths = res.tempFilePaths
        // wx.uploadFile({

        //    // 上传一张图片测试
        //    url = app.apiUrl + 'admin/user/api/failureReporting',
        //   filePath: tempFilePaths[0],
        //   name: 'file',
        //   formData: {
        //     'user': 'test'
        //   },
        //   success(res) {
        //     const data = res.data
        //     //do something
        //   }
        // })

        // wx.showToast({
        //   title: '提交成功',
        //   icon: 'success',
        //   duration: 1500,
        // })



        // setTimeout(function () {
        //   console.log("延迟调用============")
        //   wx.navigateBack({
        //     delta: 1
        //   })
        // }, 1500)
       
        
      }else {
         wx.showModal({
            title: '请填写完整的反馈信息',
            content: '选择故障种类并拍照',
            confirmText: '确定',
            cancelText: '取消',
            success: (res) => {
               if(res.confirm) {
                  console.log(res);
               }else {
                  
               }
            }
         })
      }
   },


  successFun: function (res, selfObj) {
   
    let statu = res.data.success;
    let msg = res.data.msg;
    console.log(statu);
    console.log(msg);
    if (statu == 0) {
      wx.showToast({
        title: msg,
        icon: 'loading',
        duration: 1500,
      })
    }else{
      wx.showToast({
        title: '上传成功',
        icon: 'success',
        duration: 1500,
      })

      setTimeout(function () {
        console.log("延迟调用============")
        wx.navigateBack({
          delta: 1
        })
      }, 1500)

    }
  },

  uploadimg: function (data) {
    console.log(params1);
    var that = this,
      i = data.i ? data.i : 0,
      success = data.success ? data.success : 0,
      fail = data.fail ? data.fail : 0;
      wx.uploadFile({
      url: data.url,
      filePath: data.path[i],
        name: 'files',
        formData: {
          loginName: loginName,
          type: type,
          remarks: remarks,
          dormitoryNo: dormitoryNo,
        //此处可以传自定义参数……
      },
       
      header: {
        "Content-Type": "multipart/form-data",
        //"sessionId": getApp().globalData.sessionId,
      },
      success: (resp) => {
        console.log(resp);
        success++;
      },
      fail: (res) => {
        fail++;
      },
      complete: () => {
        i++;
        if (i == data.path.length) {   //当图片传完时，停止调用
          wx.showToast({
            title: '上传成功',
            duration: 1500,
            mask: 'false'
          })
          that.setData({
            tempFilePaths: []
          })
        
          setTimeout(function () {
            console.log("延迟调用============")
            wx.navigateBack({
              delta: 1
            })
          }, 1500)
        
        } else {//若图片还没有传完，则继续调用函数
          data.i = i;
          data.success = success;
          data.fail = fail;
          that.uploadimg(data);
        }
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let token = wx.getStorageSync('token');
     dormitoryNo = wx.getStorageSync('dormitoryNo');
     loginName = wx.getStorageSync('token');
    
    // var loginName, type, remarks, dormitoryNo;
    this.setData({
      'userRegister.dormitoryNo': dormitoryNo
    })
  
    this.setData({
      'userRegister.loginName': token
    })

    this.setData({
      navH: app.globalData.navHeight
    }) 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
 * 退回到上一个页面
 */
  navBack: function () {
    wx.navigateBack({
      delta: 1
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})