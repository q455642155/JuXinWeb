var voice = "";
Page({
  
  
  play: function () {
    console.log("11111")
    //播放声音文件  
    // wx.playVoice({
    //   filePath: "/images/zhiwen1.mp3"
    // })
  },
  // start: function () {
  //   //开始录音  
  //   wx.startRecord({
  //     success: function (e) {
  //       voice = e.tempFilePath
  //     }
  //   })
  // },
  // stop: function () {
  //   //结束录音  
  //   wx.stopRecord();
  // }
})

