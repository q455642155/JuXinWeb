// let md5 = require("../MD5.js");
// let checkNetWork = require("../utils/CheckNetWork.js");
let app = getApp();
let flag;
Page({
  data: {
    focus: false,
    btnDisabled: true,

   

    userRegister: {
      loginName: '',
      phone: '',
    },
    

    

  },

  onLoad: function () {
    let token = wx.getStorageSync('token');
    
    this.setData({
      'userRegister.loginName': token
    })

  },

  // onReady: function () {
  //   // 页面渲染完成
  // },
  // onShow: function () {
  //   // 页面显示

  // },
  // onHide: function () {
  //   // 页面隐藏
  // },
  // onUnload: function () {
  //   // 页面关闭
  // },
  

  userInput: function (e) {  //手机号输入
    let that = this;
    let inputValue = e.detail.value;

    that.setData({
      'userRegister.phone': inputValue

    })
  
  },

 

  //返回
  navBack:function(){
    wx.navigateBack({
      delta: 1
    })      
  },

 

  successFun: function (res, selfObj) {
    console.log(flag);
 

      let statu = res.data.success;
      let msg = res.data.msg;
      console.log(statu);
      console.log(msg);
      if (statu == 0) {
        
        console.log('111111');
        wx.showToast({
          title: msg,
          icon: 'loading',
          duration: 1500,
        })
       
      }else{

        console.log('222222');
        wx.showToast({
          title: '添加成功',
          icon: 'success',
          duration: 1500,
        })

        // app.redirectTomy();
        
        setTimeout(function () {
          console.log("延迟调用============")
          wx.navigateBack({
          delta: 1
        })      
        }, 1500)
       
      
      } 



  },
  bindButtonTap: function () { //注册按钮


    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (this.data.userRegister.phone == '') {
      wx.showToast({
        title: '手机号不能为空',
        icon: 'loading',
        duration: 1500
      })
      return false
    }
    else if (!myreg.test(this.data.userRegister.phone)) {
      wx.showToast({
        title: '手机号有误！',
        icon: 'loading',
        duration: 1500
      })
      return false
    } else {
      flag = 0;
     // userId = 18186592960 & phone=13627233474
      let url = app.apiUrl+'admin/user/api/contact';
      let params1 = this.data.userRegister;
      // let params1 = this.data.userLogin;
      let params = app.request.json2Form(params1);
      console.log(params);
      app.request.requestPostApi(url, params, this, this.successFun)

     


    }

  },
})
