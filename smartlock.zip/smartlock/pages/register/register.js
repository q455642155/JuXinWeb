// let md5 = require("../MD5.js");
// let checkNetWork = require("../utils/CheckNetWork.js");
let app = getApp();
let flag;
Page({
  data: {
    focus: false,
     btnDisabled: true,
   
    getCodeBtnProperty: {
      backgroundColor:'#20a0ff',
      titileColor: '#FFF',
      disabled: true,
      loading: false,
      title: '获取验证码'
    },

    userRegister: {
      mobileLogin:true,
      loginName:'',
      roleName:'ptyg',
      mobile: '',
      password: '',
      randomCode: '',
      no:'',
      name:'',

    },
    usermobile: {
      mobile: '',
      type: '1',  
    },

    usercode: {
      mobile: '',
      randomCode: '',
    },
    
    userphone: {
      mobile: '',
    },

  },

  onLoad: function () {
    this.setData({
      navH: app.globalData.navHeight
    })
  },

  // onReady: function () {
  //   // 页面渲染完成
  // },
  // onShow: function () {
  //   // 页面显示
  
  // },
  // onHide: function () {
  //   // 页面隐藏
  // },
  // onUnload: function () {
  //   // 页面关闭
  // },
 
  userInput: function(e) {  //手机号输入
    let that = this;
    let inputValue = e.detail.value;
    
      
    that.setData({
      'getCodeParams.account': inputValue,
      'userRegister.mobile': inputValue,
      'userRegister.loginName':inputValue,
      'userphone.mobile': inputValue,
      'usermobile.mobile': inputValue,
      'usercode.mobile': inputValue,
      'getCodeBtnProperty.titileColor': '#FFF',
      'getCodeBtnProperty.backgroundColor': '#20a0ff',
      'getCodeBtnProperty.disabled': false
    })

 
   },

   //姓名
  nameInput: function (e) {   //验证码输入

    let that = this;
    let inputValue = e.detail.value;

    that.setData({
      'userRegister.name': inputValue,
     
    })
  },

  //员工号
  nameInput1: function (e) {   //验证码输入

    let that = this;
    let inputValue = e.detail.value;

    that.setData({
      'userRegister.no': inputValue,
     
    })
  },


  codeInput: function (e) {   //验证码输入

    let that = this;
    let inputValue = e.detail.value;

    that.setData({
      'userRegister.randomCode': inputValue,
      'usercode.randomCode': inputValue,
    })
  },
  pswInput: function (e) {   //密码输入

    let that = this;
    let inputValue = e.detail.value;
    that.setData({
      'userRegister.password': inputValue
      //  btnDisabled: true
    })

  },

  //返回
  navBack: function () {
    wx.navigateBack({
      delta: 1
    })      
  },
  
  //   //获取验证码
  getCodeAct: function() {


    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (this.data.userRegister.mobile == '') {
      wx.showToast({
        title: '手机号不能为空',
        icon: 'loading',
        duration: 1500
      })
      return false
    } else if (!myreg.test(this.data.userRegister.mobile)) {
      wx.showToast({
        title: '手机号有误！',
        icon: 'loading',
        duration: 1500
      })
      return false
    }else{

      flag = 3;
    //  let url = 'http://39.107.66.62/admin/user/api/getRandomCode?';
      let url = app.apiUrl +'admin/user/api/validateMobileExist?';
      let params12 = this.data.userphone;
      let params1= app.request.json2Form(params12);
       url   = url+params1;
      console.log(url);
       let params = '';
      app.request.requestGetApi(url, params, this, this.successFun)
    }
   
  
  },
   
  successFun: function(res, selfObj) {
    console.log(flag);
    if (flag ==1){
      wx.showToast({
        title: '验证码已发送',
      })
      //启动定时器
      var number = 60;
      var time = setInterval(function () {
        number--;

        selfObj.setData({
          'getCodeBtnProperty.title': number + '秒',
          disabled: true,
          'getCodeBtnProperty.disabled': true
        })
        if (number == 0) {

          selfObj.setData({
            'getCodeBtnProperty.title': '重新获取',
            disabled: false,
            'getCodeBtnProperty.disabled': false
          })
          clearInterval(time);
        }
      }, 1000);
    } else if (flag == 0){

      let statu = res.data.success;
      let msg = res.data.msg;
      console.log(statu);
      console.log(msg);
      if (statu == 0) {
        wx.showToast({
          title: msg,
          icon: 'loading',
          duration: 1500,
        })
        //  wx.setStorageSync('token', this.data.userLogin.phone);
        //   app.redirectToHome();

      } else {
        //第二次网络请求
        flag = 2;

        let url = app.apiUrl +'admin/user/api/registerUser';
        let params1 = this.data.userRegister;
        // let params1 = this.data.userLogin;
        let params = app.request.json2Form(params1);
        console.log(params);
        app.request.requestPostApi(url, params, this, this.successFun)
      }
      // wx.showToast({
      //   title: '验证开始判断',
      // })
     

    } else if (flag == 2) {

      // wx.showToast({
      //   title: '注册成功',
      // })

      let statu = res.data.success;
      let msg = res.data.msg;
      console.log(statu);
      console.log(msg);
      if (statu == 0) {
        wx.showToast({
          title: msg,
          icon: 'loading',
          duration: 1500,
        })
        //  wx.setStorageSync('token', this.data.userLogin.phone);
        //   app.redirectToHome();
      } else {
        app.redirectToLogin();
    }
    } else if (flag == 3){

      let statu = res.data;
      console.log('判断手机号注册状态'+statu);
      if (statu == 1) {
        wx.showToast({
          title: '此手机号已注册',
          icon: 'loading',
          duration: 1500,
        })
        //  wx.setStorageSync('token', this.data.userLogin.phone);
        //   app.redirectToHome();
      } else {
        flag = 1;
        //  let url = 'http://39.107.66.62/admin/user/api/getRandomCode?';
        let url = app.apiUrl +'admin/user/api/getRandomCode?';
        let params12 = this.data.usermobile;
        let params1 = app.request.json2Form(params12);
        url = url + params1;
        console.log(url);
        let params = '';
        app.request.requestGetApi(url, params, this, this.successFun)
      }
     
    }
  
  
  
  },
  bindButtonTap: function() { //注册按钮
    

    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (this.data.userRegister.mobile == '') {
      wx.showToast({
        title: '手机号不能为空',
        icon: 'loading',
        duration: 1500
      })
      return false
    } else if (this.data.userRegister.randomCode == '') {
      wx.showToast({
        title: '验证码不能为空',
        icon: 'loading',
        duration: 1500
      })
      return false
    }
    else if (this.data.userRegister.name == '') {
      wx.showToast({
        title: '姓名不能为空',
        icon: 'loading',
        duration: 1500
      })
      return false
    } else if (this.data.userRegister.no == '') {
      wx.showToast({
        title: '工号不能为空',
        icon: 'loading',
        duration: 1500
      })
      return false
    }
    else if (this.data.userRegister.password == '') {
      wx.showToast({
        title: '密码不能为空',
        icon: 'loading',
        duration: 1500
      })
      return false
    }
  

    else if (!myreg.test(this.data.userRegister.mobile)) {
      wx.showToast({
        title: '手机号有误！',
        icon: 'loading',
        duration: 1500
      })
      return false
    }else{
      flag =0;

      let url = app.apiUrl +'admin/user/api/validateMobileCode';
      let params1 = this.data.userRegister;
      // let params1 = this.data.userLogin;
      let params = app.request.json2Form(params1);
      console.log(params); 
      app.request.requestPostApi(url, params, this, this.successFun)
    
    
    }

  },
})
