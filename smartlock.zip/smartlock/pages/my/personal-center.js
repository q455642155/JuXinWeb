var util = require('../../utils/util.js');
var app = getApp();
Page({
  data: {
   'date':'',
  },
  onLoad: function () {
    this.setData({
      navH: app.globalData.navHeight
    }) 

    var expireDate1 = wx.getStorageSync('expireDate1');
    var effectDate1 = wx.getStorageSync('effectDate1');
    var time = util.formatTime(new Date());
    console.log("生效日期：" + effectDate1);
    console.log("失效日期：" + expireDate1);


    // if (time > expireDate1) {

    //   wx.showToast({
    //     title: '授权时间过期！',
    //     duration: 1500,
    //   })
    //   //跳转到登录页面 
    //   app.redirectToLogin();
    // }else{
      if (effectDate1==null){
        effectDate1 = time;
      }
    // if (expireDate1 == null){
    expireDate1 ='2068-12-10 12:41:51';
      //   console.log("失效日期出来没有");
      // }
      var date = effectDate1.substring(0, 10) + " " + effectDate1.substring(11, 16) + '至' + expireDate1.substring(0, 10) + " " + expireDate1.substring(11, 16);
      
      this.setData({
        'date': date,
       

      });  
  // }
  
  
  },

 
    calling:function(){

      wx.showModal({
        title: '拨打电话',
        content: '确定要拨打400-6669687？',
        success: function (sm) {
          if (sm.confirm) {
        wx.makePhoneCall({
        phoneNumber: '400-6669687', //此号码并非真实电话号码，仅用于测试
        success: function () {
        console.log("拨打电话成功！")
       },
       fail: function () {
        console.log("拨打电话失败！")
      }
    })
           
          } else if (sm.cancel) {
            console.log('用户点击取消')
          }
        }
      })
   
  },





  /**
 * 退回到上一个页面
 */
  navBack: function () {
    wx.navigateBack({
      delta: 1
    })      
  },

  /**
  * 维修
  */
  weixiutap: function () {
    app.toWarn();
  },

  //安全中心
  myTickets: function () {
    app.toAnquan();
  },
  

   //退出登录
  exitmy: function () {
    wx.showModal({
      title: '退出登录',
      content: '确定要退出并清空用户数据？',
      success: function (sm) {
        if (sm.confirm) {
          

          wx.removeStorage({
            key: 'token',
            key: 'id',
            key: 'dormitoryNo',
            key: 'equipmentSn',
            key: 'terminalSn',
            key: 'effectDate',
            key: 'expireDate',
            key: 'beginTime',
            key: 'endTime',
            key: 'card',
            key: 'fingerprint',
            key: 'battery',
            key: 'expireDate1',
          
            
            success: function (res) {
              app.redirectToLogin();
              // console.log('数据清空了')
            }
          })
        

        } else if (sm.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  
  },

  onShow: function () {
  }
})