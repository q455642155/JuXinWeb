//app.js

const request = require('utils/request.js')
App({

  request: request,


  onLaunch: function () {
    //调用API从本地缓存中获取数据
    wx.getSystemInfo({
      success: res => {
        //导航高度
        this.globalData.navHeight = res.statusBarHeight + 46;
      }, fail(err) {
        console.log(err);
      }
    })

   
    // var logs = wx.getStorageSync('logs') || []
    // logs.unshift(Date.now())
    // wx.setStorageSync('logs', logs)
  },

  // 获取手机系统信息
  


  getUserInfo:function(cb){
    
    var that = this
    if(this.globalData.userInfo){
      typeof cb == "function" && cb(this.globalData.userInfo)
    }else{
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }
  },
  globalData:{
    userInfo:null,
    mqtt_client: null,
    messages: null,
    navHeight: 0
  },

  //公共方法
  redirectToHome: function () {
    wx.redirectTo({
      url: '../index/index',
    })
  },

  redirectTomy: function () {
    wx.redirectTo({
      url: '../my/personal-center',
    })
  },
  
  
  
  redirectToLogin: function () {
    wx.redirectTo({
      url: '../login/login',
    })
  },

  //回主页
  toIndex: function () {
    wx.navigateTo({
      url: '../index/index'
    })
  },

  toLogin: function () {
    wx.navigateTo({
      url: '../login/login'
    })
  },

 
  toMy: function () {
    wx.navigateTo({
      url: '../my/personal-center'
    })
  },

  toWarn: function () {
    wx.navigateTo({
      url: '../warn/warn'
    })
  },

  toAnquan: function () {
    wx.navigateTo({
      url: '../urgent/urgent'
    })
  },

  

 
  
  


 

  /**
  * 定义的接口域名
  */
  // apiUrl: 'https://www.timeslock.com/',
  apiUrl: 'https://www.cityrider.cn/',
 // apiUrl: '192.168.0.103:8080/',
 // // 登陆
  url_login:'/bluemoon-control/user/ssoLogin',
// 注册
   url_regist :'/bluemoon-control/user/getUserInfo',
//忘记密码
  url_password : '/bluemoon-control/attendance/getGpsAddress',
//手机号重复
  url_samephone:'/bluemoon-control/attendance/getWorkplaceList',
//发送验证码
 url_code :'/bluemoon-control/attendance/checkScanCode',
//验证码成功性
   url_codesucess: '/bluemoon-control/attendance/addPunchCardIn',
//修改密码
  url_putpwd : '/bluemoon-control/attendance/addPunchCardOut',
//自定义修改密码
   url_lockpwd :'/bluemoon-control/attendance/getPunchCard',
// 自定义录入指纹
   url_zhiwen : '/bluemoon-control/attendance/confirmWorkDiary',
// 自定义刷卡
  url_card: '/bluemoon-control/attendance/isPunchCard'

})