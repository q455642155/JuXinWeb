

// const app = getApp()

// const host                    = 'https://angel.bluemoon.com.cn'

// // 登陆
// var   url_login               = host + '/bluemoon-control/user/ssoLogin'
// // 注册
// var   url_get_user_info       = host + '/bluemoon-control/user/getUserInfo'
// //忘记密码
// var   url_get_gps_address     = host + '/bluemoon-control/attendance/getGpsAddress'
// //手机号重复
// var   url_get_workplace_list  = host + '/bluemoon-control/attendance/getWorkplaceList'
// //发送验证码
// var   url_check_scan_code     = host + '/bluemoon-control/attendance/checkScanCode'
// //验证码成功性
// var   url_punch_card_in       = host + '/bluemoon-control/attendance/addPunchCardIn'
// //修改密码
// var   url_punch_card_out      = host + '/bluemoon-control/attendance/addPunchCardOut'
// //自定义修改密码
// var   url_get_punch_card_info = host + '/bluemoon-control/attendance/getPunchCard'
// // 自定义录入指纹
// var   url_submit_work_diary   = host + '/bluemoon-control/attendance/confirmWorkDiary'
// // 自定义刷卡
// var   url_is_punch_card       = host + '/bluemoon-control/attendance/isPunchCard'


// let token;
/**
 * @desc    API请求接口类封装
 * @author  liuli
 * @date    2018-09-01
 */


function json2Form(json) {
  var str = [];
  for (var p
    in json) {
    str.push(encodeURIComponent(p) + "=" + encodeURIComponent(json[p]));
  }
  return str.join("&");
}

/**
  *
  * json转字符串
  */
function stringToJson(data) {
  return JSON.parse(data);
}
/**
*字符串转json
*/
function jsonToString(data) {
  return JSON.stringify(data);
}
/**
*map转换为json
*/
function mapToJson(map) {
  return JSON.stringify(strMapToObj(map));
}
/**
*json转换为map
*/
function jsonToMap(jsonStr) {
  return objToStrMap(JSON.parse(jsonStr));
}


/**
*map转化为对象（map所有键都是字符串，可以将其转换为对象）
*/
function strMapToObj(strMap) {
  let obj = Object.create(null);
  for (let [k, v] of strMap) {
    obj[k] = v;
  }
  return obj;
}

/**
*对象转换为Map
*/
function objToStrMap(obj) {
  let strMap = new Map();
  for (let k of Object.keys(obj)) {
    strMap.set(k, obj[k]);
  }
  return strMap;
}






/**
 * POST请求API
 * @param  {String}   url         接口地址
 * @param  {Object}   params      请求的参数
 * @param  {Object}   sourceObj   来源对象
 * @param  {Function} successFun  接口调用成功返回的回调函数
 * @param  {Function} failFun     接口调用失败的回调函数
 * @param  {Function} completeFun 接口调用结束的回调函数(调用成功、失败都会执行)
 */
function requestPostApi(url, params, sourceObj, successFun, failFun, completeFun) {
  requestApi(url, params, 'POST', sourceObj, successFun, failFun, completeFun)
}

/**
 * GET请求API
 * @param  {String}   url         接口地址
 * @param  {Object}   params      请求的参数
 * @param  {Object}   sourceObj   来源对象
 * @param  {Function} successFun  接口调用成功返回的回调函数
 * @param  {Function} failFun     接口调用失败的回调函数
 * @param  {Function} completeFun 接口调用结束的回调函数(调用成功、失败都会执行)
 */
function requestGetApi(url, params, sourceObj, successFun, failFun, completeFun) {
  requestApi(url, params, 'GET', sourceObj, successFun, failFun, completeFun)
}

/**
 * 请求API
 * @param  {String}   url         接口地址
 * @param  {Object}   params      请求的参数
 * @param  {String}   method      请求类型
 * @param  {Object}   sourceObj   来源对象
 * @param  {Function} successFun  接口调用成功返回的回调函数
 * @param  {Function} failFun     接口调用失败的回调函数
 * @param  {Function} completeFun 接口调用结束的回调函数(调用成功、失败都会执行)
 */
function requestApi(url, params, method, sourceObj, successFun, failFun, completeFun) {

  // 获取token
    //  wx.getStorage({
    //  key: 'token',
    //  success: function (res) {
    //   token = res.data;
      wx.request({
        url: url,
        method: method,
        data: params,
        header: {
          'Content-Type': 'application/x-www-form-urlencoded',
          // 'X-Authorization': token,
        },
        success: function (res) {
          console.log(res); 
          // let statu = res.data.errno;
          // let message = res.data.errmsg;
           typeof successFun == 'function' && successFun(res, sourceObj);
        
        },
        fail: function (res) {
          console.log(res); 
          typeof failFun == 'function' && failFun(res, sourceObj);
          wx.showToast({
            title: '服务繁忙,请稍后再试',
            icon: 'loading',
            duration: 2000,
          })
        },
        complete: function (res) {
          typeof completeFun == 'function' && completeFun(res, sourceObj)
        }
      })
 
  if (method == 'POST') {
    var contentType = 'application/x-www-form-urlencoded'
  } else {
    var contentType = 'application/json'
  }

}








module.exports = {
  requestPostApi,
  requestGetApi,
  json2Form,
  stringToJson: stringToJson,
  jsonToString: jsonToString,
  mapToJson: mapToJson,
  jsonToMap: jsonToMap,
  strMapToObj: strMapToObj,
  objToStrMap: objToStrMap,


}




// module.exports = request;